import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { messages } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    // Fetch products from DB for live catalog context
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const { data: products } = await supabase
      .from("products")
      .select("name, category, price, original_price, description, features, badge")
      .eq("published", true);

    const productCatalog = (products || [])
      .map(
        (p) =>
          `• ${p.name} (${p.category}) — $${p.price}${p.original_price ? ` (was $${p.original_price})` : ""}${p.badge ? ` [${p.badge}]` : ""}\n  ${p.description}\n  Features: ${(p.features || []).join(", ")}`
      )
      .join("\n\n");

    const systemPrompt = `You are VBB STORE's AI assistant — a friendly, knowledgeable support agent for a premium Meta advertising products store. You answer questions about ANYTHING on the website: products, services, policies, pricing, how things work, etc.

ABOUT VBB STORE:
- VBB STORE sells verified Meta advertising products: Business Managers, WhatsApp Business API accounts, Facebook Ads accounts, Reinstated Profiles, and Ballon BMs.
- Over 5 years in business, 10,000+ customers served across 50+ countries.
- All products come with genuine documentation and the highest trust scores.
- Payment: Crypto only — USDT (TRC20), Bitcoin, and Ethereum.
- Delivery: Instant/same-day delivery after payment clears.
- Support: 24/7 via WhatsApp (+8801302669333) or Telegram (@Verifiedbmbuy).

LIVE PRODUCT CATALOG:
${productCatalog}

SERVICES:
- Verified Business Managers (1, 3, 5, or 10 ad account slots)
- WhatsApp Business API (standard & green badge verified)
- Facebook Ads Accounts ($250 limit & unlimited)
- Reinstated Facebook Profiles
- Ballon BM (Standard & Premium)
- Bulk/volume orders with custom pricing
- Custom account setups
- Dedicated account managers for large orders

POLICIES:
- 7-Day Replacement Guarantee: If an account becomes non-functional within 7 days (not due to buyer's actions), it's replaced for free within 24 hours.
- Eligible for replacement: account non-functional within 7 days, not as described, invalid credentials, verification mismatch.
- NOT eligible: buyer policy violations, prohibited content, after 7-day window, shared credentials, natural Meta updates.
- No monetary refunds — replacements only (digital product).
- Replacement process: Contact support → verification (2-4 hours) → replacement within 24 hours.

FAQ KNOWLEDGE:
- Verified BM = Meta Business Manager verified with real business documents, giving higher trust scores and fewer restrictions.
- WhatsApp Business API = enterprise WhatsApp for automated messages, chatbots, bulk messaging.
- Ballon BM = premium tier with enhanced trust and advanced capabilities.
- Accounts work globally, come with documentation, and are ready for immediate ad campaigns.
- Green badge on WhatsApp = official verification checkmark, increases customer trust.
- Bulk pricing available — contact via WhatsApp/Telegram.

GUIDELINES:
- Be concise (2-4 sentences typically), warm, and helpful.
- Answer questions about ANY aspect of VBB STORE — products, pricing, policies, services, how-to, etc.
- When recommending products, mention price, key features, and link to relevant pages.
- For purchases, direct to WhatsApp (+8801302669333) or Telegram (@Verifiedbmbuy).
- If asked something completely outside VBB STORE's scope, politely redirect.
- Use emojis sparingly for friendliness.
- Always mention the 7-day replacement guarantee when relevant.
- If budget is mentioned, recommend the best-fit product.
- For support issues, guide them to WhatsApp/Telegram.
- You can reference these website pages: /shop, /about, /contact, /faq, /refund, /replacement, /terms, /privacy, /blog`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [{ role: "system", content: systemPrompt }, ...messages],
        stream: true,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit exceeded. Please try again shortly." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "Service temporarily unavailable." }), {
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const t = await response.text();
      console.error("AI gateway error:", response.status, t);
      return new Response(JSON.stringify({ error: "AI service error" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(response.body, {
      headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
    });
  } catch (e) {
    console.error("chatbot error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
