-- Drop the restrictive policy
DROP POLICY IF EXISTS "Admins can manage roles" ON public.user_roles;

-- Recreate as PERMISSIVE so admins can actually read their roles
CREATE POLICY "Admins can manage roles"
ON public.user_roles
FOR ALL
USING (is_admin());

-- Also allow authenticated users to read their own role (needed for the initial admin check)
CREATE POLICY "Users can read own role"
ON public.user_roles
FOR SELECT
USING (auth.uid() = user_id);
