
-- Fix seo_settings: drop the ALL policy that overlaps with the public SELECT
DROP POLICY "Admins can manage SEO" ON public.seo_settings;
CREATE POLICY "Admins can insert SEO" ON public.seo_settings FOR INSERT TO authenticated WITH CHECK (public.is_admin());
CREATE POLICY "Admins can update SEO" ON public.seo_settings FOR UPDATE TO authenticated USING (public.is_admin());
CREATE POLICY "Admins can delete SEO" ON public.seo_settings FOR DELETE TO authenticated USING (public.is_admin());

-- Fix site_content: drop the ALL policy that overlaps with the public SELECT
DROP POLICY "Admins can manage content" ON public.site_content;
CREATE POLICY "Admins can insert content" ON public.site_content FOR INSERT TO authenticated WITH CHECK (public.is_admin());
CREATE POLICY "Admins can update content" ON public.site_content FOR UPDATE TO authenticated USING (public.is_admin());
CREATE POLICY "Admins can delete content" ON public.site_content FOR DELETE TO authenticated USING (public.is_admin());
