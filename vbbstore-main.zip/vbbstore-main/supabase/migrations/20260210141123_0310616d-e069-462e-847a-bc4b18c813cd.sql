
CREATE TABLE public.media_seo (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  file_name TEXT NOT NULL UNIQUE,
  alt_text TEXT DEFAULT '',
  title TEXT DEFAULT '',
  caption TEXT DEFAULT '',
  description TEXT DEFAULT '',
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.media_seo ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view media SEO" ON public.media_seo FOR SELECT USING (true);
CREATE POLICY "Admins can insert media SEO" ON public.media_seo FOR INSERT WITH CHECK (is_admin());
CREATE POLICY "Admins can update media SEO" ON public.media_seo FOR UPDATE USING (is_admin());
CREATE POLICY "Admins can delete media SEO" ON public.media_seo FOR DELETE USING (is_admin());
