
ALTER TABLE public.products ADD COLUMN published boolean DEFAULT true;

-- Update existing products to be published
UPDATE public.products SET published = true WHERE published IS NULL;

-- Update the public select policy to only show published products (or all for admins)
DROP POLICY IF EXISTS "Anyone can view products" ON public.products;
CREATE POLICY "Anyone can view products"
ON public.products FOR SELECT
USING (published = true OR is_admin());
