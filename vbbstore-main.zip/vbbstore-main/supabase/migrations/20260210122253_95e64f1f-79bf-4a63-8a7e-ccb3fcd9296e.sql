
-- Redirections table for 301/302 redirects
CREATE TABLE public.redirections (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  from_path TEXT NOT NULL,
  to_path TEXT NOT NULL,
  redirect_type TEXT NOT NULL DEFAULT '301',
  active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.redirections ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage redirections" ON public.redirections FOR ALL USING (is_admin());
CREATE POLICY "Anyone can read redirections" ON public.redirections FOR SELECT USING (true);

-- Add focus_keyword, schema_markup, and social fields to seo_settings
ALTER TABLE public.seo_settings 
  ADD COLUMN IF NOT EXISTS focus_keyword TEXT DEFAULT '',
  ADD COLUMN IF NOT EXISTS schema_type TEXT DEFAULT 'WebPage',
  ADD COLUMN IF NOT EXISTS schema_markup JSONB DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS og_title TEXT DEFAULT '',
  ADD COLUMN IF NOT EXISTS og_description TEXT DEFAULT '',
  ADD COLUMN IF NOT EXISTS twitter_title TEXT DEFAULT '',
  ADD COLUMN IF NOT EXISTS twitter_description TEXT DEFAULT '',
  ADD COLUMN IF NOT EXISTS twitter_image TEXT DEFAULT '',
  ADD COLUMN IF NOT EXISTS noindex BOOLEAN DEFAULT false,
  ADD COLUMN IF NOT EXISTS nofollow BOOLEAN DEFAULT false,
  ADD COLUMN IF NOT EXISTS canonical_url TEXT DEFAULT '',
  ADD COLUMN IF NOT EXISTS robots_advanced TEXT DEFAULT '';

-- Site-level robots.txt content stored in site_content
INSERT INTO public.site_content (key, value) VALUES ('robots_txt', 'User-agent: *
Allow: /
Disallow: /admin
Sitemap: https://verifiedbmbuy.com/sitemap.xml')
ON CONFLICT DO NOTHING;
