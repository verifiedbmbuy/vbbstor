-- Add slug column to products
ALTER TABLE public.products ADD COLUMN slug text;

-- Generate slugs from existing product names
UPDATE public.products SET slug = lower(regexp_replace(regexp_replace(name, '[^a-zA-Z0-9\s-]', '', 'g'), '\s+', '-', 'g'));

-- Make slug NOT NULL and UNIQUE after populating
ALTER TABLE public.products ALTER COLUMN slug SET NOT NULL;
ALTER TABLE public.products ADD CONSTRAINT products_slug_unique UNIQUE (slug);
