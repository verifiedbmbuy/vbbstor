-- Fix orders table: drop the restrictive-only policy and recreate as permissive with explicit role
DROP POLICY IF EXISTS "Admins can manage orders" ON public.orders;

CREATE POLICY "Admins can select orders"
ON public.orders FOR SELECT
TO authenticated
USING (public.is_admin());

CREATE POLICY "Admins can insert orders"
ON public.orders FOR INSERT
TO authenticated
WITH CHECK (public.is_admin());

CREATE POLICY "Admins can update orders"
ON public.orders FOR UPDATE
TO authenticated
USING (public.is_admin());

CREATE POLICY "Admins can delete orders"
ON public.orders FOR DELETE
TO authenticated
USING (public.is_admin());

-- Explicitly deny anonymous access
CREATE POLICY "Deny anon access to orders"
ON public.orders FOR SELECT
TO anon
USING (false);
