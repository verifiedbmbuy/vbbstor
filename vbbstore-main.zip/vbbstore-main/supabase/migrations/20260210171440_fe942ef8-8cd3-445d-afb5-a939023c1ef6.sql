
-- Add flexible attributes column to products for custom product details
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS attributes jsonb DEFAULT '{}'::jsonb;
