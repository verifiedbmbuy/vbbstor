/**
 * Transform a Supabase storage URL to use the image transformation API
 * for serving optimally sized images.
 */
export function getOptimizedImageUrl(
  url: string | undefined | null,
  width: number = 500,
  height: number = 500,
  quality: number = 75
): string {
  if (!url) return "/placeholder.svg";

  // Only transform Supabase storage URLs
  if (url.includes("supabase.co/storage/v1/object/public/")) {
    return url.replace(
      "/storage/v1/object/public/",
      `/storage/v1/render/image/public/`
    ) + `?width=${width}&height=${height}&quality=${quality}&resize=contain`;
  }

  return url;
}
