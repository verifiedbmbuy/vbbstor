export interface Product {
  id: string;
  slug: string;
  name: string;
  category: string;
  price: number;
  originalPrice?: number;
  description: string;
  features: string[];
  image: string;
  badge?: string;
  attributes?: Record<string, string>;
}

export const categories = [
  "All",
  "Verified BM",
  "WhatsApp API",
  "Facebook Ads",
  "TikTok Ads",
  "Google Ads",
  "Reinstated Profiles",
] as const;

export const products: Product[] = [
  {
    id: "vbm-1", slug: "verified-bm-1-ad-account",
    name: "Verified BM – 1 Ad Account", category: "Verified BM", price: 120, originalPrice: 190,
    description: "Verified Facebook Business Manager with 1 ad account. Real documents, high trust score, ready to use right away.",
    features: ["Verified with real documents", "1 Ad Account included", "High trust score", "Instant delivery", "7-day replacement guarantee"],
    image: "/placeholder.svg", badge: "Best Seller",
  },
  {
    id: "vbm-3", slug: "verified-bm-3-ad-accounts",
    name: "Verified BM – 3 Ad Accounts", category: "Verified BM", price: 250, originalPrice: 380,
    description: "Verified Business Manager with 3 ad account slots. Great for agencies running multiple campaigns.",
    features: ["Verified with real documents", "3 Ad Accounts included", "Premium trust score", "Instant delivery", "7-day replacement guarantee"],
    image: "/placeholder.svg",
  },
  {
    id: "vbm-5", slug: "verified-bm-5-ad-accounts",
    name: "Verified BM – 5 Ad Accounts", category: "Verified BM", price: 400, originalPrice: 600,
    description: "Top-tier verified Business Manager with 5 ad account slots. Built for large-scale advertising.",
    features: ["Verified with real documents", "5 Ad Accounts included", "Highest trust score", "Instant delivery", "7-day replacement guarantee"],
    image: "/placeholder.svg", badge: "Premium",
  },
  {
    id: "waba-1", slug: "whatsapp-business-api-account",
    name: "WhatsApp Business API Account", category: "WhatsApp API", price: 180, originalPrice: 280,
    description: "Ready-to-use WhatsApp Business API with full access. Send messages at scale and grow your business.",
    features: ["Full API access", "Green badge eligible", "Bulk messaging ready", "Instant delivery", "7-day replacement guarantee"],
    image: "/placeholder.svg", badge: "Popular",
  },
  {
    id: "waba-2", slug: "whatsapp-api-verified-bm-bundle",
    name: "WhatsApp API + Verified BM Bundle", category: "WhatsApp API", price: 280, originalPrice: 400,
    description: "Get both WhatsApp Business API and a verified BM in one bundle. Everything you need to advertise and message.",
    features: ["WhatsApp API included", "Verified BM included", "Bundle discount", "Instant delivery", "7-day replacement guarantee"],
    image: "/placeholder.svg",
  },
  {
    id: "fba-1", slug: "facebook-ads-account-250-limit",
    name: "Facebook Ads Account – $250 Limit", category: "Facebook Ads", price: 50, originalPrice: 79,
    description: "Pre-warmed Facebook Ads account with $250 daily limit. Clean history, ready for your first campaign.",
    features: ["$250 daily limit", "Pre-warmed account", "Clean history", "Instant delivery", "7-day replacement guarantee"],
    image: "/placeholder.svg",
  },
  {
    id: "fba-2", slug: "facebook-ads-account-unlimited",
    name: "Facebook Ads Account – Unlimited", category: "Facebook Ads", price: 150, originalPrice: 230,
    description: "Unlimited spending Facebook Ads account. No daily cap on your ad spend.",
    features: ["Unlimited spending", "Premium account", "Clean history", "Instant delivery", "7-day replacement guarantee"],
    image: "/placeholder.svg", badge: "Hot",
  },
  {
    id: "tik-1", slug: "tiktok-ads-account-standard",
    name: "TikTok Ads Account – Standard", category: "TikTok Ads", price: 100, originalPrice: 160,
    description: "Ready-to-use TikTok Ads account. Start running ads on TikTok right away with no setup hassle.",
    features: ["Ready to run ads", "Clean account history", "No restrictions", "Instant delivery", "7-day replacement guarantee"],
    image: "/placeholder.svg",
  },
  {
    id: "tik-2", slug: "tiktok-ads-account-agency",
    name: "TikTok Ads Account – Agency", category: "TikTok Ads", price: 250, originalPrice: 380,
    description: "Agency-grade TikTok Ads account with higher spend limits. Perfect for managing multiple brands.",
    features: ["Higher spend limits", "Agency-level access", "Multiple campaigns", "Instant delivery", "7-day replacement guarantee"],
    image: "/placeholder.svg", badge: "New",
  },
  {
    id: "gads-1", slug: "google-ads-account-standard",
    name: "Google Ads Account – Standard", category: "Google Ads", price: 80, originalPrice: 130,
    description: "Verified Google Ads account ready to use. Clean history, no suspensions, start advertising today.",
    features: ["Clean account history", "No suspensions", "Ready to use", "Instant delivery", "7-day replacement guarantee"],
    image: "/placeholder.svg",
  },
  {
    id: "gads-2", slug: "google-ads-account-aged",
    name: "Google Ads Account – Aged", category: "Google Ads", price: 180, originalPrice: 280,
    description: "Aged Google Ads account with spending history. Higher trust, better ad delivery, fewer restrictions.",
    features: ["Aged with spend history", "Higher trust level", "Better ad delivery", "Instant delivery", "7-day replacement guarantee"],
    image: "/placeholder.svg", badge: "Premium",
  },
  {
    id: "rp-1", slug: "reinstated-facebook-profile",
    name: "Reinstated Facebook Profile", category: "Reinstated Profiles", price: 80, originalPrice: 120,
    description: "Facebook profile that was disabled and fully restored. Clean record, all features working.",
    features: ["Fully reinstated", "Clean record", "Full functionality", "Instant delivery", "7-day replacement guarantee"],
    image: "/placeholder.svg",
  },
  {
    id: "vbm-agency", slug: "verified-bm-agency-pack-10-ad-accounts",
    name: "Verified BM – Agency Pack (10 Ad Accounts)", category: "Verified BM", price: 750, originalPrice: 1100,
    description: "Agency-grade verified BM with 10 ad account slots. Made for large teams running lots of campaigns.",
    features: ["Verified with real documents", "10 Ad Accounts included", "Maximum trust score", "Priority support", "7-day replacement guarantee"],
    image: "/placeholder.svg", badge: "Agency",
  },
  {
    id: "waba-green", slug: "whatsapp-api-green-badge-verified",
    name: "WhatsApp API – Green Badge Verified", category: "WhatsApp API", price: 350, originalPrice: 520,
    description: "WhatsApp Business API with the official green badge. Maximum trust for your customers.",
    features: ["Official green badge", "Full API access", "Unlimited messaging", "Priority support", "7-day replacement guarantee"],
    image: "/placeholder.svg", badge: "Verified",
  },
];
