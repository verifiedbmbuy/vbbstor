import verifiedBmImg from "@/assets/products/verified-bm.jpg";
import whatsappApiImg from "@/assets/products/whatsapp-api.jpg";
import facebookAdsImg from "@/assets/products/facebook-ads.jpg";
import reinstatedProfileImg from "@/assets/products/reinstated-profile.jpg";
import ballonBmImg from "@/assets/products/ballon-bm.jpg";

const categoryImages: Record<string, string> = {
  "Verified BM": verifiedBmImg,
  "WhatsApp API": whatsappApiImg,
  "Facebook Ads": facebookAdsImg,
  "Reinstated Profiles": reinstatedProfileImg,
  "Ballon BM": ballonBmImg,
};

export const getProductImage = (category: string): string => {
  return categoryImages[category] || verifiedBmImg;
};
