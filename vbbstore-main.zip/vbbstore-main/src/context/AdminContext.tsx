import { createContext, useContext, useState, ReactNode } from "react";
import { Product, products as defaultProducts } from "@/data/products";
import { BlogPost, blogPosts as defaultBlogPosts } from "@/data/blog";

export interface SiteContent {
  heroTitle: string;
  heroSubtitle: string;
  heroBadge: string;
  aboutText: string;
}

export interface Order {
  id: string;
  product: string;
  customer: string;
  email: string;
  amount: number;
  status: "pending" | "completed" | "cancelled";
  date: string;
}

interface AdminContextType {
  products: Product[];
  setProducts: React.Dispatch<React.SetStateAction<Product[]>>;
  blogPosts: BlogPost[];
  setBlogPosts: React.Dispatch<React.SetStateAction<BlogPost[]>>;
  siteContent: SiteContent;
  setSiteContent: React.Dispatch<React.SetStateAction<SiteContent>>;
  orders: Order[];
  setOrders: React.Dispatch<React.SetStateAction<Order[]>>;
}

const AdminContext = createContext<AdminContextType | null>(null);

const defaultSiteContent: SiteContent = {
  heroTitle: "Buy Verified BM – Facebook Business Manager & WhatsApp API",
  heroSubtitle: "Top-rated Meta ad accounts with the highest trust scores. Many years on the market delivering best quality verified Business Managers to advertisers worldwide.",
  heroBadge: "Best Verified Business Manager 2026",
  aboutText: "VBB STORE is a trusted and secure platform for purchasing verified Facebook Business Manager accounts (Meta BM) and WhatsApp Business API (WABA) accounts.",
};

const sampleOrders: Order[] = [
  { id: "ORD-001", product: "Verified BM – 1 Ad Account", customer: "James W.", email: "james@example.com", amount: 120, status: "completed", date: "2026-02-08" },
  { id: "ORD-002", product: "WhatsApp Business API Account", customer: "Aisha K.", email: "aisha@example.com", amount: 180, status: "completed", date: "2026-02-07" },
  { id: "ORD-003", product: "Facebook Ads Account – Unlimited", customer: "Lucas D.", email: "lucas@example.com", amount: 150, status: "pending", date: "2026-02-09" },
  { id: "ORD-004", product: "TikTok Ads Account – Agency", customer: "Sophie L.", email: "sophie@example.com", amount: 250, status: "pending", date: "2026-02-10" },
  { id: "ORD-005", product: "Verified BM – 3 Ad Accounts", customer: "Markus S.", email: "markus@example.com", amount: 250, status: "cancelled", date: "2026-02-06" },
];

export const AdminProvider = ({ children }: { children: ReactNode }) => {
  const [products, setProducts] = useState<Product[]>(defaultProducts);
  const [blogPosts, setBlogPosts] = useState<BlogPost[]>(defaultBlogPosts);
  const [siteContent, setSiteContent] = useState<SiteContent>(defaultSiteContent);
  const [orders, setOrders] = useState<Order[]>(sampleOrders);

  return (
    <AdminContext.Provider value={{ products, setProducts, blogPosts, setBlogPosts, siteContent, setSiteContent, orders, setOrders }}>
      {children}
    </AdminContext.Provider>
  );
};

export const useAdmin = () => {
  const ctx = useContext(AdminContext);
  if (!ctx) throw new Error("useAdmin must be used within AdminProvider");
  return ctx;
};
