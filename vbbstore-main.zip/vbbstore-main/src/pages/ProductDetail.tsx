import { useParams, Link, useNavigate } from "react-router-dom";
import { CheckCircle2, ArrowRight, MessageCircle, Send, ShieldCheck, Clock, Lock, Zap, Star, Truck, Package, ChevronRight, CreditCard, UserCheck, Award, Headphones, RefreshCcw, Globe, FileText, Download, Shield, Monitor, BadgeCheck, CircleDollarSign, Wallet, MessageSquare, Mail, HelpCircle } from "lucide-react";
import { useProduct, useProducts } from "@/hooks/useProducts";
import { useCart } from "@/context/CartContext";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import FloatingContact from "@/components/FloatingContact";
import ProductCard from "@/components/ProductCard";
import { getOptimizedImageUrl } from "@/lib/imageUtils";
import { usePageSEO } from "@/hooks/use-page-seo";

const ProductDetail = () => {
  const { slug } = useParams();
  const { addToCart } = useCart();
  const navigate = useNavigate();
  const { product } = useProduct(slug);
  const { products: allProducts } = useProducts();

  usePageSEO({
    title: product ? `${product.name} - Buy Now | VBB STORE` : "Product | VBB STORE",
    description: product
      ? `Buy ${product.name} from VBB STORE. ${product.description} Instant delivery & 7-day replacement guarantee.`
      : "Browse our products at VBB STORE.",
    path: `/product/${slug || ""}`,
  });

  const related = product
    ? allProducts.filter((p) => p.category === product.category && p.id !== product.id).slice(0, 4)
    : [];

  const discount = product?.originalPrice
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;
  const savings = product?.originalPrice ? product.originalPrice - product.price : 0;

  if (!product) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container py-20 text-center">
          <h1 className="text-2xl font-bold text-foreground">Product not found</h1>
          <Link to="/shop">
            <Button className="mt-4">Back to Shop</Button>
          </Link>
        </div>
        <Footer />
      </div>
    );
  }

  const handleWhatsApp = () => {
    window.open(
      `https://wa.me/8801302669333?text=${encodeURIComponent(`Hi, I want to buy: ${product.name} ($${product.price})`)}`,
      "_blank"
    );
  };

  const handleTelegram = () => {
    window.open(
      `https://t.me/Verifiedbmbuy?text=${encodeURIComponent(`Hi, I want to buy: ${product.name} ($${product.price})`)}`,
      "_blank"
    );
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />

      {/* Breadcrumb */}
      <div className="border-b border-border bg-card">
        <div className="container py-3">
          <nav className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <Link to="/" className="hover:text-foreground transition-colors">Home</Link>
            <ChevronRight className="h-3 w-3" />
            <Link to="/shop" className="hover:text-foreground transition-colors">Shop</Link>
            <ChevronRight className="h-3 w-3" />
            <span className="text-foreground font-medium truncate max-w-[200px]">{product.name}</span>
          </nav>
        </div>
      </div>

      {/* Main Product Section */}
      <section className="container py-8 md:py-12">
        <div className="grid gap-8 lg:grid-cols-2 lg:gap-12">

          {/* Left – Image */}
          <div className="space-y-4">
            <div className="relative overflow-hidden rounded-2xl border border-border bg-muted/30">
              {product.badge && (
                <Badge className="absolute left-3 top-3 z-10 bg-destructive text-destructive-foreground text-[10px] font-bold px-2.5 py-1 uppercase tracking-wider">
                  {product.badge}
                </Badge>
              )}
              {discount > 0 && (
                <Badge className="absolute right-3 top-3 z-10 bg-primary text-primary-foreground text-[10px] font-bold px-2.5 py-1">
                  Save {discount}%
                </Badge>
              )}
              {product.image && product.image !== "/placeholder.svg" ? (
                <img
                  src={getOptimizedImageUrl(product.image, 700, 700)}
                  alt={product.name}
                  className="aspect-square w-full object-contain p-8"
                  width={700}
                  height={700}
                />
              ) : (
                <div className="flex aspect-square w-full items-center justify-center">
                  <span className="text-7xl font-bold text-muted-foreground/20">VBB</span>
                </div>
              )}
            </div>

            {/* Trust Strip */}
            <div className="grid grid-cols-3 gap-3">
              <TrustItem icon={Lock} label="Secure Payment" />
              <TrustItem icon={Truck} label="Instant Delivery" />
              <TrustItem icon={ShieldCheck} label="7-Day Guarantee" />
            </div>
          </div>

          {/* Right – Product Info */}
          <div className="flex flex-col">
            <Badge variant="secondary" className="w-fit text-[10px] font-bold uppercase tracking-widest mb-3">
              {product.category}
            </Badge>

            <h1 className="text-xl font-extrabold leading-tight text-foreground md:text-2xl lg:text-3xl">
              {product.name}
            </h1>

            {/* Rating */}
            <div className="flex items-center gap-2 mt-3">
              <div className="flex">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-4 w-4 fill-amber-400 text-amber-400" />
                ))}
              </div>
              <span className="text-sm font-semibold text-foreground">5.0</span>
              <span className="text-xs text-muted-foreground">(128 Reviews)</span>
              <Badge variant="outline" className="ml-2 text-[10px] border-green-500/30 text-green-600 bg-green-50">
                ● In Stock
              </Badge>
            </div>

            {/* Price Block */}
            <div className="mt-5 rounded-xl border border-border bg-card p-5">
              <div className="flex items-baseline gap-3">
                <span className="text-3xl font-extrabold text-foreground">${product.price.toFixed(2)}</span>
                {product.originalPrice && (
                  <span className="text-lg text-muted-foreground line-through">${product.originalPrice.toFixed(2)}</span>
                )}
              </div>
              {savings > 0 && (
                <p className="mt-1.5 text-sm font-semibold text-green-600">
                  You save ${savings.toFixed(2)} ({discount}% off)
                </p>
              )}
            </div>

            {/* Description */}
            <p className="mt-5 text-sm text-muted-foreground leading-relaxed">
              {product.description}
            </p>

            {/* CTA Buttons */}
            <div className="mt-6 space-y-3">
              <Button
                size="lg"
                className="w-full rounded-xl py-6 text-base font-bold shadow-lg shadow-primary/20"
                onClick={() => {
                  addToCart(product);
                  navigate("/checkout");
                }}
              >
                Buy Now — ${product.price.toFixed(2)}
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>

              <div className="grid grid-cols-2 gap-3">
                <Button
                  variant="outline"
                  className="rounded-xl py-5 text-sm font-semibold border-green-500/30 text-green-700 hover:bg-green-50 hover:text-green-800"
                  onClick={handleWhatsApp}
                >
                  <MessageCircle className="mr-2 h-4 w-4" />
                  Buy on WhatsApp
                </Button>
                <Button
                  variant="outline"
                  className="rounded-xl py-5 text-sm font-semibold border-primary/30 text-primary hover:bg-primary/5"
                  onClick={handleTelegram}
                >
                  <Send className="mr-2 h-4 w-4" />
                  Buy on Telegram
                </Button>
              </div>
            </div>

            {/* Delivery Info */}
            <div className="mt-6 space-y-2.5 rounded-xl border border-border bg-muted/30 p-4">
              <DeliveryRow icon={Zap} text="Instant delivery — usually within 1-4 hours" />
              <DeliveryRow icon={ShieldCheck} text="7-day replacement guarantee included" />
              <DeliveryRow icon={Package} text="Setup guide & compliance documentation" />
              <DeliveryRow icon={Lock} text="SSL encrypted, secure credential handover" />
            </div>
          </div>
        </div>
      </section>

      {/* ── Product Features ── */}
      <section className="border-t border-border bg-card py-10 md:py-14">
        <div className="container">
          <div className="mb-8 text-center">
            <Badge variant="secondary" className="mb-3 text-[10px] font-bold uppercase tracking-widest">What You Get</Badge>
            <h2 className="text-xl font-extrabold text-foreground md:text-2xl">Product Features & Inclusions</h2>
            <p className="mt-2 text-sm text-muted-foreground max-w-xl mx-auto">Everything included with your purchase — no hidden fees, no surprises.</p>
          </div>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {product.features.map((f, i) => (
              <div key={f} className="group flex items-start gap-3.5 rounded-xl border border-border bg-background p-4 transition-all hover:border-primary/30 hover:shadow-sm animate-fade-in" style={{ animationDelay: `${i * 50}ms` }}>
                <div className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-primary/10">
                  <CheckCircle2 className="h-4 w-4 text-primary" />
                </div>
                <span className="text-sm font-medium text-foreground leading-snug">{f}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Product Details / Attributes ── */}
      <section className="border-t border-border py-10 md:py-14">
        <div className="container">
          <div className="mb-8 text-center">
            <Badge variant="secondary" className="mb-3 text-[10px] font-bold uppercase tracking-widest">Specifications</Badge>
            <h2 className="text-xl font-extrabold text-foreground md:text-2xl">Product Details</h2>
          </div>

          {/* Dynamic Attributes Table */}
          {product.attributes && Object.keys(product.attributes).length > 0 && (
            <div className="mb-8 overflow-hidden rounded-xl border border-border">
              <table className="w-full text-sm">
                <tbody>
                  {Object.entries(product.attributes).map(([key, value], i) => (
                    <tr key={key} className={i % 2 === 0 ? "bg-muted/30" : "bg-background"}>
                      <td className="px-5 py-3 font-semibold text-foreground w-1/3">{key}</td>
                      <td className="px-5 py-3 text-muted-foreground">{value}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            <DetailCard
              icon={BadgeCheck}
              title="Account Type"
              items={["Verified Business Manager", "Full Admin Access", "Meta Verified Status", "Ready-to-use immediately"]}
            />
            <DetailCard
              icon={Shield}
              title="Security & Compliance"
              items={["Anti-ban guide included", "Warm-up strategy provided", "SSL encrypted delivery", "Clean account history"]}
            />
            <DetailCard
              icon={Monitor}
              title="Delivery & Support"
              items={["Same-day delivery (1–4 hrs)", "Setup assistance included", "7-day replacement guarantee", "Priority customer support"]}
            />
          </div>
        </div>
      </section>

      {/* ── How to Payment ── */}
      <section className="border-t border-border bg-card py-10 md:py-14">
        <div className="container">
          <div className="mb-8 text-center">
            <Badge variant="secondary" className="mb-3 text-[10px] font-bold uppercase tracking-widest">Payment</Badge>
            <h2 className="text-xl font-extrabold text-foreground md:text-2xl">How to Make Payment</h2>
            <p className="mt-2 text-sm text-muted-foreground max-w-xl mx-auto">We accept cryptocurrency payments for secure, fast, and worldwide transactions.</p>
          </div>
          <div className="grid gap-5 md:grid-cols-3">
            <StepCard
              step={1}
              icon={CircleDollarSign}
              title="Choose Your Product"
              description="Select the product you want and click 'Buy Now' or contact us via WhatsApp / Telegram."
            />
            <StepCard
              step={2}
              icon={Wallet}
              title="Send Crypto Payment"
              description="Pay using USDT (TRC20), Bitcoin, or Ethereum to the wallet address provided at checkout."
            />
            <StepCard
              step={3}
              icon={MessageSquare}
              title="Confirm & Receive"
              description="Share your payment screenshot via WhatsApp or Telegram. We'll verify and deliver within 1-4 hours."
            />
          </div>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
            <PaymentBadge label="USDT (TRC20)" />
            <PaymentBadge label="Bitcoin (BTC)" />
            <PaymentBadge label="Ethereum (ETH)" />
            <PaymentBadge label="Other Crypto" />
          </div>
        </div>
      </section>

      {/* ── How We Give Access ── */}
      <section className="border-t border-border py-10 md:py-14">
        <div className="container">
          <div className="mb-8 text-center">
            <Badge variant="secondary" className="mb-3 text-[10px] font-bold uppercase tracking-widest">Delivery</Badge>
            <h2 className="text-xl font-extrabold text-foreground md:text-2xl">How We Deliver Your Account</h2>
            <p className="mt-2 text-sm text-muted-foreground max-w-xl mx-auto">A fully transparent, secure process from purchase to access.</p>
          </div>
          <div className="grid gap-5 md:grid-cols-4">
            <AccessStep
              step={1}
              icon={CreditCard}
              title="Payment Verified"
              description="Our team confirms your crypto payment within minutes."
            />
            <AccessStep
              step={2}
              icon={FileText}
              title="Account Prepared"
              description="We prepare your verified account with all necessary configurations."
            />
            <AccessStep
              step={3}
              icon={Download}
              title="Credentials Sent"
              description="Login credentials are sent via encrypted message on WhatsApp or Telegram."
            />
            <AccessStep
              step={4}
              icon={Headphones}
              title="Setup Support"
              description="Our team guides you through login, setup, and best practices."
            />
          </div>
        </div>
      </section>

      {/* ── Why Choose Us ── */}
      <section className="border-t border-border bg-card py-10 md:py-14">
        <div className="container">
          <div className="mb-8 text-center">
            <Badge variant="secondary" className="mb-3 text-[10px] font-bold uppercase tracking-widest">Why VBB Store</Badge>
            <h2 className="text-xl font-extrabold text-foreground md:text-2xl">Why Customers Choose Us</h2>
            <p className="mt-2 text-sm text-muted-foreground max-w-xl mx-auto">Trusted by 1,000+ advertisers worldwide for verified Meta accounts.</p>
          </div>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            <WhyCard icon={Award} title="Years of Experience" description="We've been serving advertisers for years with consistently high-quality verified Business Managers." />
            <WhyCard icon={ShieldCheck} title="7-Day Guarantee" description="Every purchase is covered by our replacement guarantee. If there's an issue, we replace it — no questions asked." />
            <WhyCard icon={Zap} title="Instant Delivery" description="Receive your account credentials within 1-4 hours after payment confirmation." />
            <WhyCard icon={Headphones} title="24/7 Support" description="Our support team is available around the clock via WhatsApp, Telegram, and Email." />
            <WhyCard icon={Globe} title="Global Service" description="We deliver worldwide with no geographic restrictions. Advertisers from any country can purchase with confidence." />
            <WhyCard icon={RefreshCcw} title="Replacement Policy" description="Accounts come with a full compliance and warm-up guide to minimize risk — plus a free replacement if needed." />
          </div>
        </div>
      </section>

      {/* ── Customer Reviews ── */}
      <section className="border-t border-border py-10 md:py-14">
        <div className="container">
          <div className="mb-8 text-center">
            <Badge variant="secondary" className="mb-3 text-[10px] font-bold uppercase tracking-widest">Testimonials</Badge>
            <h2 className="text-xl font-extrabold text-foreground md:text-2xl">What Our Customers Say</h2>
            <p className="mt-2 text-sm text-muted-foreground max-w-xl mx-auto">Real reviews from verified buyers who trust VBB Store.</p>
          </div>
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            <ReviewCard
              name="James W."
              role="Media Buyer, USA"
              rating={5}
              review="Best BM provider I've ever used. Account was delivered in under 2 hours and has been running strong for months. Highly recommend!"
              date="Jan 2026"
            />
            <ReviewCard
              name="Aisha K."
              role="E-commerce Owner, UAE"
              rating={5}
              review="The WhatsApp API account works flawlessly. Support team walked me through the entire setup. Will buy again for sure."
              date="Feb 2026"
            />
            <ReviewCard
              name="Lucas D."
              role="Agency Owner, Germany"
              rating={5}
              review="Bought 3 verified BMs for our agency. All delivered same day with compliance guides. Professional service from start to finish."
              date="Feb 2026"
            />
            <ReviewCard
              name="Sophie L."
              role="Dropshipper, France"
              rating={5}
              review="Replaced my banned BM within hours. The anti-ban guide they provide is incredibly helpful. Great value for money."
              date="Jan 2026"
            />
            <ReviewCard
              name="Rajesh M."
              role="Digital Marketer, India"
              rating={5}
              review="Smooth crypto payment process. Got my credentials via Telegram securely. Account was ready to use immediately. Top service!"
              date="Feb 2026"
            />
            <ReviewCard
              name="Elena V."
              role="Performance Marketer, UK"
              rating={5}
              review="I've tried many providers — VBB Store is the most reliable. Excellent quality accounts with real support behind them."
              date="Jan 2026"
            />
          </div>
        </div>
      </section>

      {/* ── Product FAQ ── */}
      <section className="border-t border-border bg-card py-10 md:py-14">
        <div className="container">
          <div className="mb-8 text-center">
            <Badge variant="secondary" className="mb-3 text-[10px] font-bold uppercase tracking-widest">FAQ</Badge>
            <h2 className="text-xl font-extrabold text-foreground md:text-2xl">Frequently Asked Questions</h2>
            <p className="mt-2 text-sm text-muted-foreground max-w-xl mx-auto">Common questions about {product.name}.</p>
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            <FaqItem
              question="What exactly will I receive after purchase?"
              answer="You'll receive full admin access credentials to a verified Business Manager account, including login details, setup guide, and compliance documentation — all delivered securely via WhatsApp or Telegram."
            />
            <FaqItem
              question="How long does delivery take?"
              answer="Most orders are delivered within 1–4 hours after payment confirmation. In rare cases, it may take up to 12 hours during peak demand."
            />
            <FaqItem
              question="What payment methods do you accept?"
              answer="We accept cryptocurrency payments including USDT (TRC20), Bitcoin (BTC), and Ethereum (ETH). Crypto ensures fast, secure, and borderless transactions."
            />
            <FaqItem
              question="Is there a guarantee or refund policy?"
              answer="Yes! Every purchase comes with a 7-day replacement guarantee. If your account has any issues within 7 days, we'll replace it free of charge — no questions asked."
            />
            <FaqItem
              question="Can I use this account for running ads immediately?"
              answer="Yes, all our verified accounts are ready to use. We also provide a warm-up strategy and anti-ban guide to help you start advertising safely."
            />
            <FaqItem
              question="Is my data and login information secure?"
              answer="Absolutely. We use SSL-encrypted channels for credential delivery and never store your login details after handover. Your privacy and security are our top priority."
            />
            <FaqItem
              question="What if my account gets restricted or banned?"
              answer="If your account is restricted within the guarantee period due to a quality issue, we provide a free replacement. Our anti-ban guide also helps minimize this risk."
            />
            <FaqItem
              question="How can I contact support after purchase?"
              answer="You can reach our 24/7 support team via WhatsApp, Telegram, or Email. We're always available to help with setup, troubleshooting, or any questions."
            />
          </div>
        </div>
      </section>

      {/* Related Products */}
      {related.length > 0 && (
        <section className="border-t border-border bg-card py-10 md:py-14">
          <div className="container">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-bold text-foreground md:text-xl">Related Products</h2>
              <Link to="/shop" className="text-sm font-semibold text-primary hover:underline">
                View All
              </Link>
            </div>
            <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
              {related.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          </div>
        </section>
      )}

      <Footer />
      <FloatingContact />
    </div>
  );
};

/* ─── Sub-components ─── */

const TrustItem = ({ icon: Icon, label }: { icon: React.ElementType; label: string }) => (
  <div className="flex flex-col items-center gap-2 rounded-xl border border-border bg-card p-3 text-center">
    <Icon className="h-5 w-5 text-primary" />
    <span className="text-[11px] font-semibold text-muted-foreground">{label}</span>
  </div>
);

const DeliveryRow = ({ icon: Icon, text }: { icon: React.ElementType; text: string }) => (
  <div className="flex items-center gap-2.5 text-sm text-muted-foreground">
    <Icon className="h-4 w-4 shrink-0 text-primary" />
    <span>{text}</span>
  </div>
);

const DetailCard = ({ icon: Icon, title, items }: { icon: React.ElementType; title: string; items: string[] }) => (
  <div className="rounded-xl border border-border bg-card p-5 transition-all hover:border-primary/20 hover:shadow-sm">
    <div className="mb-4 flex items-center gap-3">
      <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10">
        <Icon className="h-5 w-5 text-primary" />
      </div>
      <h3 className="text-sm font-bold text-foreground">{title}</h3>
    </div>
    <ul className="space-y-2.5">
      {items.map((item) => (
        <li key={item} className="flex items-start gap-2 text-sm text-muted-foreground">
          <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-green-500" />
          {item}
        </li>
      ))}
    </ul>
  </div>
);

const StepCard = ({ step, icon: Icon, title, description }: { step: number; icon: React.ElementType; title: string; description: string }) => (
  <div className="relative rounded-xl border border-border bg-background p-6 text-center transition-all hover:border-primary/20 hover:shadow-sm">
    <div className="absolute -top-3 left-1/2 -translate-x-1/2 flex h-7 w-7 items-center justify-center rounded-full bg-primary text-[11px] font-bold text-primary-foreground shadow-md">
      {step}
    </div>
    <div className="mx-auto mt-3 mb-3 flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10">
      <Icon className="h-6 w-6 text-primary" />
    </div>
    <h3 className="text-sm font-bold text-foreground mb-1.5">{title}</h3>
    <p className="text-xs text-muted-foreground leading-relaxed">{description}</p>
  </div>
);

const PaymentBadge = ({ label }: { label: string }) => (
  <div className="flex items-center gap-2 rounded-full border border-border bg-background px-4 py-2">
    <Wallet className="h-3.5 w-3.5 text-primary" />
    <span className="text-xs font-semibold text-foreground">{label}</span>
  </div>
);

const AccessStep = ({ step, icon: Icon, title, description }: { step: number; icon: React.ElementType; title: string; description: string }) => (
  <div className="relative rounded-xl border border-border bg-card p-5 text-center transition-all hover:border-primary/20 hover:shadow-sm">
    <div className="mx-auto mb-3 flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 text-sm font-bold text-primary">
      {step}
    </div>
    <div className="mx-auto mb-3 flex h-10 w-10 items-center justify-center rounded-xl bg-muted">
      <Icon className="h-5 w-5 text-primary" />
    </div>
    <h3 className="text-sm font-bold text-foreground mb-1">{title}</h3>
    <p className="text-xs text-muted-foreground leading-relaxed">{description}</p>
  </div>
);

const WhyCard = ({ icon: Icon, title, description }: { icon: React.ElementType; title: string; description: string }) => (
  <div className="rounded-xl border border-border bg-background p-5 transition-all hover:border-primary/20 hover:shadow-sm">
    <div className="mb-3 flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10">
      <Icon className="h-5 w-5 text-primary" />
    </div>
    <h3 className="text-sm font-bold text-foreground mb-1.5">{title}</h3>
    <p className="text-xs text-muted-foreground leading-relaxed">{description}</p>
  </div>
);

const ReviewCard = ({ name, role, rating, review, date }: { name: string; role: string; rating: number; review: string; date: string }) => (
  <div className="rounded-xl border border-border bg-card p-5 transition-all hover:border-primary/20 hover:shadow-sm">
    <div className="flex items-center gap-0.5 mb-3">
      {[...Array(rating)].map((_, i) => (
        <Star key={i} className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
      ))}
    </div>
    <p className="text-sm text-muted-foreground leading-relaxed mb-4">"{review}"</p>
    <div className="flex items-center justify-between border-t border-border pt-3">
      <div>
        <p className="text-sm font-bold text-foreground">{name}</p>
        <p className="text-[11px] text-muted-foreground">{role}</p>
      </div>
      <span className="text-[10px] font-medium text-muted-foreground">{date}</span>
    </div>
  </div>
);

const FaqItem = ({ question, answer }: { question: string; answer: string }) => (
  <details className="group rounded-xl border border-border bg-background p-4 transition-all hover:border-primary/20 [&[open]]:border-primary/20 [&[open]]:shadow-sm">
    <summary className="flex cursor-pointer items-center justify-between gap-3 text-sm font-bold text-foreground list-none [&::-webkit-details-marker]:hidden">
      <div className="flex items-center gap-2.5">
        <HelpCircle className="h-4 w-4 shrink-0 text-primary" />
        {question}
      </div>
      <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground transition-transform group-open:rotate-90" />
    </summary>
    <p className="mt-3 pl-6.5 text-sm text-muted-foreground leading-relaxed">{answer}</p>
  </details>
);

export default ProductDetail;