import Header from "@/components/Header";
import Hero from "@/components/Hero";
import Features from "@/components/Features";
import ProductGrid from "@/components/ProductGrid";
import WhyVerifiedBM from "@/components/WhyVerifiedBM";
import WhatsAppAPI from "@/components/WhatsAppAPI";
import OurServices from "@/components/OurServices";
import WhyChooseUs from "@/components/WhyChooseUs";
import WorkSamples from "@/components/WorkSamples";
import Reviews from "@/components/Reviews";
import ScaleAdvertising from "@/components/ScaleAdvertising";
import TopAdvertisers from "@/components/TopAdvertisers";
import DistinctBenefits from "@/components/DistinctBenefits";
import FAQ from "@/components/FAQ";
import AboutUs from "@/components/AboutUs";
import Location from "@/components/Location";
import FloatingContact from "@/components/FloatingContact";
import Footer from "@/components/Footer";
import { usePageSEO } from "@/hooks/use-page-seo";

const Index = () => {
  usePageSEO({
    title: "Buy Verified BM, WhatsApp API & Ad Accounts | VBB STORE",
    description: "Buy verified Facebook Business Manager, WhatsApp API, TikTok Ads, and Google Ads accounts. Real documents, fast delivery, 7-day guarantee.",
    path: "/",
  });
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        <Hero />
        <Features />
        <ProductGrid />
        <WhyVerifiedBM />
        <WhatsAppAPI />
        <OurServices />
        <WhyChooseUs />
        <ScaleAdvertising />
        <TopAdvertisers />
        <DistinctBenefits />
        <WorkSamples />
        <Reviews />
        <FAQ />
        <AboutUs />
        <Location />
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
};

export default Index;
