import { useState, useEffect, useCallback } from "react";
import { Link } from "react-router-dom";
import { Copy, Check, MessageCircle, Send, Shield, Truck, Headphones, ShoppingBag, ArrowLeft, CreditCard, Loader2 } from "lucide-react";
import { useCart } from "@/context/CartContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { getProductImage } from "@/data/productImages";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import FloatingContact from "@/components/FloatingContact";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

const walletColors = [
  "from-green-500 to-green-600", "from-orange-500 to-orange-600", "from-purple-500 to-purple-600",
  "from-blue-500 to-blue-600", "from-pink-500 to-pink-600", "from-yellow-500 to-yellow-600",
  "from-teal-500 to-teal-600", "from-red-500 to-red-600",
];

const CheckoutPage = () => {
  const { items, totalPrice, totalItems, clearCart } = useCart();
  const [copied, setCopied] = useState<string | null>(null);
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", telegram: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [touched, setTouched] = useState<Record<string, boolean>>({});
  const [validatedPrice, setValidatedPrice] = useState<number | null>(null);
  const [priceLoading, setPriceLoading] = useState(true);
  const [priceMismatch, setPriceMismatch] = useState(false);
  const [wallets, setWallets] = useState<{ currency: string; key: string; address: string; color: string }[]>([]);

  // Validate prices against database on mount
  const validatePrices = useCallback(async () => {
    if (items.length === 0) { setPriceLoading(false); return; }
    try {
      const productIds = items.map(i => i.product.id);
      const { data, error } = await supabase
        .from("products")
        .select("id, price, original_price")
        .in("id", productIds);
      if (error || !data) {
        toast.error("Could not verify prices. Please try again.");
        setPriceLoading(false);
        return;
      }
      const dbPriceMap = new Map(data.map(p => [p.id, p.price]));
      const serverTotal = items.reduce((sum, i) => {
        const dbPrice = dbPriceMap.get(i.product.id);
        return sum + (dbPrice ?? i.product.price) * i.quantity;
      }, 0);
      setValidatedPrice(serverTotal);
      if (Math.abs(serverTotal - totalPrice) > 0.01) {
        setPriceMismatch(true);
        toast.warning("Some prices have been updated. The total has been corrected.");
      }
    } catch {
      toast.error("Price validation failed.");
    }
    setPriceLoading(false);
  }, [items, totalPrice]);

  useEffect(() => { validatePrices(); }, [validatePrices]);

  // Fetch wallet addresses from site_content
  useEffect(() => {
    const fetchWallets = async () => {
      const { data } = await supabase
        .from("site_content")
        .select("key, value")
        .like("key", "wallet_%");
      if (data && data.length > 0) {
        setWallets(
          data.map((r: any, i: number) => ({
            currency: r.key.replace("wallet_", "").toUpperCase(),
            key: r.key,
            address: r.value || "",
            color: walletColors[i % walletColors.length],
          }))
        );
      }
    };
    fetchWallets();
  }, []);

  const displayTotal = validatedPrice ?? totalPrice;

  const validate = (f = form) => {
    const errs: Record<string, string> = {};
    if (!f.name.trim()) errs.name = "Full name is required";
    if (!f.email.trim()) errs.email = "Email is required";
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(f.email)) errs.email = "Enter a valid email";
    return errs;
  };

  const handleBlur = (field: string) => {
    setTouched((t) => ({ ...t, [field]: true }));
    setErrors(validate());
  };

  const handleFieldChange = (field: string, value: string) => {
    const updated = { ...form, [field]: value };
    setForm(updated);
    if (touched[field]) setErrors(validate(updated));
  };

  const copyAddress = (address: string, currency: string) => {
    navigator.clipboard.writeText(address);
    setCopied(currency);
    toast.success(`${currency} address copied!`);
    setTimeout(() => setCopied(null), 2000);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const errs = validate();
    setErrors(errs);
    setTouched({ name: true, email: true });
    if (Object.keys(errs).length > 0) return;
    setSubmitted(true);
    clearCart();
  };

  if (items.length === 0 && !submitted) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container flex flex-col items-center py-24 text-center">
          <div className="mb-6 flex h-20 w-20 items-center justify-center rounded-2xl bg-muted">
            <ShoppingBag className="h-10 w-10 text-muted-foreground" />
          </div>
          <h1 className="mb-3 text-2xl font-extrabold text-foreground">Your cart is empty</h1>
          <p className="mb-6 text-muted-foreground">Add some products before checking out.</p>
          <Link to="/#products">
            <Button className="rounded-xl shadow-md shadow-primary/20 px-8">
              <ArrowLeft className="mr-2 h-4 w-4" /> Browse Products
            </Button>
          </Link>
        </div>
        <Footer />
      </div>
    );
  }

  if (submitted) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container flex flex-col items-center py-24 text-center">
          <div className="mb-6 flex h-20 w-20 items-center justify-center rounded-2xl bg-gradient-to-br from-green-500 to-green-600 shadow-lg shadow-green-500/25">
            <Check className="h-10 w-10 text-white" />
          </div>
          <h1 className="mb-3 text-3xl font-extrabold text-foreground">Order Placed Successfully!</h1>
          <p className="mb-8 max-w-md text-muted-foreground leading-relaxed">
            Thank you for your order. Please send the cryptocurrency payment, then contact us via WhatsApp or Telegram to confirm and receive your account credentials.
          </p>
          <div className="flex gap-3">
            <a href="https://wa.me/8801302669333" target="_blank" rel="noopener noreferrer">
              <Button className="rounded-xl bg-green-500 text-white shadow-lg shadow-green-500/25 hover:bg-green-600 px-6">
                <MessageCircle className="mr-2 h-4 w-4" /> WhatsApp
              </Button>
            </a>
            <a href="https://t.me/Verifiedbmbuy" target="_blank" rel="noopener noreferrer">
              <Button className="rounded-xl shadow-md shadow-primary/20 px-6">
                <Send className="mr-2 h-4 w-4" /> Telegram
              </Button>
            </a>
          </div>
          <Link to="/" className="mt-6">
            <Button variant="link" className="text-muted-foreground hover:text-foreground">
              <ArrowLeft className="mr-2 h-4 w-4" /> Back to Home
            </Button>
          </Link>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container py-10 md:py-14">
        {/* Header */}
        <div className="mb-8">
          <Link to="/cart" className="mb-4 inline-flex items-center gap-2 text-sm font-medium text-muted-foreground hover:text-primary transition-colors">
            <ArrowLeft className="h-4 w-4" /> Back to Cart
          </Link>
          <h1 className="text-3xl font-extrabold text-foreground md:text-4xl">Checkout</h1>
          <p className="mt-1 text-muted-foreground">{totalItems} item{totalItems > 1 ? "s" : ""} • Total: {priceLoading ? "..." : `$${displayTotal}`}</p>
        </div>

        <div className="grid gap-8 lg:grid-cols-5">
          {priceMismatch && (
            <div className="lg:col-span-5 rounded-xl border border-yellow-300 bg-yellow-50 px-4 py-3 text-sm text-yellow-800 dark:border-yellow-700 dark:bg-yellow-900/20 dark:text-yellow-300">
              ⚠️ Some product prices have changed since you added them to cart. The total has been updated to reflect current prices.
            </div>
          )}
          {/* Left column */}
          <div className="lg:col-span-3 space-y-6">
            {/* Order Summary */}
            <div className="rounded-2xl border border-border bg-card overflow-hidden">
              <div className="border-b border-border bg-muted/30 px-6 py-4">
                <h2 className="text-lg font-bold text-foreground">Order Summary</h2>
              </div>
              <div className="divide-y divide-border">
                {items.map(({ product, quantity }) => (
                  <div key={product.id} className="flex items-center gap-4 p-5">
                    <div className="h-16 w-16 shrink-0 overflow-hidden rounded-xl bg-muted/50">
                      <img
                        src={getProductImage(product.category)}
                        alt={product.name}
                        className="h-full w-full object-cover"
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-[11px] font-bold uppercase tracking-widest text-primary">{product.category}</p>
                      <h3 className="font-bold text-foreground truncate">{product.name}</h3>
                      <p className="text-xs text-muted-foreground">Qty: {quantity}</p>
                    </div>
                    <div className="text-right">
                      {product.originalPrice && (
                        <p className="text-xs text-muted-foreground line-through">${product.originalPrice * quantity}</p>
                      )}
                      <p className="text-lg font-extrabold text-foreground">${product.price * quantity}</p>
                    </div>
                  </div>
                ))}
              </div>
              {/* Total */}
              <div className="border-t-2 border-primary/20 bg-primary/[0.03] px-6 py-4">
                <div className="flex items-center justify-between">
                  <span className="text-lg font-bold text-foreground">Total</span>
                  <span className="text-2xl font-extrabold text-foreground">${displayTotal} <span className="text-sm font-medium text-muted-foreground">USD</span></span>
                </div>
                {items.some(i => i.product.originalPrice) && (
                  <p className="mt-1 text-xs font-bold text-green-600">
                    You save ${items.reduce((s, { product: p, quantity: q }) => s + ((p.originalPrice || p.price) - p.price) * q, 0).toFixed(2)}
                  </p>
                )}
              </div>
            </div>

            {/* Crypto Wallets */}
            <div className="rounded-2xl border border-border bg-card overflow-hidden">
              <div className="border-b border-border bg-muted/30 px-6 py-4">
                <div className="flex items-center gap-3">
                  <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-primary to-blue-600 shadow-sm">
                    <CreditCard className="h-4 w-4 text-white" />
                  </div>
                  <div>
                    <h2 className="text-lg font-bold text-foreground">Pay with Cryptocurrency</h2>
                    <p className="text-xs text-muted-foreground">Send exactly <strong className="text-foreground">${displayTotal}</strong> to one of these wallets</p>
                  </div>
                </div>
              </div>
              <div className="p-5 space-y-3">
                {wallets.filter((w) => w.address).map((w) => (
                  <div key={w.currency} className="group rounded-xl border border-border bg-muted/30 p-4 transition-all hover:border-primary/20 hover:shadow-sm">
                    <div className="mb-2 flex items-center gap-2">
                      <div className={`flex h-7 w-7 items-center justify-center rounded-lg bg-gradient-to-br ${w.color} shadow-sm`}>
                        <span className="text-[10px] font-extrabold text-white">₿</span>
                      </div>
                      <span className="text-sm font-bold text-foreground">{w.currency}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <code className="flex-1 truncate rounded-lg bg-background px-3 py-2 text-xs text-muted-foreground border border-border">{w.address}</code>
                      <Button
                        variant="outline"
                        size="sm"
                        className="shrink-0 rounded-lg"
                        onClick={() => copyAddress(w.address, w.currency)}
                      >
                        {copied === w.currency ? (
                          <Check className="h-3.5 w-3.5 text-green-500" />
                        ) : (
                          <Copy className="h-3.5 w-3.5" />
                        )}
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Trust badges */}
            <div className="flex justify-center gap-4">
              {[
                { icon: Shield, label: "100% Safe" },
                { icon: Truck, label: "Instant Delivery" },
                { icon: Headphones, label: "24/7 Support" },
              ].map(({ icon: Icon, label }) => (
                <div key={label} className="flex items-center gap-2 rounded-xl border border-border bg-card px-4 py-3">
                  <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-primary to-blue-600 shadow-sm">
                    <Icon className="h-4 w-4 text-white" />
                  </div>
                  <span className="text-xs font-bold text-muted-foreground">{label}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Right column – Form */}
          <div className="lg:col-span-2">
            <div className="sticky top-20">
              <form onSubmit={handleSubmit} className="rounded-2xl border border-border bg-card overflow-hidden">
                <div className="border-b border-border bg-muted/30 px-6 py-4">
                  <h2 className="text-lg font-bold text-foreground">Your Details</h2>
                  <p className="text-xs text-muted-foreground">We'll send your account credentials here</p>
                </div>
                <div className="p-6 space-y-4">
                  <div>
                    <Label htmlFor="name" className="text-sm font-medium">Full Name <span className="text-destructive">*</span></Label>
                    <Input
                      id="name"
                      value={form.name}
                      onChange={(e) => handleFieldChange("name", e.target.value)}
                      onBlur={() => handleBlur("name")}
                      placeholder="Your full name"
                      className={`mt-1.5 rounded-xl ${touched.name && errors.name ? "border-destructive" : ""}`}
                    />
                    {touched.name && errors.name && <p className="mt-1 text-xs font-medium text-destructive">{errors.name}</p>}
                  </div>
                  <div>
                    <Label htmlFor="email" className="text-sm font-medium">Email Address <span className="text-destructive">*</span></Label>
                    <Input
                      id="email"
                      type="email"
                      value={form.email}
                      onChange={(e) => handleFieldChange("email", e.target.value)}
                      onBlur={() => handleBlur("email")}
                      placeholder="your@email.com"
                      className={`mt-1.5 rounded-xl ${touched.email && errors.email ? "border-destructive" : ""}`}
                    />
                    {touched.email && errors.email && <p className="mt-1 text-xs font-medium text-destructive">{errors.email}</p>}
                  </div>
                  <div>
                    <Label htmlFor="telegram" className="text-sm font-medium">Telegram / WhatsApp</Label>
                    <Input
                      id="telegram"
                      value={form.telegram}
                      onChange={(e) => handleFieldChange("telegram", e.target.value)}
                      placeholder="@username or phone number"
                      className="mt-1.5 rounded-xl"
                    />
                  </div>
                </div>
                <div className="border-t border-border bg-muted/30 p-6">
                  <Button type="submit" disabled={priceLoading} className="w-full rounded-xl py-5 font-bold shadow-lg shadow-primary/25" size="lg">
                    {priceLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                    Place Order – ${displayTotal}
                  </Button>
                  <p className="mt-3 flex items-center justify-center gap-1.5 text-xs text-muted-foreground">
                    <Check className="h-3.5 w-3.5 text-green-500" />
                    <span>Verified Account • Delivered Same Day</span>
                  </p>
                </div>
              </form>

              {/* Quick contact */}
              <div className="mt-4 flex gap-2">
                <a href="https://wa.me/8801302669333" target="_blank" rel="noopener noreferrer" className="flex-1">
                  <Button variant="outline" className="w-full rounded-xl py-5 font-bold">
                    <MessageCircle className="mr-2 h-4 w-4" /> WhatsApp
                  </Button>
                </a>
                <a href="https://t.me/Verifiedbmbuy" target="_blank" rel="noopener noreferrer" className="flex-1">
                  <Button variant="outline" className="w-full rounded-xl py-5 font-bold">
                    <Send className="mr-2 h-4 w-4" /> Telegram
                  </Button>
                </a>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
};

export default CheckoutPage;
