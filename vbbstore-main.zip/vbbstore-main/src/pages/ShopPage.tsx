import { useState } from "react";
import { categories } from "@/data/products";
import { useProducts } from "@/hooks/useProducts";
import ProductCard from "@/components/ProductCard";
import { Button } from "@/components/ui/button";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import FloatingContact from "@/components/FloatingContact";

import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { usePageSEO } from "@/hooks/use-page-seo";

const ShopPage = () => {
  const [active, setActive] = useState<string>("All");
  const [search, setSearch] = useState("");
  
  const { products } = useProducts();

  usePageSEO({
    title: "Shop Verified BM, WhatsApp API & Ad Accounts | VBB STORE",
    description: "Buy verified Business Manager, WhatsApp API, Facebook Ads, TikTok Ads, Google Ads accounts and more. Fast delivery and 7-day guarantee.",
    path: "/shop",
  });

  const filtered = products
    .filter((p) => active === "All" || p.category === active)
    .filter((p) => p.name.toLowerCase().includes(search.toLowerCase()) || p.description.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        {/* Shop Hero */}
        <section className="relative overflow-hidden bg-gradient-to-br from-primary via-primary to-blue-700 py-16 md:py-20">
          <div className="absolute inset-0">
            <div className="absolute -left-32 -top-32 h-80 w-80 rounded-full bg-blue-400/20 blur-3xl" />
            <div className="absolute -bottom-16 -right-16 h-64 w-64 rounded-full bg-blue-300/15 blur-3xl" />
          </div>
          <div className="container relative z-10 text-center">
            <p className="mb-3 text-sm font-bold uppercase tracking-widest text-white/60">Browse & Buy</p>
            <h1 className="mb-4 text-4xl font-extrabold text-white md:text-5xl lg:text-6xl">
              Our Products
            </h1>
            <p className="mx-auto mb-8 max-w-xl text-lg text-white/70">
              Premium verified Meta accounts, WhatsApp API access, and more. All with instant delivery and 7-day replacement guarantee.
            </p>
            <div className="mx-auto max-w-md relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <Input
                placeholder="Search products..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="h-12 rounded-xl bg-white pl-12 text-foreground shadow-xl border-0"
              />
            </div>
          </div>
        </section>

        {/* Products */}
        <section className="py-12 md:py-16">
          <div className="container">
            <div className="mb-8 flex flex-wrap justify-center gap-2 animate-fade-in">
              {categories.map((cat) => (
                <Button
                  key={cat}
                  variant={active === cat ? "default" : "outline"}
                  size="sm"
                  onClick={() => setActive(cat)}
                  className={`rounded-full px-5 font-medium transition-all ${
                    active === cat ? "shadow-md shadow-primary/25" : "hover:bg-primary/5"
                  }`}
                >
                  {cat}
                </Button>
              ))}
            </div>

            {filtered.length === 0 ? (
              <div className="py-20 text-center">
                <p className="text-lg font-semibold text-foreground">No products found</p>
                <p className="text-muted-foreground">Try a different search or category.</p>
              </div>
            ) : (
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 animate-fade-in">
                {filtered.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            )}

            <div className="mt-12 text-center text-sm text-muted-foreground">
              Showing {filtered.length} of {products.length} products
            </div>
          </div>
        </section>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
};

export default ShopPage;
