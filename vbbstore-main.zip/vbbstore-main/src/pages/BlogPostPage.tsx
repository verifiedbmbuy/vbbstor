import { useParams, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { ArrowLeft, Clock, User, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import FloatingContact from "@/components/FloatingContact";
import { usePageSEO } from "@/hooks/use-page-seo";
import { useEffect, useState } from "react";

interface BlogPost {
  id: string;
  slug: string;
  title: string;
  excerpt: string;
  content: string;
  category: string;
  date: string;
  read_time: string | null;
  author: string | null;
  published: boolean | null;
}

const BlogPostPage = () => {
  const { slug } = useParams();
  const [post, setPost] = useState<BlogPost | null>(null);
  const [related, setRelated] = useState<BlogPost[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchPost = async () => {
      setLoading(true);
      const { data } = await supabase
        .from("blog_posts")
        .select("*")
        .eq("slug", slug || "")
        .eq("published", true)
        .maybeSingle();
      setPost(data as BlogPost | null);

      if (data) {
        const { data: relatedData } = await supabase
          .from("blog_posts")
          .select("*")
          .eq("published", true)
          .neq("id", data.id)
          .limit(3);
        setRelated((relatedData as BlogPost[]) || []);
      }
      setLoading(false);
    };
    fetchPost();
  }, [slug]);

  usePageSEO({
    title: post ? `${post.title} | VBB STORE Blog` : "Blog | VBB STORE",
    description: post ? post.excerpt.slice(0, 155) : "Read our latest blog posts at VBB STORE.",
    path: `/blog/${slug || ""}`,
  });

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container py-20 text-center">
          <div className="h-8 w-8 mx-auto animate-spin rounded-full border-4 border-primary border-t-transparent" />
        </div>
        <Footer />
      </div>
    );
  }

  if (!post) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container py-20 text-center">
          <h1 className="text-2xl font-bold text-foreground">Post not found</h1>
          <Link to="/blog"><Button className="mt-4">Back to Blog</Button></Link>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        {/* Article Header */}
        <section className="relative overflow-hidden bg-gradient-to-br from-primary via-primary to-blue-700 py-16 md:py-20">
          <div className="absolute inset-0">
            <div className="absolute -left-32 -top-32 h-80 w-80 rounded-full bg-blue-400/20 blur-3xl" />
          </div>
          <div className="container relative z-10 mx-auto max-w-3xl">
            <Link to="/blog" className="mb-6 inline-flex items-center gap-2 text-sm text-white/60 hover:text-white transition-colors">
              <ArrowLeft className="h-4 w-4" /> Back to Blog
            </Link>
            <p className="mb-3 text-sm font-bold uppercase tracking-widest text-white/50">{post.category}</p>
            <h1 className="mb-6 text-3xl font-extrabold text-white md:text-4xl lg:text-5xl leading-tight">
              {post.title}
            </h1>
            <div className="flex flex-wrap items-center gap-4 text-sm text-white/60">
              <span className="flex items-center gap-1.5"><User className="h-4 w-4" /> {post.author}</span>
              <span className="flex items-center gap-1.5"><Calendar className="h-4 w-4" /> {new Date(post.date).toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })}</span>
              <span className="flex items-center gap-1.5"><Clock className="h-4 w-4" /> {post.read_time}</span>
            </div>
          </div>
        </section>

        {/* Article Content */}
        <section className="py-12 md:py-16">
          <div className="container mx-auto max-w-3xl">
            <div className="prose prose-lg max-w-none">
              {post.content.split("\n\n").map((paragraph, i) => {
                if (paragraph.startsWith("**") && paragraph.endsWith("**")) {
                  return <h3 key={i} className="mt-8 mb-4 text-xl font-bold text-foreground">{paragraph.replace(/\*\*/g, "")}</h3>;
                }
                if (paragraph.startsWith("**")) {
                  return <h3 key={i} className="mt-8 mb-4 text-xl font-bold text-foreground">{paragraph.replace(/\*\*/g, "")}</h3>;
                }
                if (paragraph.startsWith("- ")) {
                  return (
                    <ul key={i} className="my-4 space-y-2">
                      {paragraph.split("\n").map((line, j) => (
                        <li key={j} className="flex items-start gap-2 text-muted-foreground">
                          <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                          <span>{line.replace(/^- /, "").replace(/\*\*/g, "")}</span>
                        </li>
                      ))}
                    </ul>
                  );
                }
                if (/^\d\./.test(paragraph)) {
                  return (
                    <ol key={i} className="my-4 space-y-2 list-decimal pl-5">
                      {paragraph.split("\n").map((line, j) => (
                        <li key={j} className="text-muted-foreground">{line.replace(/^\d+\.\s*/, "").replace(/\*\*/g, "")}</li>
                      ))}
                    </ol>
                  );
                }
                return <p key={i} className="mb-4 text-muted-foreground leading-relaxed">{paragraph}</p>;
              })}
            </div>

            {/* Related Posts */}
            {related.length > 0 && (
              <div className="mt-16 border-t border-border pt-12">
                <h2 className="mb-6 text-2xl font-bold text-foreground">Related Articles</h2>
                <div className="grid gap-6 sm:grid-cols-3">
                  {related.map((r) => (
                    <Link key={r.id} to={`/blog/${r.slug}`} className="group rounded-2xl border border-border bg-card p-5 transition-all hover:-translate-y-1 hover:shadow-lg hover:border-primary/20">
                      <p className="mb-2 text-xs font-bold uppercase tracking-wider text-primary">{r.category}</p>
                      <h3 className="mb-2 text-sm font-bold text-foreground line-clamp-2 group-hover:text-primary transition-colors">{r.title}</h3>
                      <p className="text-xs text-muted-foreground">{r.read_time}</p>
                    </Link>
                  ))}
                </div>
              </div>
            )}
          </div>
        </section>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
};

export default BlogPostPage;
