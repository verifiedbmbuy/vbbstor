import Header from "@/components/Header";
import Footer from "@/components/Footer";
import FloatingContact from "@/components/FloatingContact";
import FAQ from "@/components/FAQ";
import { useScrollReveal } from "@/hooks/use-scroll-reveal";
import { HelpCircle, ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { usePageSEO } from "@/hooks/use-page-seo";

const FAQPage = () => {
  const { ref, visible } = useScrollReveal();

  usePageSEO({
    title: "FAQ – Common Questions Answered | VBB STORE",
    description: "Got questions about verified BM, WhatsApp API, payments, or delivery? Find clear answers here.",
    path: "/faq",
  });

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        {/* Hero */}
        <section className="relative overflow-hidden bg-gradient-to-br from-primary via-primary to-blue-700 py-20 md:py-28">
          <div className="absolute inset-0">
            <div className="absolute -right-32 -top-32 h-96 w-96 rounded-full bg-blue-400/20 blur-3xl" />
            <div className="absolute -bottom-20 -left-20 h-72 w-72 rounded-full bg-blue-300/15 blur-3xl" />
          </div>
          <div className="container relative z-10 text-center">
            <div className="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-2xl bg-white/10 backdrop-blur-sm">
              <HelpCircle className="h-8 w-8 text-white" />
            </div>
            <h1 className="mb-4 text-4xl font-extrabold text-white md:text-5xl lg:text-6xl">Frequently Asked Questions</h1>
            <p className="mx-auto max-w-2xl text-lg text-white/70">
              Find answers to the most common questions about our verified BM accounts and WhatsApp API services.
            </p>
          </div>
        </section>

        {/* FAQ Component */}
        <FAQ />

        {/* CTA */}
        <section className="py-16 md:py-24 bg-gradient-to-b from-muted/30 to-muted/80" ref={ref}>
          <div className={`container text-center transition-all duration-700 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}>
            <h2 className="mb-4 text-3xl font-extrabold text-foreground md:text-4xl">Still Have Questions?</h2>
            <p className="mx-auto mb-8 max-w-xl text-muted-foreground">
              Our team is available 24/7 to answer any questions you may have.
            </p>
            <div className="flex flex-col items-center gap-4 sm:flex-row sm:justify-center">
              <Link to="/contact">
                <Button size="lg" className="rounded-xl shadow-lg shadow-primary/25 h-12 px-8 font-bold">
                  Contact Us <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
              <Link to="/shop">
                <Button size="lg" variant="outline" className="rounded-xl h-12 px-8 font-bold">
                  Browse Products
                </Button>
              </Link>
            </div>
          </div>
        </section>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
};

export default FAQPage;
