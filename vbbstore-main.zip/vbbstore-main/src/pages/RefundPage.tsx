import Header from "@/components/Header";
import Footer from "@/components/Footer";
import FloatingContact from "@/components/FloatingContact";
import { useScrollReveal } from "@/hooks/use-scroll-reveal";
import { RotateCcw, CheckCircle2, XCircle, Clock, MessageCircle, AlertCircle, FileCheck, ArrowRight } from "lucide-react";
import { useEffect } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { usePageSEO } from "@/hooks/use-page-seo";

const eligible = [
  "Account becomes non-functional within 7 days of delivery",
  "Account was not as described in the product listing",
  "Account credentials are invalid upon delivery",
  "Verification status does not match the purchased tier",
];

const notEligible = [
  "Account restricted due to buyer's policy violations",
  "Account banned for running prohibited content",
  "Request made after the 7-day guarantee period",
  "Buyer shared credentials with unauthorized third parties",
  "Natural account aging or normal Meta policy updates",
];

const steps = [
  { icon: MessageCircle, title: "Contact Support", desc: "Reach out via WhatsApp or Telegram with your order details and issue description." },
  { icon: FileCheck, title: "Verification", desc: "Our team will verify the issue within 2-4 hours during business hours." },
  { icon: RotateCcw, title: "Replacement", desc: "Once verified, a replacement account is delivered within 24 hours." },
];

const RefundPage = () => {
  const { ref, visible } = useScrollReveal();
  const { ref: stepsRef, visible: stepsVisible } = useScrollReveal();

  usePageSEO({
    title: "Refund Policy | VBB STORE – 7-Day Replacement",
    description: "We replace any account that stops working within 7 days. No extra cost. Read how it works.",
    path: "/refund",
  });

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        {/* Hero */}
        <section className="relative overflow-hidden bg-gradient-to-br from-primary via-primary to-blue-700 py-20 md:py-28">
          <div className="absolute inset-0">
            <div className="absolute -right-32 -top-32 h-96 w-96 rounded-full bg-blue-400/20 blur-3xl" />
            <div className="absolute -bottom-20 -left-20 h-72 w-72 rounded-full bg-blue-300/15 blur-3xl" />
          </div>
          <div className="container relative z-10 text-center">
            <div className="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-2xl bg-white/10 backdrop-blur-sm">
              <RotateCcw className="h-8 w-8 text-white" />
            </div>
            <h1 className="mb-4 text-4xl font-extrabold text-white md:text-5xl lg:text-6xl">Refund Policy</h1>
            <p className="mx-auto max-w-2xl text-lg text-white/70">
              We stand behind every product with our 7-day replacement guarantee.
            </p>
          </div>
        </section>

        {/* Eligible / Not Eligible */}
        <section className="py-16 md:py-24" ref={ref}>
          <div className={`container mx-auto max-w-5xl transition-all duration-700 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}>
            <div className="mb-12 text-center">
              <p className="mb-3 text-sm font-bold uppercase tracking-widest text-primary">Our Guarantee</p>
              <h2 className="mb-4 text-3xl font-extrabold text-foreground md:text-4xl">Replacement Eligibility</h2>
              <p className="mx-auto max-w-2xl text-muted-foreground">
                Due to the digital nature of our products, we offer replacements instead of monetary refunds. Here's what qualifies:
              </p>
            </div>

            <div className="grid gap-8 md:grid-cols-2">
              {/* Eligible */}
              <div className="rounded-2xl border-2 border-green-500/20 bg-green-50/50 dark:bg-green-950/10 p-8">
                <div className="mb-6 flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-green-500 shadow-lg shadow-green-500/25">
                    <CheckCircle2 className="h-5 w-5 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-foreground">Eligible for Replacement</h3>
                </div>
                <ul className="space-y-3">
                  {eligible.map((item, i) => (
                    <li key={i} className="flex items-start gap-3 text-sm text-muted-foreground">
                      <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-green-500" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Not Eligible */}
              <div className="rounded-2xl border-2 border-destructive/20 bg-red-50/50 dark:bg-red-950/10 p-8">
                <div className="mb-6 flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-destructive shadow-lg shadow-destructive/25">
                    <XCircle className="h-5 w-5 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-foreground">Not Eligible</h3>
                </div>
                <ul className="space-y-3">
                  {notEligible.map((item, i) => (
                    <li key={i} className="flex items-start gap-3 text-sm text-muted-foreground">
                      <XCircle className="mt-0.5 h-4 w-4 shrink-0 text-destructive" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </section>

        {/* Process Steps */}
        <section className="py-16 md:py-24 bg-gradient-to-b from-muted/30 to-muted/80" ref={stepsRef}>
          <div className={`container mx-auto max-w-4xl transition-all duration-700 ${stepsVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}>
            <div className="mb-12 text-center">
              <p className="mb-3 text-sm font-bold uppercase tracking-widest text-primary">How It Works</p>
              <h2 className="mb-4 text-3xl font-extrabold text-foreground md:text-4xl">Replacement Process</h2>
            </div>
            <div className="grid gap-6 md:grid-cols-3">
              {steps.map((step, i) => (
                <div key={i} className="relative rounded-2xl border border-border bg-card p-7 text-center shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-lg hover:border-primary/20">
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 flex h-8 w-8 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground shadow-lg">
                    {i + 1}
                  </div>
                  <div className="mx-auto mb-4 mt-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-primary to-blue-600 shadow-lg shadow-primary/25">
                    <step.icon className="h-7 w-7 text-white" />
                  </div>
                  <h3 className="mb-2 font-bold text-foreground">{step.title}</h3>
                  <p className="text-sm leading-relaxed text-muted-foreground">{step.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Important Notice */}
        <section className="py-16 md:py-24">
          <div className="container mx-auto max-w-4xl">
            <div className="rounded-2xl border border-primary/20 bg-primary/5 p-8 md:p-10">
              <div className="flex items-start gap-4">
                <AlertCircle className="mt-1 h-6 w-6 shrink-0 text-primary" />
                <div>
                  <h3 className="mb-3 text-lg font-bold text-foreground">Important Notice</h3>
                  <p className="mb-4 text-sm leading-relaxed text-muted-foreground">
                    All replacement requests must be submitted within 7 days of account delivery. Please include your order number, account details, and a clear description of the issue. Our team typically responds within 2-4 hours.
                  </p>
                  <Link to="/contact">
                    <Button className="rounded-xl shadow-lg shadow-primary/25">
                      Contact Support <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
};

export default RefundPage;
