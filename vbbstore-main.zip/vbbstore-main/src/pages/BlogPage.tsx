import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { ArrowRight, Clock, User } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import FloatingContact from "@/components/FloatingContact";
import { useScrollReveal } from "@/hooks/use-scroll-reveal";
import { usePageSEO } from "@/hooks/use-page-seo";

interface BlogPost {
  id: string;
  slug: string;
  title: string;
  excerpt: string;
  category: string;
  date: string;
  read_time: string | null;
  author: string | null;
}

const blogCategories = ["All", "Verified BM", "WhatsApp API", "Tips & Guides", "Guides"];

const BlogPage = () => {
  const [active, setActive] = useState("All");
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const { ref, visible } = useScrollReveal();

  usePageSEO({
    title: "Blog – Tips & Guides for Meta Advertising | VBB STORE",
    description: "Read our latest tips on verified BM accounts, WhatsApp API, Facebook Ads, and more. Simple guides to help you grow your ad business.",
    path: "/blog",
    jsonLd: {
      "@context": "https://schema.org",
      "@type": "CollectionPage",
      name: "VBB STORE Blog",
      description: "Expert tips, guides and insights on verified Business Manager accounts, WhatsApp Business API, Meta advertising strategies.",
      url: "https://verifiedbmbuy.com/blog",
      publisher: {
        "@type": "Organization",
        name: "VBB STORE",
        url: "https://verifiedbmbuy.com",
      },
    },
  });

  useEffect(() => {
    const fetchPosts = async () => {
      const { data } = await supabase
        .from("blog_posts")
        .select("id, slug, title, excerpt, category, date, read_time, author")
        .eq("published", true)
        .order("date", { ascending: false });
      setPosts((data as BlogPost[]) || []);
    };
    fetchPosts();
  }, []);

  const filtered = active === "All" ? posts : posts.filter((p) => p.category === active);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        {/* Blog Hero */}
        <section className="relative overflow-hidden bg-gradient-to-br from-foreground via-foreground to-foreground/90 py-16 md:py-20">
          <div className="absolute inset-0">
            <div className="absolute -left-32 top-0 h-80 w-80 rounded-full bg-primary/20 blur-3xl" />
            <div className="absolute -bottom-20 right-10 h-72 w-72 rounded-full bg-primary/10 blur-3xl" />
            <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI0MCIgaGVpZ2h0PSI0MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSAwIDEwIEwgNDAgMTAgTSAxMCAwIEwgMTAgNDAiIGZpbGw9Im5vbmUiIHN0cm9rZT0icmdiYSgyNTUsMjU1LDI1NSwwLjAzKSIgc3Ryb2tlLXdpZHRoPSIxIi8+PC9wYXR0ZXJuPjwvZGVmcz48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSJ1cmwoI2dyaWQpIi8+PC9zdmc+')] opacity-50" />
          </div>
          <div className="container relative z-10 text-center">
            <p className="mb-3 text-sm font-bold uppercase tracking-widest text-primary">Our Blog</p>
            <h1 className="mb-4 text-4xl font-extrabold text-white md:text-5xl lg:text-6xl">
              Insights & Guides
            </h1>
            <p className="mx-auto max-w-xl text-lg text-white/60">
              Expert tips, industry insights, and guides on Meta advertising, verified Business Managers, and WhatsApp API.
            </p>
          </div>
        </section>

        {/* Blog Posts */}
        <section className="py-12 md:py-16" ref={ref}>
          <div className="container">
            <div className={`mb-8 flex flex-wrap justify-center gap-2 transition-all duration-700 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}>
              {blogCategories.map((cat) => (
                <Button
                  key={cat}
                  variant={active === cat ? "default" : "outline"}
                  size="sm"
                  onClick={() => setActive(cat)}
                  className={`rounded-full px-5 font-medium transition-all ${
                    active === cat ? "shadow-md shadow-primary/25" : "hover:bg-primary/5"
                  }`}
                >
                  {cat}
                </Button>
              ))}
            </div>

            <div className={`grid gap-8 md:grid-cols-2 lg:grid-cols-3 transition-all duration-700 delay-100 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}>
              {filtered.map((post, i) => (
                <Link key={post.id} to={`/blog/${post.slug}`} className="group">
                  <article className="h-full overflow-hidden rounded-2xl border border-border bg-card shadow-sm transition-all duration-300 hover:-translate-y-1.5 hover:shadow-xl hover:border-primary/20">
                    {/* Colored header stripe */}
                    <div className={`h-48 bg-gradient-to-br ${
                      i % 3 === 0 ? "from-primary/10 via-primary/20 to-blue-500/15" :
                      i % 3 === 1 ? "from-blue-500/10 via-primary/15 to-primary/20" :
                      "from-primary/15 via-blue-600/10 to-primary/10"
                    } flex items-center justify-center p-6`}>
                      <span className="text-xs font-bold uppercase tracking-widest text-primary/60">{post.category}</span>
                    </div>
                    <div className="p-6">
                      <div className="mb-3 flex items-center gap-3 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1"><Clock className="h-3 w-3" /> {post.read_time}</span>
                        <span>•</span>
                        <span>{new Date(post.date).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}</span>
                      </div>
                      <h2 className="mb-1 text-lg font-bold text-foreground line-clamp-2 transition-colors group-hover:text-primary">
                        {post.title}
                      </h2>
                      <h3 className="mb-3 text-xs font-semibold uppercase tracking-wide text-primary/70">{post.category}</h3>
                      <p className="mb-4 text-sm text-muted-foreground line-clamp-3 leading-relaxed">{post.excerpt}</p>
                      <span className="inline-flex items-center gap-1 text-sm font-semibold text-primary transition-all group-hover:gap-2">
                        Read More <ArrowRight className="h-4 w-4" />
                      </span>
                    </div>
                  </article>
                </Link>
              ))}
            </div>
          </div>
        </section>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
};

export default BlogPage;
