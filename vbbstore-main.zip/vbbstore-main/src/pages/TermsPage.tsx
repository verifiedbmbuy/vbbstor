import Header from "@/components/Header";
import Footer from "@/components/Footer";
import FloatingContact from "@/components/FloatingContact";
import { useScrollReveal } from "@/hooks/use-scroll-reveal";
import { FileText, Scale, ShieldCheck, AlertTriangle, CreditCard, Ban, RefreshCw, Globe } from "lucide-react";
import { usePageSEO } from "@/hooks/use-page-seo";

const sections = [
  { icon: Scale, title: "1. Acceptance of Terms", content: `By accessing and using VBB STORE ("we," "us," or "our") at verifiedbmbuy.com, you agree to be bound by these Terms of Service. If you do not agree with any part of these terms, you must not use our services. These terms apply to all visitors, users, and customers of our platform.` },
  { icon: ShieldCheck, title: "2. Services Provided", content: `VBB STORE provides verified Meta Business Manager (BM) accounts, WhatsApp Business API accounts, Facebook Ads accounts, reinstated profiles, and related digital products. All accounts are verified using genuine business documentation and delivered digitally upon payment confirmation.` },
  { icon: CreditCard, title: "3. Payment & Pricing", content: `All prices are listed in USD. We accept cryptocurrency payments including USDT (TRC20), Bitcoin (BTC), and Ethereum (ETH). Payment must be completed before account delivery. Prices may change without prior notice, but confirmed orders will be honored at the purchased price.` },
  { icon: RefreshCw, title: "4. Delivery & Replacement", content: `We offer instant digital delivery. Account credentials are provided within minutes after payment confirmation. All purchases come with a 7-day replacement guarantee. If an account becomes non-functional within 7 days due to no fault of the buyer, a free replacement will be provided.` },
  { icon: Ban, title: "5. Prohibited Use", content: `You agree not to use our products for any illegal activities, spam, fraud, or violations of Meta's advertising policies. Accounts must be used responsibly and in compliance with all applicable laws. We reserve the right to refuse service to anyone who violates these terms.` },
  { icon: AlertTriangle, title: "6. Limitation of Liability", content: `VBB STORE shall not be liable for any indirect, incidental, or consequential damages arising from the use of our products. Our total liability is limited to the purchase price of the product. We are not responsible for actions taken by Meta or third parties on accounts after delivery.` },
  { icon: FileText, title: "7. Intellectual Property", content: `All content on verifiedbmbuy.com, including logos, text, graphics, and design, is the property of VBB STORE. You may not reproduce, distribute, or create derivative works from our content without written permission.` },
  { icon: Globe, title: "8. Governing Law", content: `These terms shall be governed by and construed in accordance with applicable international commerce laws. Any disputes arising under these terms will be resolved through good-faith negotiation or, if necessary, through binding arbitration.` },
];

const TermsPage = () => {
  const { ref, visible } = useScrollReveal();

  usePageSEO({
    title: "Terms of Service | VBB STORE",
    description: "Read our terms of service. Simple rules about payments, delivery, replacements, and how to use our products.",
    path: "/terms",
  });

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        {/* Hero */}
        <section className="relative overflow-hidden bg-gradient-to-br from-primary via-primary to-blue-700 py-20 md:py-28">
          <div className="absolute inset-0">
            <div className="absolute -right-32 -top-32 h-96 w-96 rounded-full bg-blue-400/20 blur-3xl" />
            <div className="absolute -bottom-20 -left-20 h-72 w-72 rounded-full bg-blue-300/15 blur-3xl" />
          </div>
          <div className="container relative z-10 text-center">
            <div className="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-2xl bg-white/10 backdrop-blur-sm">
              <FileText className="h-8 w-8 text-white" />
            </div>
            <h1 className="mb-4 text-4xl font-extrabold text-white md:text-5xl lg:text-6xl">Terms of Service</h1>
            <p className="mx-auto max-w-2xl text-lg text-white/70">
              Please read these terms carefully before using our services. Last updated: February 2026.
            </p>
          </div>
        </section>

        {/* Content */}
        <section className="py-16 md:py-24" ref={ref}>
          <div className={`container mx-auto max-w-4xl transition-all duration-700 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}>
            <div className="space-y-6">
              {sections.map((s, i) => (
                <div
                  key={i}
                  className="group rounded-2xl border border-border bg-card p-7 shadow-sm transition-all duration-300 hover:shadow-lg hover:border-primary/20"
                >
                  <div className="mb-4 flex items-center gap-4">
                    <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-blue-600 shadow-lg shadow-primary/25">
                      <s.icon className="h-5 w-5 text-white" />
                    </div>
                    <h2 className="text-xl font-bold text-foreground">{s.title}</h2>
                  </div>
                  <p className="leading-relaxed text-muted-foreground pl-15">{s.content}</p>
                </div>
              ))}
            </div>

            <div className="mt-12 rounded-2xl border border-primary/20 bg-primary/5 p-8 text-center">
              <p className="text-sm text-muted-foreground">
                If you have questions about these terms, please contact us at{" "}
                <a href="mailto:info@verifiedbmbuy.com" className="font-semibold text-primary hover:underline">
                  info@verifiedbmbuy.com
                </a>{" "}
                or via{" "}
                <a href="https://wa.me/8801302669333" className="font-semibold text-primary hover:underline">
                  WhatsApp
                </a>.
              </p>
            </div>
          </div>
        </section>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
};

export default TermsPage;
