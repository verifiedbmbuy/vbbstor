import Header from "@/components/Header";
import Footer from "@/components/Footer";
import FloatingContact from "@/components/FloatingContact";
import { useScrollReveal } from "@/hooks/use-scroll-reveal";
import { ShieldCheck, Clock, Zap, Award, CheckCircle2, Star, MessageCircle, ArrowRight } from "lucide-react";
import { useEffect } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { usePageSEO } from "@/hooks/use-page-seo";

const guarantees = [
  { icon: Clock, title: "7-Day Coverage", desc: "Full replacement coverage for 7 days from the moment of account delivery." },
  { icon: Zap, title: "Fast Turnaround", desc: "Replacement accounts are delivered within 24 hours of claim verification." },
  { icon: Award, title: "Same Quality", desc: "Replacement accounts match or exceed the quality of your original purchase." },
  { icon: Star, title: "No Extra Cost", desc: "All eligible replacements are completely free — no hidden fees or charges." },
];

const coverage = [
  { product: "Verified BM (All Tiers)", period: "7 Days", includes: "Full account replacement with matching trust score and ad account slots" },
  { product: "WhatsApp Business API", period: "7 Days", includes: "Complete WABA replacement with same features and green badge eligibility" },
  { product: "Facebook Ads Accounts", period: "7 Days", includes: "Replacement ad account with same spending limits and status" },
  { product: "TikTok & Google Ads Accounts", period: "7 Days", includes: "Replacement ad account with matching quality and clean history" },
  { product: "Reinstated Profiles", period: "7 Days", includes: "Fully working replacement profile with clean record" },
];

const ReplacementPage = () => {
  const { ref, visible } = useScrollReveal();
  const { ref: tableRef, visible: tableVisible } = useScrollReveal();

  usePageSEO({
    title: "7-Day Free Replacement | VBB STORE",
    description: "Every product comes with a 7-day free replacement. If it stops working, we replace it. Simple as that.",
    path: "/replacement",
  });

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        {/* Hero */}
        <section className="relative overflow-hidden bg-gradient-to-br from-primary via-primary to-blue-700 py-20 md:py-28">
          <div className="absolute inset-0">
            <div className="absolute -right-32 -top-32 h-96 w-96 rounded-full bg-blue-400/20 blur-3xl" />
            <div className="absolute -bottom-20 -left-20 h-72 w-72 rounded-full bg-blue-300/15 blur-3xl" />
          </div>
          <div className="container relative z-10 text-center">
            <div className="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-2xl bg-white/10 backdrop-blur-sm">
              <ShieldCheck className="h-8 w-8 text-white" />
            </div>
            <h1 className="mb-4 text-4xl font-extrabold text-white md:text-5xl lg:text-6xl">Replacement Guarantee</h1>
            <p className="mx-auto max-w-2xl text-lg text-white/70">
              Every product is backed by our industry-leading 7-day free replacement guarantee.
            </p>
          </div>
        </section>

        {/* Benefits */}
        <section className="py-16 md:py-24" ref={ref}>
          <div className={`container transition-all duration-700 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}>
            <div className="mb-12 text-center">
              <p className="mb-3 text-sm font-bold uppercase tracking-widest text-primary">Why Choose Us</p>
              <h2 className="mb-4 text-3xl font-extrabold text-foreground md:text-4xl">Our Guarantee Includes</h2>
              <p className="mx-auto max-w-2xl text-muted-foreground">We're committed to your success — that's why every purchase is protected.</p>
            </div>
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {guarantees.map((g) => (
                <div key={g.title} className="group rounded-2xl border border-border bg-card p-7 text-center shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-lg hover:border-primary/20">
                  <div className="mx-auto mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-primary to-blue-600 shadow-lg shadow-primary/25 transition-transform group-hover:scale-105">
                    <g.icon className="h-7 w-7 text-white" />
                  </div>
                  <h3 className="mb-2 font-bold text-foreground">{g.title}</h3>
                  <p className="text-sm leading-relaxed text-muted-foreground">{g.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Coverage Table */}
        <section className="py-16 md:py-24 bg-gradient-to-b from-muted/30 to-muted/80" ref={tableRef}>
          <div className={`container mx-auto max-w-5xl transition-all duration-700 ${tableVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}>
            <div className="mb-12 text-center">
              <p className="mb-3 text-sm font-bold uppercase tracking-widest text-primary">Coverage Details</p>
              <h2 className="mb-4 text-3xl font-extrabold text-foreground md:text-4xl">What's Covered</h2>
            </div>
            <div className="space-y-4">
              {coverage.map((item) => (
                <div key={item.product} className="rounded-2xl border border-border bg-card p-6 shadow-sm transition-all duration-300 hover:shadow-lg hover:border-primary/20">
                  <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                    <div className="flex items-center gap-3">
                      <CheckCircle2 className="h-5 w-5 shrink-0 text-primary" />
                      <h3 className="font-bold text-foreground">{item.product}</h3>
                    </div>
                    <span className="inline-flex w-fit items-center rounded-full bg-primary/10 px-4 py-1.5 text-xs font-bold text-primary">
                      {item.period}
                    </span>
                  </div>
                  <p className="mt-3 text-sm leading-relaxed text-muted-foreground pl-8">{item.includes}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-16 md:py-24">
          <div className="container text-center">
            <h2 className="mb-4 text-3xl font-extrabold text-foreground md:text-4xl">Need a Replacement?</h2>
            <p className="mx-auto mb-8 max-w-xl text-muted-foreground">
              Contact our support team anytime — we're here 24/7 to help you.
            </p>
            <div className="flex flex-col items-center gap-4 sm:flex-row sm:justify-center">
              <a href="https://wa.me/8801302669333">
                <Button size="lg" className="rounded-xl shadow-lg shadow-primary/25 h-12 px-8 font-bold">
                  <MessageCircle className="mr-2 h-5 w-5" /> WhatsApp Support
                </Button>
              </a>
              <Link to="/contact">
                <Button size="lg" variant="outline" className="rounded-xl h-12 px-8 font-bold">
                  Contact Page <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </div>
          </div>
        </section>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
};

export default ReplacementPage;
