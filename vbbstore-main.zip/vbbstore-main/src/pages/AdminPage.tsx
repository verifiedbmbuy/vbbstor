import { lazy, Suspense, useState } from "react";
import { Link } from "react-router-dom";
import {
  LayoutDashboard, Package, ShoppingCart, Menu, X,
  Image, Palette, ChevronDown, ChevronRight, Home,
  Gauge, PenSquare, MessageSquare, Megaphone,
  Wrench, Users, Settings2, Download, Tag, LogOut, Bell
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { AuthProvider, useAuth } from "@/hooks/useAuth";
import AdminLogin from "@/components/admin/AdminLogin";

const AdminAnalytics = lazy(() => import("@/components/admin/AdminAnalytics"));
const AdminProducts = lazy(() => import("@/components/admin/AdminProducts"));
const AdminBlog = lazy(() => import("@/components/admin/AdminBlog"));
const AdminOrders = lazy(() => import("@/components/admin/AdminOrders"));
const AdminContent = lazy(() => import("@/components/admin/AdminContent"));
const AdminSEO = lazy(() => import("@/components/admin/AdminSEO"));
const AdminMessages = lazy(() => import("@/components/admin/AdminMessages"));
const AdminCoupons = lazy(() => import("@/components/admin/AdminCoupons"));
const AdminMedia = lazy(() => import("@/components/admin/AdminMedia"));
const AdminAppearance = lazy(() => import("@/components/admin/AdminAppearance"));
const AdminSettings = lazy(() => import("@/components/admin/AdminSettings"));
const AdminUsers = lazy(() => import("@/components/admin/AdminUsers"));
const AdminBackups = lazy(() => import("@/components/admin/AdminBackups"));

type Tab =
  | "dashboard" | "products" | "blog" | "orders" | "messages"
  | "coupons" | "seo" | "content" | "media" | "appearance"
  | "settings" | "users" | "backups";

interface MenuItem { id: Tab; label: string; icon: typeof LayoutDashboard; group?: string; }

const menuItems: MenuItem[] = [
  { id: "dashboard", label: "Dashboard", icon: Gauge },
  { id: "products", label: "Products", icon: Package, group: "Store" },
  { id: "orders", label: "Orders", icon: ShoppingCart, group: "Store" },
  { id: "coupons", label: "Coupons", icon: Tag, group: "Store" },
  { id: "blog", label: "Posts", icon: PenSquare, group: "Content" },
  { id: "media", label: "Media", icon: Image, group: "Content" },
  { id: "messages", label: "Messages", icon: MessageSquare, group: "Content" },
  { id: "appearance", label: "Appearance", icon: Palette, group: "Settings" },
  { id: "seo", label: "SEO", icon: Megaphone, group: "Settings" },
  { id: "content", label: "Site Content", icon: Wrench, group: "Settings" },
  { id: "settings", label: "Settings", icon: Settings2, group: "Settings" },
  { id: "users", label: "Users & Roles", icon: Users, group: "Tools" },
  { id: "backups", label: "Export & Backup", icon: Download, group: "Tools" },
];

const groups = [
  { name: null, items: menuItems.filter((m) => !m.group) },
  { name: "Store", items: menuItems.filter((m) => m.group === "Store") },
  { name: "Content", items: menuItems.filter((m) => m.group === "Content") },
  { name: "Settings", items: menuItems.filter((m) => m.group === "Settings") },
  { name: "Tools", items: menuItems.filter((m) => m.group === "Tools") },
];

const tabComponents: Record<Tab, React.LazyExoticComponent<any>> = {
  dashboard: AdminAnalytics,
  products: AdminProducts,
  blog: AdminBlog,
  orders: AdminOrders,
  messages: AdminMessages,
  coupons: AdminCoupons,
  seo: AdminSEO,
  content: AdminContent,
  media: AdminMedia,
  appearance: AdminAppearance,
  settings: AdminSettings,
  users: AdminUsers,
  backups: AdminBackups,
};

const AdminPanel = () => {
  const { user, isAdmin, loading, signOut } = useAuth();
  const [active, setActive] = useState<Tab>("dashboard");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [collapsedGroups, setCollapsedGroups] = useState<Record<string, boolean>>({});

  const toggleGroup = (name: string) =>
    setCollapsedGroups((prev) => ({ ...prev, [name]: !prev[name] }));

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-3">
          <div className="h-10 w-10 animate-spin rounded-full border-4 border-primary border-t-transparent" />
          <span className="text-sm text-muted-foreground">Loading admin…</span>
        </div>
      </div>
    );
  }

  if (!user || !isAdmin) return <AdminLogin />;

  const activeItem = menuItems.find((t) => t.id === active);
  const ActiveComponent = tabComponents[active];

  return (
    <div className="flex min-h-screen bg-muted/30">
      {/* ── Sidebar ── */}
      <aside
        className={`fixed inset-y-0 left-0 z-40 flex w-[240px] flex-col bg-card border-r border-border shadow-sm transition-transform duration-200 lg:static lg:translate-x-0 ${
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        {/* Logo area */}
        <div className="flex h-14 items-center gap-2.5 border-b border-border px-5">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-primary-foreground font-extrabold text-sm">
            V
          </div>
          <span className="text-base font-bold text-foreground tracking-tight">VBB Admin</span>
          <button onClick={() => setSidebarOpen(false)} className="ml-auto text-muted-foreground hover:text-foreground lg:hidden">
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto px-3 py-3">
          {groups.map((group) => (
            <div key={group.name || "top"} className="mb-1">
              {group.name && (
                <button
                  onClick={() => toggleGroup(group.name!)}
                  className="flex w-full items-center justify-between rounded-md px-2 py-1.5 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground hover:text-foreground transition-colors"
                >
                  {group.name}
                  {collapsedGroups[group.name!] ? (
                    <ChevronRight className="h-3 w-3" />
                  ) : (
                    <ChevronDown className="h-3 w-3" />
                  )}
                </button>
              )}
              {(!group.name || !collapsedGroups[group.name!]) &&
                group.items.map((item) => {
                  const isActive = active === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => { setActive(item.id); setSidebarOpen(false); }}
                      className={`flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-[13px] font-medium transition-all ${
                        isActive
                          ? "bg-primary text-primary-foreground shadow-sm"
                          : "text-muted-foreground hover:bg-accent hover:text-foreground"
                      }`}
                    >
                      <item.icon className="h-4 w-4 shrink-0" />
                      <span>{item.label}</span>
                    </button>
                  );
                })}
            </div>
          ))}
        </nav>

        {/* Sidebar footer */}
        <div className="border-t border-border p-3 space-y-1">
          <Link
            to="/"
            className="flex items-center gap-2 rounded-lg px-3 py-2 text-[13px] font-medium text-muted-foreground hover:bg-accent hover:text-foreground transition-colors"
          >
            <Home className="h-4 w-4" />
            <span>View Site</span>
          </Link>
          <button
            onClick={signOut}
            className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-[13px] font-medium text-destructive hover:bg-destructive/10 transition-colors"
          >
            <LogOut className="h-4 w-4" />
            <span>Log Out</span>
          </button>
        </div>
      </aside>

      {/* Overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-30 bg-black/40 backdrop-blur-sm lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* ── Main Area ── */}
      <div className="flex flex-1 flex-col min-w-0">
        {/* Top header */}
        <header className="sticky top-0 z-20 flex h-14 items-center gap-3 border-b border-border bg-card/80 backdrop-blur-md px-4 lg:px-6">
          <button className="lg:hidden text-foreground" onClick={() => setSidebarOpen(true)}>
            <Menu className="h-5 w-5" />
          </button>

          <div className="flex items-center gap-2">
            {activeItem && <activeItem.icon className="h-5 w-5 text-primary" />}
            <h1 className="text-lg font-bold text-foreground">{activeItem?.label || "Dashboard"}</h1>
          </div>

          <div className="ml-auto flex items-center gap-3">
            <button className="relative rounded-lg p-2 text-muted-foreground hover:bg-accent hover:text-foreground transition-colors">
              <Bell className="h-4 w-4" />
            </button>
            <div className="hidden sm:flex items-center gap-2 rounded-lg bg-muted px-3 py-1.5">
              <div className="flex h-6 w-6 items-center justify-center rounded-full bg-primary text-primary-foreground text-[10px] font-bold">
                {user?.email?.charAt(0).toUpperCase()}
              </div>
              <span className="text-xs font-medium text-foreground">{user?.email?.split("@")[0]}</span>
            </div>
          </div>
        </header>

        {/* Content */}
        <main className="flex-1 p-4 lg:p-6">
          <Suspense
            fallback={
              <div className="flex items-center gap-3 py-12 justify-center text-muted-foreground text-sm">
                <div className="h-5 w-5 animate-spin rounded-full border-2 border-primary border-t-transparent" />
                Loading…
              </div>
            }
          >
            <ActiveComponent />
          </Suspense>
        </main>

        {/* Footer */}
        <footer className="border-t border-border px-4 py-3 text-center text-xs text-muted-foreground lg:px-6">
          © 2026 <span className="font-semibold text-primary">VBB Store</span> · Admin Panel
        </footer>
      </div>
    </div>
  );
};

const AdminPage = () => (
  <AuthProvider>
    <AdminPanel />
  </AuthProvider>
);

export default AdminPage;
