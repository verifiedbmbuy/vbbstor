import { Shield, Users, Globe, Award, Clock, HeartHandshake, Target, TrendingUp, CheckCircle2, Star, Zap, MessageCircle, Send, ArrowRight, HelpCircle, ChevronRight, Headphones, RefreshCcw, Lock, Package, BadgeCheck, FileText } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import FloatingContact from "@/components/FloatingContact";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { usePageSEO } from "@/hooks/use-page-seo";
import heroLogo from "@/assets/hero-logo.jpg";

const AboutPage = () => {
  usePageSEO({
    title: "About VBB STORE – Verified BM & Ad Accounts Since 2020",
    description: "We sell verified Meta Business Manager, WhatsApp API, Facebook, TikTok and Google Ads accounts. 10K+ happy customers in 50+ countries since 2020.",
    path: "/about",
  });

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        {/* ── Hero ── */}
        <section className="relative overflow-hidden bg-gradient-to-br from-primary via-primary to-blue-700 py-20 md:py-28">
          <div className="absolute inset-0">
            <div className="absolute -right-32 -top-32 h-96 w-96 rounded-full bg-blue-400/20 blur-3xl" />
            <div className="absolute -bottom-20 -left-20 h-72 w-72 rounded-full bg-blue-300/15 blur-3xl" />
            <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI0MCIgaGVpZ2h0PSI0MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSAwIDEwIEwgNDAgMTAgTSAxMCAwIEwgMTAgNDAiIGZpbGw9Im5vbmUiIHN0cm9rZT0icmdiYSgyNTUsMjU1LDI1NSwwLjAzKSIgc3Ryb2tlLXdpZHRoPSIxIi8+PC9wYXR0ZXJuPjwvZGVmcz48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSJ1cmwoI2dyaWQpIi8+PC9zdmc+')] opacity-50" />
          </div>
          <div className="container relative z-10 text-center">
            <Badge className="mb-4 border-white/20 bg-white/10 text-[10px] font-bold uppercase tracking-widest text-white">Established 2020</Badge>
            <h1 className="mb-6 text-4xl font-extrabold text-white md:text-5xl lg:text-6xl">
              The Most Trusted Name in{" "}
              <span className="bg-gradient-to-r from-white via-blue-100 to-white bg-clip-text text-transparent">Verified Meta Accounts</span>
            </h1>
            <p className="mx-auto max-w-2xl text-lg text-white/70">
              VBB STORE has been empowering advertisers and agencies worldwide with premium verified accounts since 2020. Quality, speed, and trust — that's our promise.
            </p>
            <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
              <Link to="/shop">
                <Button size="lg" variant="secondary" className="gap-2 font-bold">
                  Browse Products <ArrowRight className="h-4 w-4" />
                </Button>
              </Link>
              <a href="https://wa.me/8801302669333" target="_blank" rel="noopener noreferrer">
                <Button size="lg" className="gap-2 border-white/30 bg-white/10 font-bold text-white hover:bg-white/20">
                  <MessageCircle className="h-5 w-5" /> Talk to Us
                </Button>
              </a>
            </div>
          </div>
        </section>

        {/* ── Stats Bar ── */}
        <section className="border-b border-border bg-card py-10">
          <div className="container">
            <div className="grid grid-cols-2 gap-6 md:grid-cols-4">
              {[
                { value: "5+", label: "Years in Business", icon: Clock },
                { value: "10K+", label: "Accounts Delivered", icon: Package },
                { value: "50+", label: "Countries Served", icon: Globe },
                { value: "99%", label: "Client Satisfaction", icon: Star },
              ].map(({ value, label, icon: Icon }) => (
                <div key={label} className="text-center">
                  <div className="mx-auto mb-2 flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10">
                    <Icon className="h-5 w-5 text-primary" />
                  </div>
                  <p className="text-3xl font-extrabold text-primary md:text-4xl">{value}</p>
                  <p className="mt-1 text-xs font-medium text-muted-foreground">{label}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ── Our Story ── */}
        <section className="py-16 md:py-24">
          <div className="container">
            <div className="grid items-center gap-6 lg:grid-cols-[1fr_auto]">
              <div>
                <Badge variant="secondary" className="mb-3 text-[10px] font-bold uppercase tracking-widest">Our Story</Badge>
                <h2 className="mb-6 text-3xl font-extrabold text-foreground md:text-4xl">From a Simple Idea to a Global Brand</h2>
                <div className="space-y-4 text-muted-foreground leading-relaxed">
                  <p>
                    VBB STORE was born in 2020 from a frustration every digital advertiser knows: getting banned, restricted, or stuck with low-trust accounts that kill your campaigns before they start.
                  </p>
                  <p>
                    We set out to change that. Our founding team — experienced media buyers and compliance specialists — built a system to deliver genuinely verified Meta Business Manager accounts, WhatsApp API setups, and Facebook Ads accounts that are ready to scale from day one.
                  </p>
                  <p>
                    Five years later, we've served over 10,000 customers across 50+ countries. From solo media buyers running their first campaign to enterprise agencies managing millions in ad spend — VBB STORE is the name they trust.
                  </p>
                </div>
              </div>
              <div className="flex justify-center lg:justify-end">
                <div className="relative">
                  {/* Animated border glow */}
                  <div className="absolute -inset-1 rounded-3xl bg-gradient-to-br from-primary via-blue-400 to-primary opacity-20 blur-md" />
                  <div className="relative rounded-3xl border border-border bg-card p-6 shadow-lg">
                    <div className="relative mx-auto h-36 w-36 md:h-44 md:w-44">
                      <div className="absolute -inset-1.5 animate-border-rotate rounded-3xl opacity-60" />
                      <img
                        src={heroLogo}
                        alt="VBB Store logo"
                        className="relative h-full w-full rounded-3xl object-cover shadow-md"
                      />
                    </div>
                    <div className="mt-5 text-center">
                      <span className="text-xl font-extrabold text-foreground">VBB STORE</span>
                      <p className="mt-1 text-xs text-muted-foreground">Trusted Since 2020</p>
                      <div className="mt-3 flex justify-center gap-1.5">
                        <Badge className="bg-primary/10 text-[8px] font-bold uppercase text-primary hover:bg-primary/15">✓ Verified</Badge>
                        <Badge className="bg-primary/10 text-[8px] font-bold uppercase text-primary hover:bg-primary/15">10K+ Sold</Badge>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ── Mission & Vision ── */}
        <section className="border-t border-border bg-card py-16 md:py-24">
          <div className="container">
            <div className="grid gap-8 md:grid-cols-2">
              <div className="rounded-2xl border border-border bg-background p-8 transition-all hover:border-primary/20 hover:shadow-md">
                <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-blue-600 shadow-md shadow-primary/20">
                  <Target className="h-6 w-6 text-white" />
                </div>
                <h3 className="mb-3 text-xl font-extrabold text-foreground">Our Mission</h3>
                <p className="text-sm leading-relaxed text-muted-foreground">
                  To make verified, high-trust Meta advertising accounts accessible to every advertiser on the planet — whether you're running your first ad or managing a global agency. We eliminate the barriers so you can focus on growth.
                </p>
              </div>
              <div className="rounded-2xl border border-border bg-background p-8 transition-all hover:border-primary/20 hover:shadow-md">
                <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-blue-600 shadow-md shadow-primary/20">
                  <TrendingUp className="h-6 w-6 text-white" />
                </div>
                <h3 className="mb-3 text-xl font-extrabold text-foreground">Our Vision</h3>
                <p className="text-sm leading-relaxed text-muted-foreground">
                  To become the world's #1 marketplace for verified digital advertising infrastructure — setting the gold standard for quality, compliance, and customer experience in the industry.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* ── Timeline / Journey ── */}
        <section className="py-16 md:py-24">
          <div className="container">
            <div className="mb-12 text-center">
              <Badge variant="secondary" className="mb-3 text-[10px] font-bold uppercase tracking-widest">Our Journey</Badge>
              <h2 className="text-2xl font-extrabold text-foreground md:text-3xl">Key Milestones</h2>
            </div>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {[
                { year: "2020", title: "VBB STORE Founded", desc: "Started with a small team focused on delivering verified BM accounts to local advertisers.", icon: Target },
                { year: "2021", title: "1,000+ Customers", desc: "Expanded globally with 24/7 support across WhatsApp and Telegram.", icon: Users },
                { year: "2022", title: "WhatsApp API Launch", desc: "Added WhatsApp Business API accounts, serving enterprise clients.", icon: MessageCircle },
                { year: "2023", title: "50+ Countries", desc: "Reached global coverage with multilingual support.", icon: Globe },
                { year: "2024", title: "10K+ Delivered", desc: "Hit 10K+ verified accounts with 99% satisfaction rate.", icon: Award },
                { year: "2025", title: "Industry Leader", desc: "Recognized as one of the most trusted names worldwide.", icon: Star },
              ].map(({ year, title, desc, icon: Icon }) => (
                <div key={year} className="group rounded-2xl border border-border bg-card p-6 transition-all hover:border-primary/20 hover:shadow-md">
                  <div className="mb-3 flex items-center gap-3">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-blue-600 shadow-md shadow-primary/20 transition-transform group-hover:scale-105">
                      <Icon className="h-5 w-5 text-white" />
                    </div>
                    <Badge variant="secondary" className="text-[9px] font-bold uppercase">{year}</Badge>
                  </div>
                  <h3 className="mb-1 font-bold text-foreground">{title}</h3>
                  <p className="text-sm leading-relaxed text-muted-foreground">{desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ── What We Offer ── */}
        <section className="border-t border-border bg-card py-16 md:py-24">
          <div className="container">
            <div className="mb-12 text-center">
              <Badge variant="secondary" className="mb-3 text-[10px] font-bold uppercase tracking-widest">Products</Badge>
              <h2 className="text-2xl font-extrabold text-foreground md:text-3xl">What We Offer</h2>
              <p className="mt-2 text-sm text-muted-foreground">Premium verified accounts designed to power your advertising at scale.</p>
            </div>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {[
                { icon: BadgeCheck, title: "Verified Business Manager", desc: "Verified Meta BM accounts with real documents. Ready for ad campaigns and agency use.", badge: "Best Seller" },
                { icon: MessageCircle, title: "WhatsApp Business API", desc: "Pre-verified WhatsApp API accounts. Send 250 to 10,000+ messages per day." },
                { icon: FileText, title: "Facebook Ads Accounts", desc: "Verified Facebook Ads accounts with clean history and high trust scores." },
                { icon: RefreshCcw, title: "Reinstated Profiles", desc: "Recovered Facebook profiles with clean records, ready to use right away." },
                { icon: Globe, title: "TikTok & Google Ads", desc: "Ready-to-use TikTok Ads and Google Ads accounts. Start your campaigns on day one." },
                { icon: Shield, title: "BM Verification Service", desc: "We verify your existing Business Managers. We handle the whole process for you." },
              ].map(({ icon: Icon, title, desc, badge }) => (
                <div key={title} className="group rounded-2xl border border-border bg-background p-6 transition-all hover:border-primary/20 hover:shadow-md">
                  <div className="mb-4 flex items-center gap-3">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-blue-600 shadow-md shadow-primary/20 transition-transform group-hover:scale-105">
                      <Icon className="h-5 w-5 text-white" />
                    </div>
                    {badge && <Badge variant="secondary" className="text-[9px] font-bold uppercase">{badge}</Badge>}
                  </div>
                  <h3 className="mb-1 font-bold text-foreground">{title}</h3>
                  <p className="text-sm leading-relaxed text-muted-foreground">{desc}</p>
                </div>
              ))}
            </div>
            <div className="mt-8 text-center">
              <Link to="/shop">
                <Button size="lg" className="gap-2 font-bold">View All Products <ArrowRight className="h-4 w-4" /></Button>
              </Link>
            </div>
          </div>
        </section>

        {/* ── Our Values ── */}
        <section className="py-16 md:py-24">
          <div className="container">
            <div className="mb-12 text-center">
              <Badge variant="secondary" className="mb-3 text-[10px] font-bold uppercase tracking-widest">Values</Badge>
              <h2 className="text-2xl font-extrabold text-foreground md:text-3xl">What Drives Us Every Day</h2>
            </div>
            <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
              {[
                { icon: Shield, title: "Trust & Security", desc: "Every account is verified with genuine documentation. We never compromise on authenticity." },
                { icon: HeartHandshake, title: "Customer First", desc: "24/7 support dedicated to ensuring every customer has a seamless experience." },
                { icon: Globe, title: "Global Reach", desc: "Serving advertisers in 50+ countries with localized, multilingual support." },
                { icon: Award, title: "Quality Guarantee", desc: "7-day free replacement guarantee on every purchase. No questions asked." },
              ].map(({ icon: Icon, title, desc }) => (
                <div key={title} className="group rounded-2xl border border-border bg-card p-6 text-center transition-all hover:-translate-y-1 hover:shadow-lg hover:border-primary/20">
                  <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-primary to-blue-600 shadow-lg shadow-primary/25 transition-transform group-hover:scale-105">
                    <Icon className="h-7 w-7 text-white" />
                  </div>
                  <h3 className="mb-2 font-bold text-foreground">{title}</h3>
                  <p className="text-sm leading-relaxed text-muted-foreground">{desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ── How It Works ── */}
        <section className="border-t border-border bg-card py-16 md:py-24">
          <div className="container">
            <div className="mb-12 text-center">
              <Badge variant="secondary" className="mb-3 text-[10px] font-bold uppercase tracking-widest">Process</Badge>
              <h2 className="text-2xl font-extrabold text-foreground md:text-3xl">How It Works — Simple as 1-2-3-4</h2>
            </div>
            <div className="mx-auto grid max-w-4xl gap-6 md:grid-cols-4">
              {[
                { step: 1, icon: Target, title: "Choose Product", desc: "Browse our shop and select the verified account that fits your needs." },
                { step: 2, icon: MessageCircle, title: "Contact & Pay", desc: "Reach us on WhatsApp or Telegram and complete payment via crypto." },
                { step: 3, icon: Zap, title: "Get Delivered", desc: "Receive your account credentials securely within 1–4 hours." },
                { step: 4, icon: TrendingUp, title: "Start Scaling", desc: "Set up your campaigns and start advertising immediately." },
              ].map(({ step, icon: Icon, title, desc }) => (
                <div key={step} className="relative text-center">
                  <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-primary to-blue-600 text-lg font-extrabold text-white shadow-lg shadow-primary/20">
                    {step}
                  </div>
                  <h3 className="mb-1 font-bold text-foreground">{title}</h3>
                  <p className="text-sm text-muted-foreground">{desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ── Why Choose Us ── */}
        <section className="py-16 md:py-24">
          <div className="container">
            <div className="mb-12 text-center">
              <Badge variant="secondary" className="mb-3 text-[10px] font-bold uppercase tracking-widest">Why Us</Badge>
              <h2 className="text-2xl font-extrabold text-foreground md:text-3xl">Why 10,000+ Customers Choose VBB STORE</h2>
            </div>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {[
                { icon: Headphones, title: "24/7 Live Support", desc: "Always-on team via WhatsApp, Telegram, and email." },
                { icon: Lock, title: "Secure Delivery", desc: "SSL-encrypted credential handover. We never store your data after delivery." },
                { icon: Zap, title: "1–4 Hour Delivery", desc: "Most orders fulfilled within hours, not days." },
                { icon: RefreshCcw, title: "7-Day Replacement", desc: "Free replacement if anything goes wrong within 7 days." },
                { icon: CheckCircle2, title: "100% Verified", desc: "Only genuine, compliant accounts with real documentation." },
                { icon: Globe, title: "Global Coverage", desc: "50+ countries served with localized guidance and support." },
              ].map(({ icon: Icon, title, desc }) => (
                <div key={title} className="flex items-start gap-4 rounded-xl border border-border bg-card p-5 transition-all hover:border-primary/20 hover:shadow-md">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10">
                    <Icon className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-bold text-foreground">{title}</h3>
                    <p className="mt-1 text-sm text-muted-foreground">{desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ── Our Team ── */}
        <section className="border-t border-border bg-card py-16 md:py-24">
          <div className="container">
            <div className="mb-12 text-center">
              <Badge variant="secondary" className="mb-3 text-[10px] font-bold uppercase tracking-widest">Team</Badge>
              <h2 className="text-2xl font-extrabold text-foreground md:text-3xl">The People Behind VBB STORE</h2>
              <p className="mt-2 text-sm text-muted-foreground">Dedicated experts ensuring quality, support, and success for every customer.</p>
            </div>
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {[
                { title: "Account Specialists", desc: "Handling account verification and quality assurance for every order.", icon: BadgeCheck },
                { title: "Technical Support", desc: "24/7 team ready to assist with setup, integration, and troubleshooting.", icon: Headphones },
                { title: "Customer Success", desc: "Dedicated managers ensuring smooth onboarding and long-term satisfaction.", icon: HeartHandshake },
                { title: "Compliance Team", desc: "Ensuring every account meets Meta's verification and policy standards.", icon: Shield },
              ].map(({ title, desc, icon: Icon }) => (
                <div key={title} className="group rounded-2xl border border-border bg-background p-6 text-center transition-all hover:-translate-y-1 hover:shadow-lg hover:border-primary/20">
                  <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-br from-primary/10 to-primary/20 transition-transform group-hover:scale-105">
                    <Icon className="h-7 w-7 text-primary" />
                  </div>
                  <h3 className="mb-2 font-bold text-foreground">{title}</h3>
                  <p className="text-sm leading-relaxed text-muted-foreground">{desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ── Testimonials ── */}
        <section className="py-16 md:py-24">
          <div className="container">
            <div className="mb-12 text-center">
              <Badge variant="secondary" className="mb-3 text-[10px] font-bold uppercase tracking-widest">Reviews</Badge>
              <h2 className="text-2xl font-extrabold text-foreground md:text-3xl">What Our Customers Say</h2>
            </div>
            <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {[
                { name: "Ahmed K.", role: "Media Buyer, Dubai", text: "VBB STORE delivered my verified BM within 2 hours. Account is still running perfectly after 6 months. Best in the business." },
                { name: "Sarah L.", role: "Agency Owner, UK", text: "We've purchased over 20 accounts from VBB. Their quality and support is unmatched. The 7-day guarantee gives us total confidence." },
                { name: "Carlos M.", role: "E-commerce, Brazil", text: "Fast delivery, genuine verification, and incredible support. I've recommended VBB to every advertiser I know." },
                { name: "James W.", role: "Performance Marketer, USA", text: "After getting banned 3 times, VBB STORE was a lifesaver. Their anti-ban guide actually works. Haven't had issues since." },
                { name: "Fatima R.", role: "Digital Agency, Pakistan", text: "The WhatsApp API setup was seamless. Their team walked me through every step. Outstanding service." },
                { name: "David O.", role: "Affiliate Marketer, Nigeria", text: "I was skeptical at first, but VBB proved me wrong. Legit accounts, fast delivery, and they actually respond 24/7." },
              ].map(({ name, role, text }) => (
                <div key={name} className="rounded-2xl border border-border bg-card p-6 transition-all hover:border-primary/20 hover:shadow-md">
                  <div className="mb-3 flex gap-0.5">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                  <p className="mb-4 text-sm leading-relaxed text-muted-foreground">"{text}"</p>
                  <div>
                    <p className="text-sm font-bold text-foreground">{name}</p>
                    <p className="text-xs text-muted-foreground">{role}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ── FAQ ── */}
        <section className="border-t border-border bg-card py-16 md:py-24">
          <div className="container">
            <div className="mb-10 text-center">
              <Badge variant="secondary" className="mb-3 text-[10px] font-bold uppercase tracking-widest">FAQ</Badge>
              <h2 className="text-2xl font-extrabold text-foreground md:text-3xl">Common Questions About VBB STORE</h2>
            </div>
            <div className="mx-auto grid max-w-4xl gap-3 md:grid-cols-2">
              {[
                { q: "Is VBB STORE a legitimate business?", a: "Absolutely. We've been operating since 2020 with 10,000+ verified accounts delivered to customers in 50+ countries. Our track record speaks for itself." },
                { q: "How are your accounts verified?", a: "Every account goes through genuine Meta verification processes with real business documentation. We don't use shortcuts or fake documents." },
                { q: "What payment methods do you accept?", a: "We accept cryptocurrency payments including USDT (TRC20), Bitcoin (BTC), and Ethereum (ETH) for fast, secure, borderless transactions." },
                { q: "Do you offer bulk discounts?", a: "Yes! We offer competitive pricing for bulk orders. Contact us on WhatsApp or Telegram to discuss custom packages for your agency." },
                { q: "What happens if my account has issues?", a: "All purchases include a 7-day free replacement guarantee. If anything goes wrong within that period, we replace it immediately — no questions asked." },
                { q: "How fast is delivery?", a: "Most orders are delivered within 1–4 hours after payment confirmation. In rare cases during peak demand, delivery may take up to 12 hours." },
              ].map(({ q, a }) => (
                <details key={q} className="group rounded-xl border border-border bg-background p-4 transition-all hover:border-primary/20 [&[open]]:border-primary/20 [&[open]]:shadow-sm">
                  <summary className="flex cursor-pointer items-center justify-between gap-3 text-sm font-bold text-foreground list-none [&::-webkit-details-marker]:hidden">
                    <div className="flex items-center gap-2.5">
                      <HelpCircle className="h-4 w-4 shrink-0 text-primary" />
                      {q}
                    </div>
                    <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground transition-transform group-open:rotate-90" />
                  </summary>
                  <p className="mt-3 pl-[26px] text-sm leading-relaxed text-muted-foreground">{a}</p>
                </details>
              ))}
            </div>
          </div>
        </section>

        {/* ── CTA Banner ── */}
        <section className="py-16 md:py-24">
          <div className="container">
            <div className="rounded-2xl bg-gradient-to-br from-primary to-blue-600 p-8 text-center text-white md:p-14">
              <h2 className="mb-3 text-2xl font-extrabold md:text-4xl">Ready to Scale Your Advertising?</h2>
              <p className="mx-auto mb-8 max-w-xl text-sm text-white/80 md:text-base">
                Join 10,000+ advertisers who trust VBB STORE for verified Meta accounts. Get started today with fast delivery and 24/7 support.
              </p>
              <div className="flex flex-col items-center gap-3 sm:flex-row sm:justify-center">
                <Link to="/shop">
                  <Button size="lg" variant="secondary" className="w-full gap-2 font-bold sm:w-auto">
                    Browse Products <ArrowRight className="h-4 w-4" />
                  </Button>
                </Link>
                <a href="https://wa.me/8801302669333" target="_blank" rel="noopener noreferrer">
                  <Button size="lg" className="w-full gap-2 border border-white/30 bg-white/10 font-bold text-white hover:bg-white/20 sm:w-auto">
                    <MessageCircle className="h-5 w-5" /> WhatsApp Us
                  </Button>
                </a>
                <Link to="/contact">
                  <Button size="lg" className="w-full gap-2 border border-white/30 bg-white/10 font-bold text-white hover:bg-white/20 sm:w-auto">
                    <Send className="h-5 w-5" /> Contact Us
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
};

export default AboutPage;
