import { useState } from "react";
import { Link } from "react-router-dom";
import { MessageCircle, Send, Mail, Phone, Clock, Globe, Shield, Headphones, Star, CheckCircle2, ArrowRight, HelpCircle, ChevronRight, Zap, Users, Award, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import FloatingContact from "@/components/FloatingContact";
import { toast } from "sonner";
import { usePageSEO } from "@/hooks/use-page-seo";
import { supabase } from "@/integrations/supabase/client";

const ContactPage = () => {
  const [form, setForm] = useState({ name: "", email: "", subject: "", message: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [touched, setTouched] = useState<Record<string, boolean>>({});
  const [sending, setSending] = useState(false);

  usePageSEO({
    title: "Contact Us – 24/7 Support | VBB STORE",
    description: "Need help with your order? Have questions about our accounts? Reach us on WhatsApp, Telegram, or email. We reply fast, 24/7.",
    path: "/contact",
  });

  const validate = (f = form) => {
    const errs: Record<string, string> = {};
    if (!f.name.trim()) errs.name = "Name is required";
    if (!f.email.trim()) errs.email = "Email is required";
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(f.email)) errs.email = "Enter a valid email";
    if (!f.message.trim()) errs.message = "Message is required";
    return errs;
  };

  const handleBlur = (field: string) => {
    setTouched((t) => ({ ...t, [field]: true }));
    setErrors(validate());
  };

  const handleChange = (field: string, value: string) => {
    const updated = { ...form, [field]: value };
    setForm(updated);
    if (touched[field]) setErrors(validate(updated));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const errs = validate();
    setErrors(errs);
    setTouched({ name: true, email: true, message: true });
    if (Object.keys(errs).length > 0) return;

    setSending(true);
    try {
      const { error } = await supabase.from("contact_messages").insert({
        name: form.name.trim(),
        email: form.email.trim(),
        subject: form.subject.trim() || null,
        message: form.message.trim(),
      });
      if (error) throw error;
      toast.success("Message sent! We'll get back to you shortly.");
      setForm({ name: "", email: "", subject: "", message: "" });
      setTouched({});
      setErrors({});
    } catch {
      toast.error("Something went wrong. Please try again or contact us via WhatsApp.");
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />

      {/* ── Hero Banner ── */}
      <section className="relative overflow-hidden border-b border-border bg-gradient-to-br from-primary/5 via-background to-primary/10 py-16 md:py-24">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_50%,hsl(var(--primary)/0.08),transparent_60%)]" />
        <div className="container relative text-center">
          <Badge variant="secondary" className="mb-4 text-[10px] font-bold uppercase tracking-widest">24/7 Support</Badge>
          <h1 className="mb-4 text-3xl font-extrabold text-foreground md:text-5xl">
            Get in Touch With Us
          </h1>
          <p className="mx-auto max-w-2xl text-muted-foreground md:text-lg">
            Have questions about verified BM accounts, WhatsApp API, or need help with your order? Our support team is available around the clock to assist you.
          </p>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
            <a href="https://wa.me/8801302669333" target="_blank" rel="noopener noreferrer">
              <Button size="lg" className="gap-2 bg-green-600 hover:bg-green-700 text-white">
                <MessageCircle className="h-5 w-5" /> Chat on WhatsApp
              </Button>
            </a>
            <a href="https://t.me/Verifiedbmbuy" target="_blank" rel="noopener noreferrer">
              <Button size="lg" variant="outline" className="gap-2">
                <Send className="h-5 w-5" /> Message on Telegram
              </Button>
            </a>
          </div>
        </div>
      </section>

      {/* ── Stats Bar ── */}
      <section className="border-b border-border bg-card py-8">
        <div className="container">
          <div className="grid grid-cols-2 gap-6 md:grid-cols-4">
            {[
              { icon: Users, value: "5,000+", label: "Happy Customers" },
              { icon: Clock, value: "< 2 min", label: "Avg. Response Time" },
              { icon: Globe, value: "50+", label: "Countries Served" },
              { icon: Star, value: "4.9/5", label: "Support Rating" },
            ].map(({ icon: Icon, value, label }) => (
              <div key={label} className="flex flex-col items-center text-center">
                <div className="mb-2 flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10">
                  <Icon className="h-5 w-5 text-primary" />
                </div>
                <p className="text-xl font-extrabold text-foreground md:text-2xl">{value}</p>
                <p className="text-xs text-muted-foreground">{label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Contact Channels + Form ── */}
      <section className="py-12 md:py-16">
        <div className="container">
          <div className="mb-10 text-center">
            <Badge variant="secondary" className="mb-3 text-[10px] font-bold uppercase tracking-widest">Reach Us</Badge>
            <h2 className="text-2xl font-extrabold text-foreground md:text-3xl">Choose Your Preferred Channel</h2>
            <p className="mt-2 text-sm text-muted-foreground">We respond fastest on WhatsApp and Telegram — usually within minutes.</p>
          </div>

          <div className="grid gap-8 lg:grid-cols-5">
            {/* Contact Cards */}
            <div className="space-y-4 lg:col-span-2">
              <ContactChannelCard
                href="https://wa.me/8801302669333"
                icon={MessageCircle}
                iconColor="text-green-600"
                iconBg="bg-green-500/10"
                title="WhatsApp"
                subtitle="Instant chat support"
                detail="+880 1302 669333"
                badge="Fastest"
              />
              <ContactChannelCard
                href="https://t.me/Verifiedbmbuy"
                icon={Send}
                iconColor="text-primary"
                iconBg="bg-primary/10"
                title="Telegram"
                subtitle="Message us anytime"
                detail="@Verifiedbmbuy"
              />
              <ContactChannelCard
                href="mailto:support@vbbstore.com"
                icon={Mail}
                iconColor="text-primary"
                iconBg="bg-primary/10"
                title="Email"
                subtitle="For detailed inquiries"
                detail="support@vbbstore.com"
              />
              <ContactChannelCard
                href="https://m.me/101736778209833"
                icon={MessageSquare}
                iconColor="text-blue-600"
                iconBg="bg-blue-500/10"
                title="Messenger"
                subtitle="Facebook Messenger"
                detail="VBB Store"
              />

              {/* Office Hours */}
              <div className="rounded-xl border border-border bg-card p-5">
                <h3 className="mb-3 flex items-center gap-2 text-sm font-bold text-foreground">
                  <Clock className="h-4 w-4 text-primary" /> Support Hours
                </h3>
                <div className="space-y-2 text-sm text-muted-foreground">
                  <div className="flex justify-between"><span>WhatsApp & Telegram</span><span className="font-semibold text-green-600">24/7</span></div>
                  <div className="flex justify-between"><span>Email Response</span><span className="font-semibold text-foreground">Within 2 hours</span></div>
                  <div className="flex justify-between"><span>Order Processing</span><span className="font-semibold text-foreground">1–4 hours</span></div>
                </div>
              </div>
            </div>

            {/* Contact Form */}
            <form onSubmit={handleSubmit} className="rounded-xl border border-border bg-card p-6 lg:col-span-3">
              <h2 className="mb-1 text-xl font-extrabold text-foreground">Send Us a Message</h2>
              <p className="mb-6 text-sm text-muted-foreground">Fill out the form and we'll get back to you as soon as possible.</p>
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <Label htmlFor="c-name">Name <span className="text-destructive">*</span></Label>
                  <Input id="c-name" value={form.name} onChange={(e) => handleChange("name", e.target.value)} onBlur={() => handleBlur("name")} placeholder="Your name" className={touched.name && errors.name ? "border-destructive" : ""} />
                  {touched.name && errors.name && <p className="mt-1 text-xs font-medium text-destructive">{errors.name}</p>}
                </div>
                <div>
                  <Label htmlFor="c-email">Email <span className="text-destructive">*</span></Label>
                  <Input id="c-email" type="email" value={form.email} onChange={(e) => handleChange("email", e.target.value)} onBlur={() => handleBlur("email")} placeholder="your@email.com" className={touched.email && errors.email ? "border-destructive" : ""} />
                  {touched.email && errors.email && <p className="mt-1 text-xs font-medium text-destructive">{errors.email}</p>}
                </div>
              </div>
              <div className="mt-4">
                <Label htmlFor="c-subject">Subject</Label>
                <Input id="c-subject" value={form.subject} onChange={(e) => handleChange("subject", e.target.value)} placeholder="What's this about?" />
              </div>
              <div className="mt-4">
                <Label htmlFor="c-message">Message <span className="text-destructive">*</span></Label>
                <Textarea id="c-message" value={form.message} onChange={(e) => handleChange("message", e.target.value)} onBlur={() => handleBlur("message")} placeholder="Describe your question or request..." rows={5} className={touched.message && errors.message ? "border-destructive" : ""} />
                {touched.message && errors.message && <p className="mt-1 text-xs font-medium text-destructive">{errors.message}</p>}
              </div>
              <Button type="submit" className="mt-6 w-full gap-2" size="lg" disabled={sending}>
                {sending ? "Sending..." : <><Send className="h-4 w-4" /> Send Message</>}
              </Button>
              <p className="mt-3 text-center text-xs text-muted-foreground">We typically respond within 30 minutes during business hours.</p>
            </form>
          </div>
        </div>
      </section>

      {/* ── Why Contact Us ── */}
      <section className="border-t border-border bg-card py-12 md:py-16">
        <div className="container">
          <div className="mb-10 text-center">
            <Badge variant="secondary" className="mb-3 text-[10px] font-bold uppercase tracking-widest">Why Us</Badge>
            <h2 className="text-2xl font-extrabold text-foreground md:text-3xl">Why Customers Trust VBB STORE</h2>
          </div>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {[
              { icon: Headphones, title: "24/7 Live Support", desc: "Our team is always online — reach us anytime via WhatsApp, Telegram, or email for instant help." },
              { icon: Shield, title: "Secure Transactions", desc: "Every transaction is encrypted and secure. We never store sensitive credentials after delivery." },
              { icon: Zap, title: "Lightning-Fast Delivery", desc: "Most orders are delivered within 1–4 hours. We prioritize speed without compromising quality." },
              { icon: Award, title: "7-Day Replacement", desc: "All products come with a 7-day free replacement guarantee. No questions asked." },
              { icon: CheckCircle2, title: "Verified Products Only", desc: "We only sell fully verified, compliant accounts that are ready to use immediately." },
              { icon: Globe, title: "Global Coverage", desc: "Serving customers in 50+ countries worldwide with localized support and guidance." },
            ].map(({ icon: Icon, title, desc }) => (
              <div key={title} className="group rounded-xl border border-border bg-background p-5 transition-all hover:border-primary/20 hover:shadow-md">
                <div className="mb-3 flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-blue-600 shadow-md shadow-primary/20 transition-transform group-hover:scale-105">
                  <Icon className="h-5 w-5 text-white" />
                </div>
                <h3 className="mb-1 font-bold text-foreground">{title}</h3>
                <p className="text-sm leading-relaxed text-muted-foreground">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── How It Works ── */}
      <section className="border-t border-border py-12 md:py-16">
        <div className="container">
          <div className="mb-10 text-center">
            <Badge variant="secondary" className="mb-3 text-[10px] font-bold uppercase tracking-widest">Process</Badge>
            <h2 className="text-2xl font-extrabold text-foreground md:text-3xl">How Getting Support Works</h2>
          </div>
          <div className="mx-auto grid max-w-4xl gap-6 md:grid-cols-4">
            {[
              { step: 1, icon: MessageCircle, title: "Reach Out", desc: "Contact us via WhatsApp, Telegram, or the form above." },
              { step: 2, icon: Headphones, title: "Get Assisted", desc: "Our team will respond within minutes with a solution." },
              { step: 3, icon: CheckCircle2, title: "Issue Resolved", desc: "We work until your question or issue is fully resolved." },
              { step: 4, icon: Star, title: "Happy Customer", desc: "Join 5,000+ satisfied customers worldwide." },
            ].map(({ step, icon: Icon, title, desc }) => (
              <div key={step} className="relative text-center">
                <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-primary to-blue-600 text-lg font-extrabold text-white shadow-lg shadow-primary/20">
                  {step}
                </div>
                <h3 className="mb-1 font-bold text-foreground">{title}</h3>
                <p className="text-sm text-muted-foreground">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── FAQ ── */}
      <section className="border-t border-border bg-card py-12 md:py-16">
        <div className="container">
          <div className="mb-10 text-center">
            <Badge variant="secondary" className="mb-3 text-[10px] font-bold uppercase tracking-widest">FAQ</Badge>
            <h2 className="text-2xl font-extrabold text-foreground md:text-3xl">Frequently Asked Questions</h2>
            <p className="mt-2 text-sm text-muted-foreground">Quick answers to common questions about our support and services.</p>
          </div>
          <div className="mx-auto grid max-w-4xl gap-3 md:grid-cols-2">
            {[
              { q: "How fast will I get a response?", a: "WhatsApp and Telegram messages are typically answered within 2 minutes. Email responses take up to 2 hours." },
              { q: "What if I have an issue with my order?", a: "Contact us immediately via WhatsApp or Telegram. We offer a 7-day replacement guarantee on all products." },
              { q: "Do you offer pre-purchase consultations?", a: "Absolutely! Message us on WhatsApp or Telegram and we'll help you choose the right product for your needs." },
              { q: "What payment methods do you accept?", a: "We accept USDT (TRC20), Bitcoin (BTC), and Ethereum (ETH). Crypto ensures fast, secure transactions." },
              { q: "Can I get a refund?", a: "We offer replacements rather than refunds. If your product has any issues within 7 days, we'll replace it free of charge." },
              { q: "Do you provide setup assistance?", a: "Yes! Every purchase includes a setup guide, and our team is available 24/7 to walk you through the process." },
            ].map(({ q, a }) => (
              <details key={q} className="group rounded-xl border border-border bg-background p-4 transition-all hover:border-primary/20 [&[open]]:border-primary/20 [&[open]]:shadow-sm">
                <summary className="flex cursor-pointer items-center justify-between gap-3 text-sm font-bold text-foreground list-none [&::-webkit-details-marker]:hidden">
                  <div className="flex items-center gap-2.5">
                    <HelpCircle className="h-4 w-4 shrink-0 text-primary" />
                    {q}
                  </div>
                  <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground transition-transform group-open:rotate-90" />
                </summary>
                <p className="mt-3 pl-[26px] text-sm leading-relaxed text-muted-foreground">{a}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA Banner ── */}
      <section className="border-t border-border py-12 md:py-16">
        <div className="container">
          <div className="rounded-2xl bg-gradient-to-br from-primary to-blue-600 p-8 text-center text-white md:p-12">
            <h2 className="mb-3 text-2xl font-extrabold md:text-3xl">Ready to Get Started?</h2>
            <p className="mx-auto mb-6 max-w-xl text-sm text-white/80 md:text-base">
              Browse our verified products or chat with our team to find the perfect solution for your business.
            </p>
            <div className="flex flex-col items-center gap-3 sm:flex-row sm:justify-center">
              <a href="https://wa.me/8801302669333" target="_blank" rel="noopener noreferrer">
                <Button size="lg" variant="secondary" className="w-full gap-2 font-bold sm:w-auto">
                  <MessageCircle className="h-5 w-5" /> WhatsApp Us Now
                </Button>
              </a>
              <Link to="/shop">
                <Button size="lg" className="w-full gap-2 border border-white/30 bg-white/10 font-bold text-white hover:bg-white/20 sm:w-auto">
                  Browse Products <ArrowRight className="h-4 w-4" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      <Footer />
      <FloatingContact />
    </div>
  );
};

/* ── Sub-components ── */

const ContactChannelCard = ({ href, icon: Icon, iconColor, iconBg, title, subtitle, detail, badge }: {
  href: string; icon: any; iconColor: string; iconBg: string; title: string; subtitle: string; detail: string; badge?: string;
}) => (
  <a href={href} target="_blank" rel="noopener noreferrer" className="group flex items-center gap-4 rounded-xl border border-border bg-card p-4 transition-all hover:border-primary/20 hover:shadow-md">
    <div className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-xl ${iconBg}`}>
      <Icon className={`h-5 w-5 ${iconColor}`} />
    </div>
    <div className="min-w-0 flex-1">
      <div className="flex items-center gap-2">
        <p className="font-bold text-foreground">{title}</p>
        {badge && <Badge variant="secondary" className="text-[9px] font-bold uppercase">{badge}</Badge>}
      </div>
      <p className="text-xs text-muted-foreground">{subtitle}</p>
      <p className="text-sm font-medium text-foreground/80">{detail}</p>
    </div>
    <ArrowRight className="h-4 w-4 shrink-0 text-muted-foreground transition-transform group-hover:translate-x-1" />
  </a>
);

const MessageSquare = (props: any) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
);

export default ContactPage;
