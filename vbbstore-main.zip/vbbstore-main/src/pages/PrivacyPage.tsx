import Header from "@/components/Header";
import Footer from "@/components/Footer";
import FloatingContact from "@/components/FloatingContact";
import { useScrollReveal } from "@/hooks/use-scroll-reveal";
import { Shield, Eye, Database, Lock, Cookie, UserCheck, Bell, Mail } from "lucide-react";
import { usePageSEO } from "@/hooks/use-page-seo";

const sections = [
  { icon: Eye, title: "1. Information We Collect", content: `We collect minimal information necessary to process your orders and provide support. This includes your preferred contact method (WhatsApp, Telegram, or email), payment transaction details (cryptocurrency wallet addresses and transaction IDs), and communication history for support purposes.` },
  { icon: Database, title: "2. How We Use Your Information", content: `Your information is used solely for order processing, account delivery, customer support, and service improvement. We never sell, rent, or share your personal information with third parties for marketing purposes. Data is retained only as long as necessary for service delivery.` },
  { icon: Lock, title: "3. Data Security", content: `We implement industry-standard security measures to protect your data. All communications are encrypted, and payment transactions are processed through secure cryptocurrency networks. We regularly review our security practices to ensure the highest level of protection.` },
  { icon: Cookie, title: "4. Cookies & Tracking", content: `Our website uses essential cookies to ensure proper functionality. We may use analytics cookies to understand website usage and improve our services. You can control cookie preferences through your browser settings. We do not use cookies for targeted advertising.` },
  { icon: UserCheck, title: "5. Your Rights", content: `You have the right to access, correct, or delete your personal information at any time. You can request a copy of your data, ask us to update inaccurate information, or request complete data deletion. Contact our support team to exercise these rights.` },
  { icon: Shield, title: "6. Third-Party Services", content: `We may use third-party services for payment processing and analytics. These services have their own privacy policies and handle data according to their terms. We only work with trusted providers that maintain appropriate security standards.` },
  { icon: Bell, title: "7. Communications", content: `We may contact you regarding order updates, account delivery, and important service announcements. You can opt out of promotional communications at any time. Essential order-related communications cannot be opted out of during active transactions.` },
  { icon: Mail, title: "8. Policy Updates", content: `We may update this Privacy Policy periodically to reflect changes in our practices. Significant changes will be communicated through our website or direct notification. Continued use of our services after changes constitutes acceptance of the updated policy.` },
];

const PrivacyPage = () => {
  const { ref, visible } = useScrollReveal();

  usePageSEO({
    title: "Privacy Policy | VBB STORE",
    description: "We keep your data safe. Read how we collect, use, and protect your information.",
    path: "/privacy",
  });

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        {/* Hero */}
        <section className="relative overflow-hidden bg-gradient-to-br from-primary via-primary to-blue-700 py-20 md:py-28">
          <div className="absolute inset-0">
            <div className="absolute -right-32 -top-32 h-96 w-96 rounded-full bg-blue-400/20 blur-3xl" />
            <div className="absolute -bottom-20 -left-20 h-72 w-72 rounded-full bg-blue-300/15 blur-3xl" />
          </div>
          <div className="container relative z-10 text-center">
            <div className="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-2xl bg-white/10 backdrop-blur-sm">
              <Shield className="h-8 w-8 text-white" />
            </div>
            <h1 className="mb-4 text-4xl font-extrabold text-white md:text-5xl lg:text-6xl">Privacy Policy</h1>
            <p className="mx-auto max-w-2xl text-lg text-white/70">
              Your privacy matters to us. Learn how we collect, use, and protect your information.
            </p>
          </div>
        </section>

        {/* Content */}
        <section className="py-16 md:py-24" ref={ref}>
          <div className={`container mx-auto max-w-4xl transition-all duration-700 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}>
            <div className="space-y-6">
              {sections.map((s, i) => (
                <div
                  key={i}
                  className="group rounded-2xl border border-border bg-card p-7 shadow-sm transition-all duration-300 hover:shadow-lg hover:border-primary/20"
                >
                  <div className="mb-4 flex items-center gap-4">
                    <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-blue-600 shadow-lg shadow-primary/25">
                      <s.icon className="h-5 w-5 text-white" />
                    </div>
                    <h2 className="text-xl font-bold text-foreground">{s.title}</h2>
                  </div>
                  <p className="leading-relaxed text-muted-foreground">{s.content}</p>
                </div>
              ))}
            </div>

            <div className="mt-12 rounded-2xl border border-primary/20 bg-primary/5 p-8 text-center">
              <p className="text-sm text-muted-foreground">
                For privacy inquiries, contact us at{" "}
                <a href="mailto:info@verifiedbmbuy.com" className="font-semibold text-primary hover:underline">
                  info@verifiedbmbuy.com
                </a>.
              </p>
            </div>
          </div>
        </section>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
};

export default PrivacyPage;
