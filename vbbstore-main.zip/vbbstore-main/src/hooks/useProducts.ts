import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { products as staticProducts, type Product } from "@/data/products";
import { getProductImage } from "@/data/productImages";

export const useProducts = () => {
  const [products, setProducts] = useState<Product[]>(staticProducts);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      const { data, error } = await supabase
        .from("products")
        .select("*")
        .order("created_at", { ascending: false });

      if (error || !data || data.length === 0) {
        // Fallback to static data
        setLoading(false);
        return;
      }

      const mapped: Product[] = data.map((p: any) => ({
        id: p.id,
        slug: p.slug || p.id,
        name: p.name,
        category: p.category,
        price: p.price,
        originalPrice: p.original_price ?? undefined,
        description: p.description,
        features: p.features ?? [],
        image: p.image && p.image !== "/placeholder.svg" ? p.image : getProductImage(p.category),
        badge: p.badge ?? undefined,
        attributes: p.attributes ?? undefined,
      }));

      setProducts(mapped);
      setLoading(false);
    };

    fetchProducts();
  }, []);

  return { products, loading };
};

export const useProduct = (slugOrId: string | undefined) => {
  const { products, loading } = useProducts();
  const product = products.find((p) => p.slug === slugOrId || p.id === slugOrId);
  return { product, loading };
};
