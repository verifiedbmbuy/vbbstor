import { useEffect } from "react";

const BASE_URL = "https://verifiedbmbuy.com";
const OG_IMAGE = "https://verifiedbmbuy.com/og-image.png";

export const usePageSEO = ({
  title,
  description,
  path,
  ogImage,
  jsonLd,
}: {
  title: string;
  description: string;
  path: string;
  ogImage?: string;
  jsonLd?: Record<string, unknown> | Record<string, unknown>[];
}) => {
  useEffect(() => {
    document.title = title;

    const setMeta = (name: string, content: string, attr = "name") => {
      let el = document.querySelector(`meta[${attr}="${name}"]`);
      if (!el) {
        el = document.createElement("meta");
        el.setAttribute(attr, name);
        document.head.appendChild(el);
      }
      el.setAttribute("content", content);
    };

    const setLink = (rel: string, href: string, extra?: Record<string, string>) => {
      const selector = extra
        ? `link[rel="${rel}"][hreflang="${extra.hreflang}"]`
        : `link[rel="${rel}"]:not([hreflang])`;
      let el = document.querySelector(selector);
      if (!el) {
        el = document.createElement("link");
        el.setAttribute("rel", rel);
        if (extra) Object.entries(extra).forEach(([k, v]) => el!.setAttribute(k, v));
        document.head.appendChild(el);
      }
      (el as HTMLLinkElement).href = href;
    };

    const fullUrl = `${BASE_URL}${path}`;
    const image = ogImage || OG_IMAGE;

    // Meta description
    setMeta("description", description);

    // Robots – explicitly index, follow
    setMeta("robots", "index, follow, max-snippet:-1, max-image-preview:large");

    // Open Graph
    setMeta("og:title", title, "property");
    setMeta("og:description", description, "property");
    setMeta("og:url", fullUrl, "property");
    setMeta("og:type", "website", "property");
    setMeta("og:site_name", "VBB STORE", "property");
    setMeta("og:locale", "en_US", "property");
    setMeta("og:image", image, "property");
    setMeta("og:image:width", "1200", "property");
    setMeta("og:image:height", "630", "property");
    setMeta("og:image:alt", title, "property");

    // Twitter
    setMeta("twitter:card", "summary_large_image");
    setMeta("twitter:title", title);
    setMeta("twitter:description", description);
    setMeta("twitter:image", image);
    setMeta("twitter:site", "@vbbstore");
    setMeta("twitter:creator", "@vbbstore");

    // Canonical
    setLink("canonical", fullUrl);

    // Hreflang tags
    setLink("alternate", fullUrl, { hreflang: "en" });
    setLink("alternate", fullUrl, { hreflang: "x-default" });

    // WebPage JSON-LD (injected on every page)
    const webPageSchema = {
      "@context": "https://schema.org",
      "@type": "WebPage",
      name: title,
      description,
      url: fullUrl,
      inLanguage: "en",
      isPartOf: {
        "@type": "WebSite",
        name: "VBB STORE",
        url: BASE_URL,
      },
      publisher: {
        "@type": "Organization",
        name: "VBB STORE",
        url: BASE_URL,
        logo: {
          "@type": "ImageObject",
          url: `${BASE_URL}/favicon.ico`,
        },
      },
      primaryImageOfPage: {
        "@type": "ImageObject",
        url: image,
        width: "1200",
        height: "630",
      },
      potentialAction: {
        "@type": "ReadAction",
        target: {
          "@type": "EntryPoint",
          urlTemplate: fullUrl,
          actionPlatform: [
            "https://schema.org/DesktopWebPlatform",
            "https://schema.org/MobileWebPlatform",
          ],
        },
      },
    };

    // Inject WebPage schema
    let webPageScriptEl = document.querySelector('script[data-seo="webpage"]');
    if (!webPageScriptEl) {
      webPageScriptEl = document.createElement("script");
      webPageScriptEl.setAttribute("type", "application/ld+json");
      webPageScriptEl.setAttribute("data-seo", "webpage");
      document.head.appendChild(webPageScriptEl);
    }
    webPageScriptEl.textContent = JSON.stringify(webPageSchema);

    // Inject additional JSON-LD if provided
    let extraScriptEl = document.querySelector('script[data-seo="extra"]');
    if (jsonLd) {
      if (!extraScriptEl) {
        extraScriptEl = document.createElement("script");
        extraScriptEl.setAttribute("type", "application/ld+json");
        extraScriptEl.setAttribute("data-seo", "extra");
        document.head.appendChild(extraScriptEl);
      }
      const schemas = Array.isArray(jsonLd) ? jsonLd : [jsonLd];
      extraScriptEl.textContent = JSON.stringify(schemas.length === 1 ? schemas[0] : schemas);
    } else if (extraScriptEl) {
      extraScriptEl.remove();
    }

    return () => {
      document.querySelectorAll('link[rel="alternate"][hreflang]').forEach((el) => el.remove());
      document.querySelectorAll('script[data-seo]').forEach((el) => el.remove());
    };
  }, [title, description, path, ogImage, jsonLd]);
};
