import { TrendingUp, BarChart3, Users, Rocket } from "lucide-react";
import { Button } from "@/components/ui/button";

const ScaleAdvertising = () => {
  return (
    <section className="py-16 md:py-24 bg-gradient-to-b from-muted/30 to-muted/80">
      <div className="container">
        <div className="grid items-center gap-12 lg:grid-cols-2 animate-fade-in">
          <div>
            <p className="mb-3 text-sm font-bold uppercase tracking-widest text-primary">Scale Up</p>
            <h2 className="mb-6 text-3xl font-extrabold text-foreground md:text-4xl lg:text-5xl leading-tight">
              Ready to Spend More on Ads? You'll Need a Verified BM.
            </h2>
            <p className="mb-4 text-muted-foreground leading-relaxed">
              A verified Business Manager isn't just a status symbol — it's what lets you actually scale. Higher trust scores mean higher spend limits, more ad accounts, and access to features that unverified accounts simply don't get.
            </p>
            <p className="mb-8 text-muted-foreground leading-relaxed">
              Whether you're an agency juggling dozens of clients or a solo media buyer pushing for better ROI, a verified BM removes the ceiling on your growth.
            </p>
            <Button size="lg" className="rounded-xl shadow-lg shadow-primary/25 h-12 px-8 font-bold" onClick={() => document.getElementById("products")?.scrollIntoView({ behavior: "smooth" })}>
              <Rocket className="mr-2 h-5 w-5" /> Browse Products
            </Button>
          </div>
          <div className="grid grid-cols-2 gap-4">
            {[
              { icon: TrendingUp, label: "10x Scaling", desc: "Multiply your ad budget capacity", color: "from-blue-500 to-blue-600" },
              { icon: BarChart3, label: "Lower CPMs", desc: "Better delivery with higher trust", color: "from-primary to-blue-500" },
              { icon: Users, label: "Multi-Client", desc: "Manage multiple brands at once", color: "from-blue-600 to-primary" },
              { icon: Rocket, label: "No Spend Cap", desc: "Remove daily spending limits", color: "from-blue-500 to-blue-700" },
            ].map(({ icon: Icon, label, desc, color }) => (
              <div key={label} className="group rounded-2xl border border-border bg-card p-6 text-center shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-lg hover:border-primary/20">
                <div className={`mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br ${color} shadow-lg shadow-primary/20 transition-transform group-hover:scale-105`}>
                  <Icon className="h-7 w-7 text-white" />
                </div>
                <h3 className="mb-1 font-bold text-foreground">{label}</h3>
                <p className="text-xs text-muted-foreground">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ScaleAdvertising;
