import { useState, useEffect, useCallback } from "react";
import { Star, Quote, ChevronLeft, ChevronRight } from "lucide-react";
import { useScrollReveal } from "@/hooks/use-scroll-reveal";
import { Button } from "@/components/ui/button";

const reviews = [
  { name: "James W.", location: "USA", role: "Agency Owner", rating: 5, text: "Best verified BM provider I've ever used. Account was delivered in minutes and works flawlessly. Scaled our ad spend 5x within the first week. Highly recommend VBB STORE!" },
  { name: "Aisha K.", location: "UAE", role: "Digital Marketer", rating: 5, text: "Purchased 3 verified BMs for our agency. All came with genuine documentation and high trust scores. The team was professional and supportive throughout." },
  { name: "Markus S.", location: "Germany", role: "E-commerce Owner", rating: 5, text: "The WhatsApp API account was set up perfectly. Customer support was incredibly helpful throughout the process. Our customer engagement increased by 300%." },
  { name: "Priya M.", location: "India", role: "Performance Marketer", rating: 5, text: "Great quality accounts at competitive prices. The 7-day replacement guarantee gives extra peace of mind. Have been a repeat customer for over a year." },
  { name: "Lucas D.", location: "Brazil", role: "Media Buyer", rating: 5, text: "Fast delivery, real documentation, and the BM trust score was exactly as advertised. No restrictions, no bans. Will definitely buy again." },
  { name: "Sophie L.", location: "UK", role: "Agency Director", rating: 5, text: "Outstanding service! Got a verified BM and it exceeded my expectations. Support team is responsive 24/7. Best in the business." },
  { name: "Chen W.", location: "Singapore", role: "Growth Lead", rating: 5, text: "We've tried multiple providers before finding VBB STORE. The quality difference is night and day. Genuine verification, instant delivery, and zero issues." },
  { name: "Ahmed R.", location: "Saudi Arabia", role: "E-commerce Manager", rating: 5, text: "Bulk ordered 10 verified BMs for our clients. Every single one was perfect. The volume discount saved us thousands. Incredible value." },
  { name: "Maria G.", location: "Spain", role: "Freelance Advertiser", rating: 5, text: "As a solo advertiser, I needed a reliable BM. VBB STORE delivered exactly what I needed. My campaigns have never performed better." },
];

const Reviews = () => {
  const { ref, visible } = useScrollReveal();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);

  const getVisibleCount = () => {
    if (typeof window === "undefined") return 3;
    if (window.innerWidth < 640) return 1;
    if (window.innerWidth < 1024) return 2;
    return 3;
  };

  const [visibleCount, setVisibleCount] = useState(3);

  useEffect(() => {
    const handleResize = () => setVisibleCount(getVisibleCount());
    handleResize();
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  const maxIndex = Math.max(0, reviews.length - visibleCount);

  const next = useCallback(() => {
    setCurrentIndex((prev) => (prev >= maxIndex ? 0 : prev + 1));
  }, [maxIndex]);

  const prev = () => {
    setCurrentIndex((prev) => (prev <= 0 ? maxIndex : prev - 1));
  };

  useEffect(() => {
    if (!isAutoPlaying) return;
    const interval = setInterval(next, 4000);
    return () => clearInterval(interval);
  }, [isAutoPlaying, next]);

  const visibleReviews = reviews.slice(currentIndex, currentIndex + visibleCount);
  // Handle wrapping
  const displayReviews = visibleReviews.length < visibleCount
    ? [...visibleReviews, ...reviews.slice(0, visibleCount - visibleReviews.length)]
    : visibleReviews;

  return (
    <section className="py-16 md:py-24 bg-gradient-to-b from-muted/30 to-muted/80" ref={ref}>
      <div className="container">
        <div className={`mb-12 text-center transition-all duration-700 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}>
          <p className="mb-3 text-sm font-bold uppercase tracking-widest text-primary">Testimonials</p>
          <h2 className="mb-4 text-3xl font-extrabold text-foreground md:text-5xl">Customer Success Stories</h2>
          <p className="mx-auto max-w-2xl text-muted-foreground">
            Thousands of advertisers trust VBB STORE. Here's what they have to say.
          </p>
        </div>

        <div
          className={`relative transition-all duration-700 delay-150 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
          onMouseEnter={() => setIsAutoPlaying(false)}
          onMouseLeave={() => setIsAutoPlaying(true)}
        >
          {/* Cards */}
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {displayReviews.map((r, i) => (
              <div
                key={`${r.name}-${currentIndex}-${i}`}
                className="group relative flex flex-col rounded-2xl border border-border bg-card p-7 shadow-sm transition-all duration-500 hover:-translate-y-1 hover:shadow-lg hover:border-primary/20 animate-fade-in"
              >
                <Quote className="absolute right-5 top-5 h-8 w-8 text-primary/10" />
                <div className="mb-4 flex gap-0.5">
                  {Array.from({ length: 5 }).map((_, si) => (
                    <Star
                      key={si}
                      className={`h-4 w-4 ${si < r.rating ? "fill-yellow-400 text-yellow-400" : "text-border"}`}
                    />
                  ))}
                </div>
                <p className="mb-5 flex-1 text-sm leading-relaxed text-muted-foreground italic">"{r.text}"</p>
                <div className="flex items-center gap-3 border-t border-border pt-5">
                  <div className="flex h-11 w-11 items-center justify-center rounded-full bg-gradient-to-br from-primary to-blue-600 text-sm font-bold text-white shadow-md shadow-primary/20">
                    {r.name.charAt(0)}
                  </div>
                  <div>
                    <p className="font-bold text-foreground">{r.name}</p>
                    <p className="text-xs text-muted-foreground">{r.role} • {r.location}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Navigation */}
          <div className="mt-8 flex items-center justify-center gap-4">
            <Button
              variant="outline"
              size="icon"
              className="rounded-full h-10 w-10 shadow-sm"
              onClick={prev}
              aria-label="Previous reviews"
            >
              <ChevronLeft className="h-5 w-5" />
            </Button>

            <div className="flex gap-1.5" role="tablist" aria-label="Review pages">
              {Array.from({ length: maxIndex + 1 }).map((_, i) => (
                <button
                  key={i}
                  role="tab"
                  aria-selected={i === currentIndex}
                  aria-label={`Go to review page ${i + 1}`}
                  className={`h-2 rounded-full transition-all duration-300 ${
                    i === currentIndex ? "w-6 bg-primary" : "w-2 bg-border hover:bg-muted-foreground/30"
                  }`}
                  onClick={() => setCurrentIndex(i)}
                />
              ))}
            </div>

            <Button
              variant="outline"
              size="icon"
              className="rounded-full h-10 w-10 shadow-sm"
              onClick={next}
              aria-label="Next reviews"
            >
              <ChevronRight className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Reviews;
