import { Shield, Globe, Clock, Award } from "lucide-react";

const highlights = [
  { icon: Shield, value: "100%", label: "Verified Accounts" },
  { icon: Globe, value: "50+", label: "Countries Served" },
  { icon: Clock, value: "5+", label: "Years Experience" },
  { icon: Award, value: "10K+", label: "Happy Customers" },
];

const AboutUs = () => {
  return (
    <section id="about" className="py-16 md:py-24 bg-gradient-to-b from-muted/30 to-muted/80">
      <div className="container">
        <div className="animate-fade-in">
          <div className="grid gap-10 lg:grid-cols-2 lg:items-center">
            {/* Left - Text */}
            <div>
              <p className="mb-3 text-sm font-bold uppercase tracking-widest text-primary">About VBB Store</p>
              <h2 className="mb-6 text-3xl font-extrabold text-foreground md:text-5xl">
                Your Trusted Partner in{" "}
                <span className="text-gradient">Meta Advertising</span>
              </h2>
              <div className="space-y-4 text-muted-foreground leading-relaxed">
                <p>
                  VBB STORE started with a simple idea: advertisers need reliable, verified accounts without the hassle. We sell verified Facebook Business Managers, WhatsApp Business API accounts, Facebook Ads accounts, TikTok Ads, Google Ads, and reinstated profiles.
                </p>
                <p>
                  Every account we sell comes with genuine documentation. We don't cut corners on verification — that's why our customers keep coming back.
                </p>
                <p>
                  Over the past 5+ years, we've served more than 10,000 customers in 50+ countries. Whether you're a solo media buyer or an agency managing dozens of clients, we make it easy to get the accounts you need and start advertising right away.
                </p>
              </div>
            </div>

            {/* Right - Stats Grid */}
            <div className="grid grid-cols-2 gap-4">
              {highlights.map((h) => (
                <div key={h.label} className="group rounded-2xl border border-border bg-card p-6 text-center shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-lg hover:border-primary/20">
                  <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-blue-600 shadow-md shadow-primary/20 transition-transform group-hover:scale-110">
                    <h.icon className="h-6 w-6 text-white" />
                  </div>
                  <p className="text-2xl font-extrabold text-primary md:text-3xl">{h.value}</p>
                  <p className="mt-1 text-xs font-medium text-muted-foreground">{h.label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutUs;
