import { Shield, Award, Clock, Truck, Star, MessageCircle, Send, Facebook, Mail } from "lucide-react";
import { Button } from "@/components/ui/button";
import heroLogo from "@/assets/hero-logo.jpg";

const stats = [
  { icon: Shield, label: "Verified Accounts", value: "100%" },
  { icon: Award, label: "Best Quality", value: "A+ Rated" },
  { icon: Clock, label: "On Market", value: "5+ Years" },
  { icon: Truck, label: "Delivery", value: "Instant" },
];

const Hero = () => {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-background via-secondary/40 to-background py-16 md:py-24 lg:py-28">
      {/* Subtle background accents */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute -left-40 top-0 h-[500px] w-[500px] rounded-full bg-primary/[0.06] blur-[100px]" />
        <div className="absolute -right-32 bottom-0 h-[400px] w-[400px] rounded-full bg-primary/[0.04] blur-[100px]" />
      </div>

      <div className="container relative z-10">
        {/* Main two-column layout */}
        <div className="flex flex-col items-center gap-8 lg:flex-row lg:items-center lg:gap-12">
          {/* Left — Logo */}
          <div
            className="flex shrink-0 items-center justify-center lg:w-auto animate-hero-fade-left"
            style={{ animationDelay: "0.1s" }}
          >
            <div className="relative">
              <div className="absolute -inset-4 rounded-3xl bg-gradient-to-br from-primary/20 via-primary/5 to-transparent blur-2xl" />
              <div className="relative rounded-3xl animate-border-rotate p-[3px] shadow-2xl shadow-primary/20">
                <img
                  src={heroLogo}
                  alt="VBB - Verified BM Buy"
                  className="h-52 w-52 rounded-[22px] object-cover sm:h-72 sm:w-72 md:h-80 md:w-80 lg:h-80 lg:w-80 animate-hero-scale-in"
                  fetchPriority="high"
                  loading="eager"
                  width={320}
                  height={320}
                />
              </div>
            </div>
          </div>

          {/* Right — Content */}
          <div className="flex flex-1 flex-col items-center text-center lg:items-start lg:text-left">
            {/* Badge */}
            <div className="animate-hero-fade-right" style={{ animationDelay: "0.15s" }}>
              <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/5 px-4 py-1.5 text-xs font-semibold text-primary">
                <Star className="h-3.5 w-3.5 fill-primary" />
                <span>Best Verified Business Manager 2026</span>
                <span className="h-1.5 w-1.5 rounded-full bg-green-500 animate-pulse" />
              </div>
            </div>

            {/* H1 */}
            <h1
              className="mb-5 text-3xl font-extrabold tracking-tight text-foreground sm:text-4xl md:text-[2.75rem] lg:text-[2.85rem] xl:text-[3.25rem] animate-hero-fade-right"
              style={{ animationDelay: "0.25s" }}
            >
              Buy <span className="text-gradient">Verified BM</span> And
              <br />
              <span className="mt-3 block text-green-500">WhatsApp Business API</span>
            </h1>

            {/* Description */}
            <p
              className="mb-8 text-sm text-muted-foreground md:text-base leading-relaxed text-justify animate-hero-fade-right"
              style={{ animationDelay: "0.35s" }}
            >
              We sell verified Facebook Business Managers and WhatsApp Business API accounts — the real deal, with proper documentation. Need Facebook Ads, TikTok Ads, Google Ads accounts, or reinstated profiles? We've got those too. Every account is legit, secure, and ready to use. Over 10,000 advertisers trust us because we deliver what we promise, fast.
            </p>

            {/* Contact buttons */}
            <div
              className="flex flex-wrap items-center gap-3 lg:gap-4 w-full animate-hero-fade-right"
              style={{ animationDelay: "0.45s" }}
            >
              <a href="https://wa.me/8801302669333" target="_blank" rel="noopener noreferrer" className="flex-1 min-w-[120px]">
                <Button size="lg" className="w-full h-12 rounded-xl px-6 font-bold bg-green-800 hover:bg-green-900 text-white shadow-lg shadow-green-800/20 transition-all">
                  <MessageCircle className="mr-2 h-4 w-4" /> WhatsApp
                </Button>
              </a>
              <a href="https://t.me/Verifiedbmbuy" target="_blank" rel="noopener noreferrer" className="flex-1 min-w-[120px]">
                <Button size="lg" className="w-full h-12 rounded-xl px-6 font-bold bg-sky-800 hover:bg-sky-900 text-white shadow-lg shadow-sky-800/20 transition-all">
                  <Send className="mr-2 h-4 w-4" /> Telegram
                </Button>
              </a>
              <a href="http://m.me/101736778209833" target="_blank" rel="noopener noreferrer" className="flex-1 min-w-[120px]">
                <Button size="lg" className="w-full h-12 rounded-xl px-6 font-bold bg-blue-600 hover:bg-blue-700 text-white shadow-lg shadow-blue-600/20 transition-all">
                  <Facebook className="mr-2 h-4 w-4" /> Facebook
                </Button>
              </a>
              <a href="mailto:info@verifiedbmbuy.com" className="flex-1 min-w-[120px]">
                <Button size="lg" className="w-full h-12 rounded-xl border-2 px-6 font-bold bg-red-600 hover:bg-red-700 text-white shadow-lg shadow-red-600/20 transition-all">
                  <Mail className="mr-2 h-4 w-4" /> Email
                </Button>
              </a>
            </div>
          </div>
        </div>

        {/* Stats row */}
        <div
          className="mt-16 grid grid-cols-2 gap-3 md:grid-cols-4 animate-hero-fade-up"
          style={{ animationDelay: "0.55s" }}
        >
          {stats.map(({ icon: Icon, label, value }) => (
            <div
              key={label}
              className="group flex flex-col items-center gap-2.5 rounded-2xl border border-border bg-card p-5 shadow-sm transition-all hover:shadow-md hover:border-primary/20"
            >
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10">
                <Icon className="h-5 w-5 text-primary transition-transform group-hover:scale-110" />
              </div>
              <span className="text-lg font-bold text-foreground">{value}</span>
              <span className="text-xs font-medium text-muted-foreground">{label}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Hero;
