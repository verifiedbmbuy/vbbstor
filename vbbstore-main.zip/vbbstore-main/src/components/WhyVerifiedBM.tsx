import { ShieldCheck, TrendingUp, Users, Target, Globe, Zap, DollarSign, Lock, BarChart3, Layers, HeartHandshake } from "lucide-react";

const benefits = [
  { icon: ShieldCheck, title: "Higher Trust Score", desc: "Verified BMs are far less likely to get flagged or banned — Meta treats them differently." },
  { icon: TrendingUp, title: "Better Ad Results", desc: "Higher trust means your ads get delivered more often, at lower costs. Your ROI goes up." },
  { icon: Users, title: "Run Multiple Ad Accounts", desc: "One verified BM lets you manage several ad accounts — great for testing or running client campaigns." },
  { icon: Target, title: "Unlock Premium Tools", desc: "Get access to Meta features that aren't available to unverified accounts." },
  { icon: Globe, title: "Advertise Anywhere", desc: "No country restrictions. Run campaigns in any market you want." },
  { icon: Zap, title: "Faster Ad Approvals", desc: "Meta reviews your ads quicker when they know you're a verified business." },
  { icon: DollarSign, title: "Higher Spend Limits", desc: "Verified accounts can spend significantly more per day — no more hitting ceilings." },
  { icon: Lock, title: "Better Security", desc: "Extra layers of protection keep your ad accounts and data safe from unauthorized access." },
  { icon: BarChart3, title: "Detailed Analytics", desc: "Access reporting tools that give you deeper insights into your campaign performance." },
  { icon: Layers, title: "Multiple Pixels", desc: "Set up and manage several pixels for more precise audience tracking and retargeting." },
  { icon: HeartHandshake, title: "Easy Asset Sharing", desc: "Share pages, pixels, and ad accounts between agencies and clients without headaches." },
  { icon: ShieldCheck, title: "Fewer Restrictions", desc: "Verified accounts deal with far fewer random bans and limitations from Meta." },
];

const WhyVerifiedBM = () => {
  return (
    <section className="py-16 md:py-24 bg-gradient-to-b from-muted/30 to-muted/80">
      <div className="container">
        <div className="mb-12 text-center animate-fade-in">
          <p className="mb-3 text-sm font-bold uppercase tracking-widest text-primary">Why Verified BM?</p>
          <h2 className="mb-4 text-3xl font-extrabold text-foreground md:text-5xl">
            Why Smart Advertisers Use Verified BMs
          </h2>
          <p className="mx-auto max-w-2xl text-muted-foreground">
            If you're serious about Meta ads, a verified BM isn't optional — it's the foundation.
          </p>
        </div>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3 animate-fade-in">
          {benefits.map((b) => (
            <div key={b.title} className="group flex gap-4 rounded-2xl border border-border bg-card p-6 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-lg hover:border-primary/20">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-blue-600 shadow-md shadow-primary/20">
                <b.icon className="h-6 w-6 text-white" />
              </div>
              <div>
                <h3 className="mb-1 font-bold text-foreground">{b.title}</h3>
                <p className="text-sm leading-relaxed text-muted-foreground">{b.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default WhyVerifiedBM;
