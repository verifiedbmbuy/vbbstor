import { useState, useEffect, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Image, Upload, Loader2, X, Check, FolderOpen } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const BUCKET = "admin-assets";

interface MediaPickerProps {
  open: boolean;
  onClose: () => void;
  onSelect: (url: string) => void;
}

interface StorageFile {
  name: string;
  id: string;
  created_at: string;
}

const MediaPicker = ({ open, onClose, onSelect }: MediaPickerProps) => {
  const [files, setFiles] = useState<StorageFile[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [search, setSearch] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  const fetchFiles = async () => {
    setLoading(true);
    const { data: rootData } = await supabase.storage.from(BUCKET).list("", {
      limit: 200, sortBy: { column: "created_at", order: "desc" },
    });
    const { data: prodData } = await supabase.storage.from(BUCKET).list("products", {
      limit: 200, sortBy: { column: "created_at", order: "desc" },
    });

    const rootFiles = (rootData || []).filter(f => f.name && !f.name.endsWith("/"));
    const prodFiles = (prodData || []).map(f => ({ ...f, name: `products/${f.name}` }));
    setFiles([...rootFiles, ...prodFiles] as StorageFile[]);
    setLoading(false);
  };

  useEffect(() => {
    if (open) fetchFiles();
  }, [open]);

  const getPublicUrl = (name: string) => {
    const { data } = supabase.storage.from(BUCKET).getPublicUrl(name);
    return data.publicUrl;
  };

  const isImage = (name: string) => /\.(jpg|jpeg|png|gif|webp|svg|ico)$/i.test(name);

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = e.target.files;
    if (!selectedFiles || selectedFiles.length === 0) return;
    setUploading(true);
    for (const file of Array.from(selectedFiles)) {
      // Convert to WebP
      try {
        const bitmap = await createImageBitmap(file);
        const canvas = document.createElement("canvas");
        canvas.width = bitmap.width; canvas.height = bitmap.height;
        canvas.getContext("2d")!.drawImage(bitmap, 0, 0);
        const webpBlob = await new Promise<Blob>((resolve) => canvas.toBlob((b) => resolve(b!), "image/webp", 0.85));
        const fileName = `products/${Date.now()}-${crypto.randomUUID().slice(0, 8)}.webp`;
        await supabase.storage.from(BUCKET).upload(fileName, webpBlob, { cacheControl: "3600", contentType: "image/webp" });
      } catch {
        // Fallback: upload original
        const ext = file.name.split(".").pop();
        const fileName = `${Date.now()}-${crypto.randomUUID().slice(0, 8)}.${ext}`;
        await supabase.storage.from(BUCKET).upload(fileName, file, { cacheControl: "3600", contentType: file.type });
      }
    }
    setUploading(false);
    if (fileInputRef.current) fileInputRef.current.value = "";
    fetchFiles();
  };

  const filtered = files.filter(f => isImage(f.name) && f.name.toLowerCase().includes(search.toLowerCase()));

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4" onClick={onClose}>
      <div
        className="relative w-full max-w-3xl max-h-[85vh] flex flex-col overflow-hidden rounded-xl border border-border bg-card shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-border px-5 py-3">
          <h2 className="font-bold text-foreground">Choose from Media Library</h2>
          <button onClick={onClose} className="rounded-md p-1 hover:bg-muted text-muted-foreground hover:text-foreground">
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Search + Upload */}
        <div className="flex items-center gap-2 border-b border-border px-5 py-3">
          <Input
            placeholder="Search images..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="flex-1 text-sm"
          />
          <input ref={fileInputRef} type="file" multiple accept="image/*" className="hidden" onChange={handleUpload} />
          <Button variant="outline" size="sm" disabled={uploading} onClick={() => fileInputRef.current?.click()} className="gap-1.5 shrink-0">
            {uploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
            Upload New
          </Button>
        </div>

        {/* Grid */}
        <div className="flex-1 overflow-y-auto p-4">
          {loading ? (
            <div className="flex items-center justify-center gap-2 py-12 text-sm text-muted-foreground">
              <Loader2 className="h-5 w-5 animate-spin" /> Loading media…
            </div>
          ) : filtered.length === 0 ? (
            <div className="flex flex-col items-center gap-3 py-12 text-center">
              <FolderOpen className="h-12 w-12 text-muted-foreground/40" />
              <p className="text-sm text-muted-foreground">
                {search ? "No images match your search" : "No images uploaded yet"}
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-3 gap-3 sm:grid-cols-4 md:grid-cols-5">
              {filtered.map((file) => (
                <button
                  key={file.id || file.name}
                  onClick={() => {
                    onSelect(getPublicUrl(file.name));
                    onClose();
                  }}
                  className="group relative aspect-square overflow-hidden rounded-lg border border-border bg-muted transition-all hover:border-primary hover:ring-2 hover:ring-primary/20 focus:outline-none focus:ring-2 focus:ring-primary"
                >
                  <img
                    src={getPublicUrl(file.name)}
                    alt={file.name}
                    className="h-full w-full object-cover"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 flex items-center justify-center bg-primary/20 opacity-0 transition-opacity group-hover:opacity-100">
                    <div className="rounded-full bg-primary p-1.5">
                      <Check className="h-4 w-4 text-primary-foreground" />
                    </div>
                  </div>
                  <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/60 to-transparent p-1.5">
                    <p className="truncate text-[10px] text-white">{file.name.split("/").pop()}</p>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default MediaPicker;
