import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Mail, Trash2, Eye, EyeOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "sonner";

interface Message {
  id: string;
  name: string;
  email: string;
  subject: string;
  message: string;
  read: boolean;
  created_at: string;
}

const AdminMessages = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<Message | null>(null);

  const fetchMessages = async () => {
    const { data } = await supabase.from("contact_messages").select("*").order("created_at", { ascending: false });
    setMessages((data as Message[]) || []);
    setLoading(false);
  };

  useEffect(() => { fetchMessages(); }, []);

  const toggleRead = async (msg: Message) => {
    await supabase.from("contact_messages").update({ read: !msg.read }).eq("id", msg.id);
    fetchMessages();
  };

  const deleteMessage = async (id: string) => {
    await supabase.from("contact_messages").delete().eq("id", id);
    toast.success("Message deleted");
    if (selected?.id === id) setSelected(null);
    fetchMessages();
  };

  const unreadCount = messages.filter((m) => !m.read).length;

  if (loading) return <div className="text-muted-foreground">Loading...</div>;

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-extrabold text-foreground">Customer Messages</h1>
          <p className="text-sm text-muted-foreground">{unreadCount} unread message{unreadCount !== 1 ? "s" : ""}</p>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Message list */}
        <div className="lg:col-span-1 space-y-2 max-h-[600px] overflow-y-auto">
          {messages.length === 0 ? (
            <Card className="rounded-2xl p-8 text-center">
              <Mail className="mx-auto mb-3 h-10 w-10 text-muted-foreground/50" />
              <p className="text-muted-foreground">No messages yet</p>
            </Card>
          ) : (
            messages.map((msg) => (
              <Card
                key={msg.id}
                className={`cursor-pointer rounded-xl border p-4 transition-all hover:border-primary/30 ${
                  selected?.id === msg.id ? "border-primary bg-primary/5" : ""
                } ${!msg.read ? "border-l-4 border-l-primary" : ""}`}
                onClick={() => setSelected(msg)}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className={`text-sm truncate ${!msg.read ? "font-bold text-foreground" : "text-foreground"}`}>{msg.name}</p>
                    <p className="text-xs text-muted-foreground truncate">{msg.subject || "(No subject)"}</p>
                    <p className="mt-1 text-xs text-muted-foreground">{new Date(msg.created_at).toLocaleDateString()}</p>
                  </div>
                  {!msg.read && <div className="h-2.5 w-2.5 shrink-0 rounded-full bg-primary mt-1" />}
                </div>
              </Card>
            ))
          )}
        </div>

        {/* Message detail */}
        <div className="lg:col-span-2">
          {selected ? (
            <Card className="rounded-2xl border border-border p-6">
              <div className="mb-4 flex items-center justify-between">
                <div>
                  <h2 className="text-lg font-bold text-foreground">{selected.subject || "(No subject)"}</h2>
                  <p className="text-sm text-muted-foreground">From: {selected.name} &lt;{selected.email}&gt;</p>
                  <p className="text-xs text-muted-foreground">{new Date(selected.created_at).toLocaleString()}</p>
                </div>
                <div className="flex gap-1">
                  <Button variant="ghost" size="icon" onClick={() => toggleRead(selected)} className="h-8 w-8" title={selected.read ? "Mark unread" : "Mark read"}>
                    {selected.read ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                  <Button variant="ghost" size="icon" onClick={() => deleteMessage(selected.id)} className="h-8 w-8 text-destructive">
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              <div className="rounded-xl bg-muted/50 p-4 text-sm leading-relaxed text-foreground whitespace-pre-wrap">
                {selected.message}
              </div>
              <div className="mt-4">
                <a
                  href={`mailto:${selected.email}?subject=Re: ${selected.subject || "Your inquiry"}`}
                  className="inline-flex"
                >
                  <Button className="rounded-xl shadow-md shadow-primary/20">
                    <Mail className="mr-2 h-4 w-4" /> Reply via Email
                  </Button>
                </a>
              </div>
            </Card>
          ) : (
            <Card className="flex h-64 items-center justify-center rounded-2xl border border-border">
              <p className="text-muted-foreground">Select a message to view details</p>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
};

export default AdminMessages;
