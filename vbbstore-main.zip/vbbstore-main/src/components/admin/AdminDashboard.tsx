import { Package, FileText, ShoppingCart, DollarSign } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { useAdmin } from "@/context/AdminContext";

const AdminDashboard = () => {
  const { products, blogPosts, orders } = useAdmin();
  const totalRevenue = orders.filter(o => o.status === "completed").reduce((sum, o) => sum + o.amount, 0);
  const pendingOrders = orders.filter(o => o.status === "pending").length;

  const stats = [
    { label: "Total Products", value: products.length, icon: Package, color: "from-primary to-blue-600" },
    { label: "Blog Posts", value: blogPosts.length, icon: FileText, color: "from-green-500 to-green-600" },
    { label: "Pending Orders", value: pendingOrders, icon: ShoppingCart, color: "from-orange-500 to-orange-600" },
    { label: "Revenue", value: `$${totalRevenue}`, icon: DollarSign, color: "from-purple-500 to-purple-600" },
  ];

  return (
    <div>
      <h1 className="mb-6 text-2xl font-extrabold text-foreground">Dashboard</h1>
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((s) => (
          <Card key={s.label} className="rounded-2xl border border-border">
            <CardContent className="flex items-center gap-4 p-6">
              <div className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br ${s.color} shadow-md`}>
                <s.icon className="h-6 w-6 text-white" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">{s.label}</p>
                <p className="text-2xl font-extrabold text-foreground">{s.value}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="mt-8">
        <h2 className="mb-4 text-lg font-bold text-foreground">Recent Orders</h2>
        <Card className="rounded-2xl border border-border overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border bg-muted/50">
                  <th className="px-4 py-3 text-left font-semibold text-muted-foreground">Order ID</th>
                  <th className="px-4 py-3 text-left font-semibold text-muted-foreground">Product</th>
                  <th className="px-4 py-3 text-left font-semibold text-muted-foreground">Customer</th>
                  <th className="px-4 py-3 text-left font-semibold text-muted-foreground">Amount</th>
                  <th className="px-4 py-3 text-left font-semibold text-muted-foreground">Status</th>
                </tr>
              </thead>
              <tbody>
                {orders.slice(0, 5).map((order) => (
                  <tr key={order.id} className="border-b border-border last:border-0">
                    <td className="px-4 py-3 font-medium text-foreground">{order.id}</td>
                    <td className="px-4 py-3 text-muted-foreground">{order.product}</td>
                    <td className="px-4 py-3 text-muted-foreground">{order.customer}</td>
                    <td className="px-4 py-3 font-bold text-foreground">${order.amount}</td>
                    <td className="px-4 py-3">
                      <span className={`rounded-full px-2.5 py-1 text-xs font-bold ${
                        order.status === "completed" ? "bg-green-100 text-green-700" :
                        order.status === "pending" ? "bg-yellow-100 text-yellow-700" :
                        "bg-red-100 text-red-700"
                      }`}>
                        {order.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default AdminDashboard;
