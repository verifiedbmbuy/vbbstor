import { useState, useEffect, useRef, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Image, Upload, Trash2, Copy, Check, FolderOpen, Loader2, X, Save, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { toast } from "sonner";

interface StorageFile {
  name: string;
  id: string;
  created_at: string;
  metadata: Record<string, any> | null;
}

interface MediaSeo {
  id?: string;
  file_name: string;
  slug: string;
  alt_text: string;
  title: string;
  caption: string;
  description: string;
}

const BUCKET = "admin-assets";

const emptyMediaSeo: MediaSeo = { file_name: "", slug: "", alt_text: "", title: "", caption: "", description: "" };

const AdminMedia = () => {
  const [files, setFiles] = useState<StorageFile[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [copied, setCopied] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Detail modal
  const [selectedFile, setSelectedFile] = useState<StorageFile | null>(null);
  const [seoForm, setSeoForm] = useState<MediaSeo>(emptyMediaSeo);
  const [seoSaving, setSeoSaving] = useState(false);
  const [seoLoading, setSeoLoading] = useState(false);

  const fetchFiles = async () => {
    const { data, error } = await supabase.storage.from(BUCKET).list("", {
      limit: 200,
      sortBy: { column: "created_at", order: "desc" },
    });
    if (error) console.error("Error listing files:", error);

    // Also list products/ subfolder
    const { data: prodData } = await supabase.storage.from(BUCKET).list("products", {
      limit: 200,
      sortBy: { column: "created_at", order: "desc" },
    });

    const rootFiles = (data || []).filter(f => f.name && !f.name.endsWith("/")).map(f => f);
    const prodFiles = (prodData || []).map(f => ({ ...f, name: `products/${f.name}` }));

    setFiles([...rootFiles, ...prodFiles] as StorageFile[]);
    setLoading(false);
  };

  useEffect(() => { fetchFiles(); }, []);

  const getPublicUrl = (name: string) => {
    const { data } = supabase.storage.from(BUCKET).getPublicUrl(name);
    return data.publicUrl;
  };

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = e.target.files;
    if (!selectedFiles || selectedFiles.length === 0) return;
    setUploading(true);
    let successCount = 0;
    for (const file of Array.from(selectedFiles)) {
      const ext = file.name.split(".").pop();
      const fileName = `${Date.now()}-${crypto.randomUUID().slice(0, 8)}.${ext}`;
      const { error } = await supabase.storage.from(BUCKET).upload(fileName, file, {
        cacheControl: "3600",
        contentType: file.type,
      });
      if (error) toast.error(`Failed to upload ${file.name}: ${error.message}`);
      else successCount++;
    }
    if (successCount > 0) toast.success(`${successCount} file(s) uploaded`);
    setUploading(false);
    if (fileInputRef.current) fileInputRef.current.value = "";
    fetchFiles();
  };

  const handleDelete = async (name: string) => {
    const { error } = await supabase.storage.from(BUCKET).remove([name]);
    if (error) toast.error("Failed to delete file");
    else {
      toast.success("File deleted");
      await supabase.from("media_seo").delete().eq("file_name", name);
      if (selectedFile?.name === name) setSelectedFile(null);
      fetchFiles();
    }
  };

  const handleCopy = (name: string) => {
    const url = getPublicUrl(name);
    navigator.clipboard.writeText(url);
    setCopied(name);
    toast.success("URL copied");
    setTimeout(() => setCopied(null), 2000);
  };

  const isImage = (name: string) => /\.(jpg|jpeg|png|gif|webp|svg|ico)$/i.test(name);

  // Open detail modal
  const openDetail = useCallback(async (file: StorageFile) => {
    setSelectedFile(file);
    setSeoLoading(true);
    const { data } = await supabase
      .from("media_seo")
      .select("*")
      .eq("file_name", file.name)
      .maybeSingle();
    if (data) {
      setSeoForm({
        id: data.id,
        file_name: file.name,
        slug: (data as any).slug || "",
        alt_text: data.alt_text || "",
        title: data.title || "",
        caption: data.caption || "",
        description: data.description || "",
      });
    } else {
      // Auto-generate slug from filename
      const baseName = file.name.split("/").pop()?.replace(/\.[^.]+$/, "") || "";
      const autoSlug = baseName.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
      setSeoForm({ ...emptyMediaSeo, file_name: file.name, slug: autoSlug });
    }
    setSeoLoading(false);
  }, []);

  const saveSeo = async () => {
    setSeoSaving(true);
    const slug = seoForm.slug || seoForm.file_name.split("/").pop()?.replace(/\.[^.]+$/, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "") || "";
    const payload = {
      file_name: seoForm.file_name,
      slug,
      alt_text: seoForm.alt_text,
      title: seoForm.title,
      caption: seoForm.caption,
      description: seoForm.description,
    };
    const { error } = await supabase
      .from("media_seo")
      .upsert(payload, { onConflict: "file_name" });
    if (error) toast.error("Save failed: " + error.message);
    else toast.success("Image SEO saved");
    setSeoSaving(false);
  };

  return (
    <div>
      <input ref={fileInputRef} type="file" multiple accept="image/*" className="hidden" onChange={handleUpload} />

      <div className="mb-4 rounded border-l-4 border-[#2271b1] bg-white p-3 text-[13px] text-[#1d2327] shadow-sm">
        <strong>Media Library</strong> — Upload and manage images. Click any image to edit its SEO attributes.
      </div>

      {/* Upload area */}
      <Card
        className="mb-6 cursor-pointer rounded border border-dashed border-[#c3c4c7] bg-white p-8 text-center transition-colors hover:border-[#2271b1] hover:bg-[#f0f6fc]"
        onClick={() => !uploading && fileInputRef.current?.click()}
      >
        <div className="flex flex-col items-center gap-3">
          {uploading ? (
            <>
              <Loader2 className="h-10 w-10 animate-spin text-[#2271b1]" />
              <p className="text-sm text-[#646970]">Uploading...</p>
            </>
          ) : (
            <>
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-[#f0f0f1]">
                <Upload className="h-8 w-8 text-[#646970]" />
              </div>
              <p className="text-sm text-[#646970]">Drop files to upload or click to browse</p>
              <Button
                variant="outline"
                className="border-[#2271b1] text-[#2271b1] hover:bg-[#2271b1] hover:text-white text-[13px]"
                onClick={(e) => { e.stopPropagation(); fileInputRef.current?.click(); }}
              >
                Select Files
              </Button>
            </>
          )}
        </div>
      </Card>

      {loading && (
        <div className="flex items-center gap-2 py-8 text-[#646970] text-sm justify-center">
          <Loader2 className="h-5 w-5 animate-spin" /> Loading media...
        </div>
      )}

      {/* Media Grid */}
      {!loading && files.length > 0 && (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
          {files.map((file) => (
            <div
              key={file.id || file.name}
              className={`group relative overflow-hidden rounded border bg-white shadow-sm transition-shadow hover:shadow-md cursor-pointer ${selectedFile?.name === file.name ? "border-[#2271b1] ring-2 ring-[#2271b1]/30" : "border-[#c3c4c7]"}`}
              onClick={() => openDetail(file)}
            >
              <div className="aspect-square bg-[#f0f0f1] flex items-center justify-center overflow-hidden">
                {isImage(file.name) ? (
                  <img src={getPublicUrl(file.name)} alt={file.name} className="h-full w-full object-cover" loading="lazy" />
                ) : (
                  <Image className="h-10 w-10 text-[#a7aaad]" />
                )}
              </div>
              <div className="border-t border-[#c3c4c7] px-2 py-1.5">
                <p className="truncate text-[12px] font-medium text-[#1d2327]">{file.name.split("/").pop()}</p>
              </div>
              <div className="absolute inset-0 flex items-center justify-center gap-2 bg-black/60 opacity-0 transition-opacity group-hover:opacity-100">
                <button onClick={(e) => { e.stopPropagation(); handleCopy(file.name); }} className="rounded bg-white/90 p-2 text-[#1d2327] hover:bg-white" title="Copy URL">
                  {copied === file.name ? <Check className="h-4 w-4 text-green-600" /> : <Copy className="h-4 w-4" />}
                </button>
                <button onClick={(e) => { e.stopPropagation(); handleDelete(file.name); }} className="rounded bg-red-500/90 p-2 text-white hover:bg-red-600" title="Delete">
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {!loading && files.length === 0 && (
        <div className="flex flex-col items-center gap-3 py-16 text-center">
          <FolderOpen className="h-12 w-12 text-[#a7aaad]" />
          <p className="text-sm text-[#646970]">No media files uploaded yet</p>
        </div>
      )}

      {/* Image Detail & SEO Panel */}
      {selectedFile && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={() => setSelectedFile(null)}>
          <div className="relative w-full max-w-3xl max-h-[90vh] overflow-y-auto rounded-xl bg-white shadow-2xl" onClick={(e) => e.stopPropagation()}>
            {/* Header */}
            <div className="flex items-center justify-between border-b border-[#c3c4c7] px-5 py-3">
              <h2 className="text-sm font-bold text-[#1d2327]">Attachment Details</h2>
              <button onClick={() => setSelectedFile(null)} className="rounded p-1 hover:bg-[#f0f0f1]">
                <X className="h-5 w-5 text-[#646970]" />
              </button>
            </div>

            <div className="grid gap-6 p-5 md:grid-cols-2">
              {/* Left: Image Preview */}
              <div>
                {isImage(selectedFile.name) ? (
                  <img
                    src={getPublicUrl(selectedFile.name)}
                    alt={seoForm.alt_text || selectedFile.name}
                    className="w-full rounded-lg border border-[#c3c4c7] bg-[#f0f0f1] object-contain"
                    style={{ maxHeight: 400 }}
                  />
                ) : (
                  <div className="flex h-64 items-center justify-center rounded-lg border border-[#c3c4c7] bg-[#f0f0f1]">
                    <Image className="h-16 w-16 text-[#a7aaad]" />
                  </div>
                )}
                <div className="mt-3 space-y-1">
                  <p className="text-[12px] text-[#646970]"><strong>File:</strong> {selectedFile.name}</p>
                  <div className="flex gap-2 mt-2">
                    <Button variant="outline" size="sm" className="text-[12px]" onClick={() => handleCopy(selectedFile.name)}>
                      <Copy className="mr-1 h-3 w-3" /> Copy URL
                    </Button>
                    <Button variant="outline" size="sm" className="text-[12px] text-red-600 hover:text-red-700 border-red-200 hover:border-red-300" onClick={() => handleDelete(selectedFile.name)}>
                      <Trash2 className="mr-1 h-3 w-3" /> Delete
                    </Button>
                  </div>
                </div>
              </div>

              {/* Right: SEO Fields */}
              <div>
                {seoLoading ? (
                  <div className="flex items-center gap-2 py-8 text-[#646970] text-sm justify-center">
                    <Loader2 className="h-4 w-4 animate-spin" /> Loading SEO data...
                  </div>
                ) : (
                  <div className="space-y-3">
                    <h3 className="text-xs font-bold text-[#1d2327] uppercase tracking-wide flex items-center gap-1">
                     <Search className="h-3 w-3" /> Image SEO
                    </h3>

                    {/* Permalink / Slug */}
                    <div>
                      <label className="mb-1 block text-[12px] font-medium text-[#1d2327]">Permalink (Slug)</label>
                      <Input
                        value={seoForm.slug}
                        onChange={(e) => setSeoForm(f => ({ ...f, slug: e.target.value.toLowerCase().replace(/[^a-z0-9-]+/g, "-").replace(/(^-|-$)/g, "") }))}
                        placeholder="my-image-name"
                        className="h-8 text-[13px] border-[#8c8f94]"
                      />
                      {seoForm.slug && (
                        <div className="mt-1 flex items-center gap-1 rounded border border-[#c3c4c7] bg-[#f0f0f1] px-2 py-1">
                          <span className="text-[11px] font-semibold text-[#646970]">Permalink:</span>
                          <span className="text-[11px] text-[#2271b1] break-all">
                            https://verifiedbmbuy.com/media/{seoForm.slug}
                          </span>
                        </div>
                      )}
                    </div>

                    <div>
                      <label className="mb-1 block text-[12px] font-medium text-[#1d2327]">Alt Text <span className="text-[#646970] font-normal">(important for SEO & accessibility)</span></label>
                      <textarea
                        className="flex w-full rounded-md border border-[#8c8f94] bg-white px-3 py-2 text-[13px] focus:border-[#2271b1] focus:outline-none focus:ring-1 focus:ring-[#2271b1]"
                        rows={2}
                        value={seoForm.alt_text}
                        onChange={(e) => setSeoForm(f => ({ ...f, alt_text: e.target.value }))}
                        placeholder="Describe the image for search engines and screen readers"
                      />
                      <p className="mt-0.5 text-[11px] text-[#646970]">Describe the purpose of the image. Leave empty if decorative.</p>
                    </div>

                    <div>
                      <label className="mb-1 block text-[12px] font-medium text-[#1d2327]">Title</label>
                      <Input
                        value={seoForm.title}
                        onChange={(e) => setSeoForm(f => ({ ...f, title: e.target.value }))}
                        placeholder="Image title attribute"
                        className="h-8 text-[13px] border-[#8c8f94]"
                      />
                    </div>

                    <div>
                      <label className="mb-1 block text-[12px] font-medium text-[#1d2327]">Caption</label>
                      <textarea
                        className="flex w-full rounded-md border border-[#8c8f94] bg-white px-3 py-2 text-[13px] focus:border-[#2271b1] focus:outline-none focus:ring-1 focus:ring-[#2271b1]"
                        rows={2}
                        value={seoForm.caption}
                        onChange={(e) => setSeoForm(f => ({ ...f, caption: e.target.value }))}
                        placeholder="Caption displayed below the image"
                      />
                    </div>

                    <div>
                      <label className="mb-1 block text-[12px] font-medium text-[#1d2327]">Description</label>
                      <textarea
                        className="flex w-full rounded-md border border-[#8c8f94] bg-white px-3 py-2 text-[13px] focus:border-[#2271b1] focus:outline-none focus:ring-1 focus:ring-[#2271b1]"
                        rows={3}
                        value={seoForm.description}
                        onChange={(e) => setSeoForm(f => ({ ...f, description: e.target.value }))}
                        placeholder="Detailed description of the image"
                      />
                    </div>

                    <Button
                      onClick={saveSeo}
                      disabled={seoSaving}
                      size="sm"
                      className="bg-[#2271b1] hover:bg-[#135e96] text-white text-[13px]"
                    >
                      {seoSaving ? <Loader2 className="mr-1 h-3 w-3 animate-spin" /> : <Save className="mr-1 h-3 w-3" />}
                      Save Image SEO
                    </Button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminMedia;
