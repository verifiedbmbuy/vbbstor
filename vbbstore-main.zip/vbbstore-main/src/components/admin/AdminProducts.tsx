import { useState, useEffect, useRef, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Plus, Pencil, Trash2, X, Save, Upload, Loader2, Sparkles, PlusCircle, MinusCircle, Image, Eye, EyeOff } from "lucide-react";
import { SeoScoreIndicator } from "./SeoScoreIndicator";
import InlineSeoEditor from "./InlineSeoEditor";
import MediaPicker from "./MediaPicker";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";

interface Product {
  id: string;
  slug: string;
  name: string;
  category: string;
  price: number;
  original_price: number | null;
  description: string;
  features: string[];
  image: string;
  badge: string;
  published?: boolean;
  attributes?: Record<string, string>;
}

const emptyForm = {
  name: "", slug: "", category: "", price: 0, original_price: "",
  description: "", features: "", image: "/placeholder.svg", badge: "",
  published: true,
};

const emptyAttributes: Array<{ key: string; value: string }> = [];

const AdminProducts = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<Product | null>(null);
  const [adding, setAdding] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [attributes, setAttributes] = useState<Array<{ key: string; value: string }>>(emptyAttributes);
  const [imageUploading, setImageUploading] = useState(false);
  const imageInputRef = useRef<HTMLInputElement>(null);
  const [autoSavedId, setAutoSavedId] = useState<string | null>(null);
  const [autoSaveStatus, setAutoSaveStatus] = useState<string>("");
  const autoSaveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [generatingAI, setGeneratingAI] = useState<string | null>(null);
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [searchQuery, setSearchQuery] = useState("");
  const [mediaPickerOpen, setMediaPickerOpen] = useState(false);

  const fetchProducts = async () => {
    try {
      const { data, error } = await supabase.from("products").select("*").order("created_at", { ascending: false });
      if (error) { toast.error("Failed to load products: " + error.message); }
      setProducts((data as Product[]) || []);
    } catch (err: any) {
      toast.error("Failed to load products");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchProducts(); }, []);

  const startEdit = (p: Product) => {
    setEditing(p);
    setForm({
      name: p.name, slug: p.slug || "", category: p.category, price: p.price,
      original_price: p.original_price?.toString() || "",
      description: p.description, features: p.features.join(", "),
      image: p.image, badge: p.badge || "",
      published: p.published !== false,
    });
    // Load attributes
    const attrs = p.attributes || {};
    setAttributes(Object.entries(attrs).map(([key, value]) => ({ key, value: String(value) })));
    setAdding(false);
  };

  const startAdd = () => {
    setAdding(true); setEditing(null); setForm(emptyForm);
    setAttributes(emptyAttributes); setAutoSavedId(null); setAutoSaveStatus("");
  };

  const cancel = () => {
    setEditing(null); setAdding(false); setAutoSavedId(null); setAutoSaveStatus("");
    setAttributes(emptyAttributes); setFormErrors({});
    if (autoSaveTimer.current) clearTimeout(autoSaveTimer.current);
  };

  // Attributes helpers
  const addAttribute = () => setAttributes((prev) => [...prev, { key: "", value: "" }]);
  const removeAttribute = (index: number) => setAttributes((prev) => prev.filter((_, i) => i !== index));
  const updateAttribute = (index: number, field: "key" | "value", val: string) =>
    setAttributes((prev) => prev.map((a, i) => (i === index ? { ...a, [field]: val } : a)));

  const getAttributesObj = () => {
    const obj: Record<string, string> = {};
    attributes.forEach((a) => { if (a.key.trim()) obj[a.key.trim()] = a.value; });
    return obj;
  };

  // Auto-save as draft
  const autoSaveDraft = useCallback(async (currentForm: typeof emptyForm, editingProduct: Product | null, savedId: string | null) => {
    if (!currentForm.name.trim()) return;
    const slug = currentForm.slug || currentForm.name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
    const features = currentForm.features.split(",").map((f) => f.trim()).filter(Boolean);
    const row = {
      name: currentForm.name, slug, category: currentForm.category || "Uncategorized", price: currentForm.price || 0,
      original_price: currentForm.original_price ? Number(currentForm.original_price) : null,
      description: currentForm.description, features, image: currentForm.image, badge: currentForm.badge,
      published: false, attributes: getAttributesObj(),
    };
    try {
      if (editingProduct) {
        await supabase.from("products").update(row as any).eq("id", editingProduct.id);
        setAutoSaveStatus("Draft auto-saved");
      } else if (savedId) {
        await supabase.from("products").update(row as any).eq("id", savedId);
        setAutoSaveStatus("Draft auto-saved");
      } else {
        const { data } = await supabase.from("products").insert([row] as any).select();
        if (data && data[0]) { setAutoSavedId(data[0].id); setAutoSaveStatus("Draft auto-saved"); }
      }
      fetchProducts();
    } catch { /* silent */ }
  }, [attributes]);

  const triggerAutoSave = useCallback((newForm: typeof emptyForm) => {
    if (autoSaveTimer.current) clearTimeout(autoSaveTimer.current);
    if (!newForm.name.trim()) return;
    setAutoSaveStatus("Saving...");
    autoSaveTimer.current = setTimeout(() => { autoSaveDraft(newForm, editing, autoSavedId); }, 3000);
  }, [editing, autoSavedId, autoSaveDraft]);

  const updateForm = (updater: (f: typeof emptyForm) => typeof emptyForm) => {
    setForm((prev) => { const next = updater(prev); triggerAutoSave(next); return next; });
  };

  const validateProductForm = () => {
    const errs: Record<string, string> = {};
    if (!form.name.trim()) errs.name = "Product name is required";
    if (!form.category.trim()) errs.category = "Category is required";
    if (form.price <= 0) errs.price = "Price must be greater than 0";
    setFormErrors(errs);
    return errs;
  };

  const saveAsDraft = async () => {
    if (!form.name.trim()) { toast.error("At least a product name is required"); return; }
    try {
      const features = form.features.split(",").map((f) => f.trim()).filter(Boolean);
      const slug = form.slug || form.name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
      const row = {
        name: form.name, slug, category: form.category || "Uncategorized", price: form.price || 0,
        original_price: form.original_price ? Number(form.original_price) : null,
        description: form.description, features, image: form.image, badge: form.badge,
        published: false, attributes: getAttributesObj(),
      };
      if (editing) {
        const { error } = await supabase.from("products").update(row as any).eq("id", editing.id);
        if (error) { toast.error("Save draft failed: " + error.message); return; }
      } else {
        const { error } = await supabase.from("products").insert([row] as any).select();
        if (error) { toast.error("Save draft failed: " + error.message); return; }
      }
      toast.success("Saved as draft");
      cancel(); fetchProducts();
    } catch (err: any) { toast.error("Error: " + (err?.message || "Unknown")); }
  };

  const upsertCanonical = async (slug: string) => {
    const pagePath = `/product/${slug}`;
    const canonical = `https://verifiedbmbuy.com${pagePath}`;
    await supabase.from("seo_settings").upsert({ page_path: pagePath, canonical_url: canonical }, { onConflict: "page_path" });
  };

  const save = async () => {
    const errs = validateProductForm();
    if (Object.keys(errs).length > 0) { toast.info("Form incomplete — saving as draft"); await saveAsDraft(); return; }
    try {
      const features = form.features.split(",").map((f) => f.trim()).filter(Boolean);
      const slug = form.slug || form.name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
      const row = {
        name: form.name, slug, category: form.category, price: form.price,
        original_price: form.original_price ? Number(form.original_price) : null,
        description: form.description, features, image: form.image, badge: form.badge,
        published: form.published, attributes: getAttributesObj(),
      };
      if (editing) {
        const { error } = await supabase.from("products").update(row as any).eq("id", editing.id);
        if (error) { toast.error("Update failed: " + error.message); return; }
        toast.success("Product updated");
      } else {
        const { data, error } = await supabase.from("products").insert([row] as any).select();
        if (error) { toast.error("Add failed: " + error.message); return; }
        if (!data?.length) { toast.error("Product created but not confirmed"); return; }
        toast.success("Product added");
      }
      await upsertCanonical(slug);
      cancel(); fetchProducts();
    } catch (err: any) { toast.error("Error: " + (err?.message || "Unknown")); }
  };

  const togglePublish = async (id: string, currentlyPublished: boolean) => {
    const { error } = await supabase.from("products").update({ published: !currentlyPublished } as any).eq("id", id);
    if (error) { toast.error("Failed to update: " + error.message); return; }
    toast.success(currentlyPublished ? "Product unpublished" : "Product published");
    fetchProducts();
  };

  const deleteProduct = async (id: string) => {
    await supabase.from("products").delete().eq("id", id);
    toast.success("Product deleted");
    if (editing?.id === id) cancel();
    fetchProducts();
  };

  const generateAIDescription = async (productId: string) => {
    setGeneratingAI(productId);
    try {
      const resp = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/generate-description`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}` },
        body: JSON.stringify({ productId }),
      });
      const data = await resp.json();
      if (!resp.ok) throw new Error(data.error || "Failed");
      toast.success("AI description generated!");
      fetchProducts();
    } catch (e: any) { toast.error(e.message || "Failed"); }
    finally { setGeneratingAI(null); }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setImageUploading(true);
    try {
      const bitmap = await createImageBitmap(file);
      const canvas = document.createElement("canvas");
      canvas.width = bitmap.width; canvas.height = bitmap.height;
      canvas.getContext("2d")!.drawImage(bitmap, 0, 0);
      const webpBlob = await new Promise<Blob>((resolve) => canvas.toBlob((b) => resolve(b!), "image/webp", 0.85));
      const fileName = `products/${Date.now()}-${crypto.randomUUID().slice(0, 8)}.webp`;
      const { error } = await supabase.storage.from("admin-assets").upload(fileName, webpBlob, { cacheControl: "3600", contentType: "image/webp" });
      if (error) { toast.error("Upload failed: " + error.message); }
      else {
        const { data } = supabase.storage.from("admin-assets").getPublicUrl(fileName);
        setForm((f) => ({ ...f, image: data.publicUrl }));
        toast.success("Image uploaded");
      }
    } catch { toast.error("Failed to process image"); }
    setImageUploading(false);
    if (imageInputRef.current) imageInputRef.current.value = "";
  };

  const filteredProducts = products.filter((p) =>
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (loading) return (
    <div className="flex items-center gap-3 py-12 justify-center text-muted-foreground text-sm">
      <div className="h-5 w-5 animate-spin rounded-full border-2 border-primary border-t-transparent" />
      Loading products…
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-xl font-bold text-foreground">Products ({products.length})</h2>
          <p className="text-sm text-muted-foreground">Manage your product catalog</p>
        </div>
        <Button onClick={startAdd} className="gap-2 rounded-lg shadow-sm">
          <Plus className="h-4 w-4" /> Add Product
        </Button>
      </div>

      {/* Product Form */}
      {(editing || adding) && (
        <Card className="border border-border p-0 overflow-hidden">
          <div className="flex items-center justify-between border-b border-border bg-muted/30 px-5 py-3">
            <h3 className="font-bold text-foreground">{editing ? "Edit Product" : "New Product"}</h3>
            <Button variant="ghost" size="icon" onClick={cancel}><X className="h-4 w-4" /></Button>
          </div>

          <Tabs defaultValue="general" className="w-full">
            <div className="border-b border-border px-5">
              <TabsList className="h-10 bg-transparent p-0 gap-0">
                <TabsTrigger value="general" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent text-sm">General</TabsTrigger>
                <TabsTrigger value="details" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent text-sm">Details & Attributes</TabsTrigger>
                <TabsTrigger value="media" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent text-sm">Media</TabsTrigger>
                <TabsTrigger value="seo" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent text-sm">SEO</TabsTrigger>
              </TabsList>
            </div>

            {/* General Tab */}
            <TabsContent value="general" className="p-5 space-y-4 mt-0">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="sm:col-span-2">
                  <label className="mb-1 block text-sm font-medium text-muted-foreground">Name <span className="text-destructive">*</span></label>
                  <Input value={form.name} onChange={(e) => { updateForm((f) => ({ ...f, name: e.target.value })); if (formErrors.name) setFormErrors((fe) => ({ ...fe, name: "" })); }} className={formErrors.name ? "border-destructive" : ""} />
                  {formErrors.name && <p className="mt-1 text-xs text-destructive">{formErrors.name}</p>}
                  {form.name.trim() && (
                    <div className="mt-2 flex items-center gap-2 rounded-md bg-muted px-3 py-1.5">
                      <span className="text-[11px] font-medium text-muted-foreground">Permalink:</span>
                      <span className="text-[11px] text-primary break-all">
                        /product/{form.slug || form.name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "")}
                      </span>
                    </div>
                  )}
                </div>
                <div className="sm:col-span-2">
                  <label className="mb-1 block text-sm font-medium text-muted-foreground">Slug</label>
                  <Input value={form.slug} onChange={(e) => updateForm((f) => ({ ...f, slug: e.target.value }))} placeholder="auto-generated" className="text-sm" />
                </div>
                <div>
                  <label className="mb-1 block text-sm font-medium text-muted-foreground">Category <span className="text-destructive">*</span></label>
                  <Input value={form.category} onChange={(e) => { updateForm((f) => ({ ...f, category: e.target.value })); if (formErrors.category) setFormErrors((fe) => ({ ...fe, category: "" })); }} className={formErrors.category ? "border-destructive" : ""} />
                  {formErrors.category && <p className="mt-1 text-xs text-destructive">{formErrors.category}</p>}
                </div>
                <div>
                  <label className="mb-1 block text-sm font-medium text-muted-foreground">Badge</label>
                  <Input value={form.badge} onChange={(e) => updateForm((f) => ({ ...f, badge: e.target.value }))} placeholder="e.g. Best Seller" />
                </div>
                <div>
                  <label className="mb-1 block text-sm font-medium text-muted-foreground">Price ($) <span className="text-destructive">*</span></label>
                  <Input type="number" value={form.price} onChange={(e) => { updateForm((f) => ({ ...f, price: Number(e.target.value) })); if (formErrors.price) setFormErrors((fe) => ({ ...fe, price: "" })); }} className={formErrors.price ? "border-destructive" : ""} />
                  {formErrors.price && <p className="mt-1 text-xs text-destructive">{formErrors.price}</p>}
                </div>
                <div>
                  <label className="mb-1 block text-sm font-medium text-muted-foreground">Original Price ($)</label>
                  <Input value={form.original_price} onChange={(e) => updateForm((f) => ({ ...f, original_price: e.target.value }))} placeholder="Optional strikethrough price" />
                </div>
                <div className="sm:col-span-2">
                  <label className="mb-1 block text-sm font-medium text-muted-foreground">Description</label>
                  <textarea className="flex w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring min-h-[80px]" rows={3} value={form.description} onChange={(e) => updateForm((f) => ({ ...f, description: e.target.value }))} />
                </div>
                <div className="sm:col-span-2">
                  <label className="mb-1 block text-sm font-medium text-muted-foreground">Features (comma-separated)</label>
                  <Input value={form.features} onChange={(e) => updateForm((f) => ({ ...f, features: e.target.value }))} placeholder="Feature 1, Feature 2, Feature 3" />
                </div>
              </div>
            </TabsContent>

            {/* Details & Attributes Tab */}
            <TabsContent value="details" className="p-5 mt-0">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-sm font-bold text-foreground">Custom Attributes</h4>
                    <p className="text-xs text-muted-foreground">Add custom details like account type, spending limit, verification level, etc.</p>
                  </div>
                  <Button type="button" variant="outline" size="sm" onClick={addAttribute} className="gap-1.5 text-xs">
                    <PlusCircle className="h-3.5 w-3.5" /> Add Field
                  </Button>
                </div>

                {attributes.length === 0 && (
                  <div className="rounded-lg border-2 border-dashed border-border py-8 text-center">
                    <p className="text-sm text-muted-foreground mb-2">No custom attributes yet</p>
                    <p className="text-xs text-muted-foreground mb-3">Add fields like "Account Type", "Spending Limit", "Verification Level", etc.</p>
                    <Button type="button" variant="outline" size="sm" onClick={addAttribute} className="gap-1.5">
                      <PlusCircle className="h-3.5 w-3.5" /> Add First Attribute
                    </Button>
                  </div>
                )}

                {attributes.map((attr, i) => (
                  <div key={i} className="flex items-start gap-2">
                    <div className="flex-1">
                      <Input
                        value={attr.key}
                        onChange={(e) => updateAttribute(i, "key", e.target.value)}
                        placeholder="Field name (e.g. Account Type)"
                        className="text-sm"
                      />
                    </div>
                    <div className="flex-1">
                      <Input
                        value={attr.value}
                        onChange={(e) => updateAttribute(i, "value", e.target.value)}
                        placeholder="Value (e.g. Agency)"
                        className="text-sm"
                      />
                    </div>
                    <Button type="button" variant="ghost" size="icon" onClick={() => removeAttribute(i)} className="h-9 w-9 text-destructive hover:text-destructive shrink-0">
                      <MinusCircle className="h-4 w-4" />
                    </Button>
                  </div>
                ))}

                {attributes.length > 0 && (
                  <Button type="button" variant="ghost" size="sm" onClick={addAttribute} className="gap-1.5 text-xs text-muted-foreground">
                    <PlusCircle className="h-3.5 w-3.5" /> Add Another
                  </Button>
                )}

                {/* Quick presets */}
                <div className="border-t border-border pt-4">
                  <p className="mb-2 text-xs font-medium text-muted-foreground">Quick Presets:</p>
                  <div className="flex flex-wrap gap-1.5">
                    {[
                      { key: "Account Type", value: "" },
                      { key: "Spending Limit", value: "" },
                      { key: "Verification Level", value: "" },
                      { key: "Ad Accounts", value: "" },
                      { key: "Daily Limit", value: "" },
                      { key: "Region", value: "" },
                      { key: "Age", value: "" },
                      { key: "Platform", value: "" },
                      { key: "Delivery Time", value: "" },
                      { key: "Warranty", value: "" },
                    ].map((preset) => (
                      <button
                        key={preset.key}
                        type="button"
                        onClick={() => {
                          if (!attributes.some((a) => a.key === preset.key)) {
                            setAttributes((prev) => [...prev, { ...preset }]);
                          }
                        }}
                        className="rounded-md border border-border px-2.5 py-1 text-[11px] font-medium text-muted-foreground hover:bg-accent hover:text-foreground transition-colors"
                      >
                        + {preset.key}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </TabsContent>

            {/* Media Tab */}
            <TabsContent value="media" className="p-5 mt-0">
              <div className="space-y-4">
                <label className="block text-sm font-medium text-muted-foreground">Product Image</label>
                <input ref={imageInputRef} type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
                <div className="flex items-center gap-2 flex-wrap">
                  <Input value={form.image} onChange={(e) => setForm((f) => ({ ...f, image: e.target.value }))} placeholder="Image URL or upload" className="flex-1 min-w-[200px]" />
                  <Button type="button" variant="outline" size="sm" disabled={imageUploading} onClick={() => imageInputRef.current?.click()} className="gap-1.5">
                    {imageUploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
                    Upload
                  </Button>
                  <Button type="button" variant="outline" size="sm" onClick={() => setMediaPickerOpen(true)} className="gap-1.5">
                    <Image className="h-4 w-4" />
                    Choose from Media
                  </Button>
                </div>
                {form.image && form.image !== "/placeholder.svg" && (
                  <div className="rounded-lg border border-border p-3 inline-block bg-muted/30">
                    <img src={form.image} alt="Preview" className="h-32 w-32 rounded object-contain" />
                  </div>
                )}
              </div>
              <MediaPicker
                open={mediaPickerOpen}
                onClose={() => setMediaPickerOpen(false)}
                onSelect={(url) => setForm((f) => ({ ...f, image: url }))}
              />
            </TabsContent>

            {/* SEO Tab */}
            <TabsContent value="seo" className="p-5 mt-0">
              {(editing || autoSavedId) ? (
                <InlineSeoEditor
                  pagePath={`/product/${form.slug || form.name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "")}`}
                  defaultTitle={`${form.name} | VBB STORE`}
                  defaultDescription={form.description}
                  defaultSchemaType="Product"
                  defaultSchemaData={{ "@type": "Product", name: form.name, description: form.description, brand: { "@type": "Brand", name: "VBB STORE" }, offers: { "@type": "Offer", price: String(form.price), priceCurrency: "USD", availability: "https://schema.org/InStock" } }}
                />
              ) : (
                <p className="text-sm text-muted-foreground py-4">Save the product first to edit SEO settings.</p>
              )}
            </TabsContent>
          </Tabs>

          {/* Actions bar */}
          <div className="flex items-center gap-2 border-t border-border bg-muted/20 px-5 py-3">
            {autoSaveStatus && <span className="text-xs text-muted-foreground italic mr-auto">{autoSaveStatus}</span>}
            <div className="flex items-center gap-2 ml-auto">
              <Button variant="outline" onClick={cancel} size="sm">Cancel</Button>
              <Button variant="secondary" onClick={saveAsDraft} size="sm">Save as Draft</Button>
              <Button onClick={save} size="sm" className="gap-1.5">
                <Save className="h-3.5 w-3.5" /> {editing ? "Update" : "Publish"}
              </Button>
            </div>
          </div>
        </Card>
      )}

      {/* Search */}
      <div className="flex items-center gap-3">
        <Input
          placeholder="Search products..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="max-w-sm"
        />
      </div>

      {/* Products Table */}
      <Card className="border border-border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-muted/40">
                <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground uppercase tracking-wider">Image</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground uppercase tracking-wider">Name</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground uppercase tracking-wider">Category</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground uppercase tracking-wider">Price</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground uppercase tracking-wider">Badge</th>
                <th className="px-4 py-3 text-center text-xs font-semibold text-muted-foreground uppercase tracking-wider">SEO</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground uppercase tracking-wider">Status</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-muted-foreground uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredProducts.map((p) => (
                <tr key={p.id} className="border-b border-border last:border-0 hover:bg-muted/20 transition-colors">
                  <td className="px-4 py-3">
                    {p.image && p.image !== "/placeholder.svg" ? (
                      <img src={p.image} alt={p.name} className="h-10 w-10 rounded-md border border-border object-cover" />
                    ) : (
                      <div className="flex h-10 w-10 items-center justify-center rounded-md border border-border bg-muted text-[10px] text-muted-foreground">N/A</div>
                    )}
                  </td>
                  <td className="px-4 py-3">
                    <p className="font-medium text-foreground">{p.name}</p>
                    {p.attributes && Object.keys(p.attributes).length > 0 && (
                      <p className="text-[11px] text-muted-foreground">{Object.keys(p.attributes).length} attributes</p>
                    )}
                  </td>
                  <td className="px-4 py-3">
                    <span className="rounded-md bg-muted px-2 py-0.5 text-xs font-medium text-muted-foreground">{p.category}</span>
                  </td>
                  <td className="px-4 py-3 font-semibold text-foreground">${p.price}</td>
                  <td className="px-4 py-3">
                    {p.badge && <span className="rounded-md bg-primary/10 px-2 py-0.5 text-xs font-semibold text-primary">{p.badge}</span>}
                  </td>
                  <td className="px-4 py-3 text-center"><SeoScoreIndicator pagePath={`/product/${p.slug}`} /></td>
                  <td className="px-4 py-3">
                    <button
                      onClick={() => togglePublish(p.id, p.published !== false)}
                      className={`rounded-md px-2 py-0.5 text-xs font-semibold cursor-pointer transition-colors ${p.published !== false ? "bg-green-100 text-green-700 hover:bg-green-200" : "bg-yellow-100 text-yellow-700 hover:bg-yellow-200"}`}
                      title={p.published !== false ? "Click to unpublish" : "Click to publish"}
                    >
                      {p.published !== false ? "Published" : "Draft"}
                    </button>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-end gap-0.5">
                      <Button variant="ghost" size="icon" onClick={() => togglePublish(p.id, p.published !== false)} className="h-8 w-8" title={p.published !== false ? "Unpublish" : "Publish"}>
                        {p.published !== false ? <EyeOff className="h-4 w-4 text-muted-foreground" /> : <Eye className="h-4 w-4 text-green-600" />}
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => generateAIDescription(p.id)} disabled={generatingAI === p.id} className="h-8 w-8" title="AI Description">
                        {generatingAI === p.id ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4 text-primary" />}
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => startEdit(p)} className="h-8 w-8"><Pencil className="h-4 w-4" /></Button>
                      <Button variant="ghost" size="icon" onClick={() => deleteProduct(p.id)} className="h-8 w-8 text-destructive hover:text-destructive"><Trash2 className="h-4 w-4" /></Button>
                    </div>
                  </td>
                </tr>
              ))}
              {filteredProducts.length === 0 && (
                <tr><td colSpan={8} className="px-4 py-8 text-center text-sm text-muted-foreground">No products found</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
};

export default AdminProducts;
