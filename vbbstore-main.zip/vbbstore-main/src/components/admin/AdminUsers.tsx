import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Users, Shield, ShieldCheck, Trash2, UserPlus, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { toast } from "sonner";

interface UserRole {
  id: string;
  user_id: string;
  role: string;
}

const AdminUsers = () => {
  const [roles, setRoles] = useState<UserRole[]>([]);
  const [loading, setLoading] = useState(true);
  const [newUserId, setNewUserId] = useState("");
  const [newRole, setNewRole] = useState<"admin" | "user">("user");
  const [adding, setAdding] = useState(false);

  const fetchRoles = async () => {
    const { data, error } = await supabase.from("user_roles").select("*").order("role");
    if (error) {
      console.error("Fetch roles error:", error);
      toast.error("Failed to load user roles");
    }
    setRoles((data as UserRole[]) || []);
    setLoading(false);
  };

  useEffect(() => { fetchRoles(); }, []);

  const addRole = async () => {
    if (!newUserId.trim()) { toast.error("User ID is required"); return; }
    const { error } = await supabase.from("user_roles").insert({ user_id: newUserId.trim(), role: newRole });
    if (error) {
      toast.error("Failed: " + error.message);
      return;
    }
    toast.success("User role added");
    setNewUserId("");
    setAdding(false);
    fetchRoles();
  };

  const removeRole = async (id: string) => {
    const { error } = await supabase.from("user_roles").delete().eq("id", id);
    if (error) { toast.error("Failed: " + error.message); return; }
    toast.success("Role removed");
    fetchRoles();
  };

  if (loading) return <div className="text-muted-foreground">Loading users...</div>;

  const admins = roles.filter((r) => r.role === "admin");
  const users = roles.filter((r) => r.role === "user");

  return (
    <div>
      <div className="mb-5 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-extrabold text-foreground">Users & Roles</h1>
          <p className="text-sm text-muted-foreground">{roles.length} user role{roles.length !== 1 ? "s" : ""} configured</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={fetchRoles} className="rounded-xl">
            <RefreshCw className="mr-2 h-4 w-4" /> Refresh
          </Button>
          <Button onClick={() => setAdding(!adding)} className="rounded-xl shadow-md shadow-primary/20">
            <UserPlus className="mr-2 h-4 w-4" /> Add Role
          </Button>
        </div>
      </div>

      {adding && (
        <Card className="mb-5 rounded-2xl border border-primary/20 p-5">
          <h3 className="mb-3 text-sm font-bold text-foreground">Add User Role</h3>
          <div className="grid gap-3 sm:grid-cols-3">
            <div>
              <label className="mb-1 block text-xs font-medium text-muted-foreground">User ID (UUID)</label>
              <Input value={newUserId} onChange={(e) => setNewUserId(e.target.value)} placeholder="e.g. 903d95f4-3af0-43a2-8711-..." />
            </div>
            <div>
              <label className="mb-1 block text-xs font-medium text-muted-foreground">Role</label>
              <select className="flex w-full rounded-md border border-input bg-background px-3 py-2 text-sm" value={newRole} onChange={(e) => setNewRole(e.target.value as any)}>
                <option value="admin">Admin</option>
                <option value="user">User</option>
              </select>
            </div>
            <div className="flex items-end gap-2">
              <Button onClick={addRole} size="sm" className="rounded-xl">Add</Button>
              <Button variant="outline" size="sm" onClick={() => setAdding(false)} className="rounded-xl">Cancel</Button>
            </div>
          </div>
          <p className="mt-2 text-xs text-muted-foreground">
            Tip: You can find a user's UUID in the authentication dashboard.
          </p>
        </Card>
      )}

      <div className="grid gap-5 lg:grid-cols-2">
        {/* Admins */}
        <Card className="rounded-2xl border border-border p-5">
          <h3 className="mb-4 flex items-center gap-2 text-sm font-bold text-foreground">
            <ShieldCheck className="h-4 w-4 text-primary" /> Administrators ({admins.length})
          </h3>
          <div className="space-y-2">
            {admins.length === 0 ? (
              <p className="text-sm text-muted-foreground">No admin roles configured.</p>
            ) : (
              admins.map((r) => (
                <div key={r.id} className="flex items-center justify-between rounded-xl bg-primary/5 p-3">
                  <div>
                    <p className="text-sm font-mono text-foreground">{r.user_id}</p>
                    <span className="rounded-full bg-primary/10 px-2 py-0.5 text-xs font-bold text-primary">admin</span>
                  </div>
                  <Button variant="ghost" size="sm" onClick={() => removeRole(r.id)} className="h-8 text-destructive">
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))
            )}
          </div>
        </Card>

        {/* Users */}
        <Card className="rounded-2xl border border-border p-5">
          <h3 className="mb-4 flex items-center gap-2 text-sm font-bold text-foreground">
            <Users className="h-4 w-4 text-muted-foreground" /> Users ({users.length})
          </h3>
          <div className="space-y-2">
            {users.length === 0 ? (
              <p className="text-sm text-muted-foreground">No user roles configured.</p>
            ) : (
              users.map((r) => (
                <div key={r.id} className="flex items-center justify-between rounded-xl bg-muted/50 p-3">
                  <div>
                    <p className="text-sm font-mono text-foreground">{r.user_id}</p>
                    <span className="rounded-full bg-muted px-2 py-0.5 text-xs font-bold text-muted-foreground">user</span>
                  </div>
                  <Button variant="ghost" size="sm" onClick={() => removeRole(r.id)} className="h-8 text-destructive">
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))
            )}
          </div>
        </Card>
      </div>
    </div>
  );
};

export default AdminUsers;
