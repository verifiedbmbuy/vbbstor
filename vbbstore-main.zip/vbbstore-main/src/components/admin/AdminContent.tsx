import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Save } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { toast } from "sonner";

const contentKeys = [
  { key: "heroBadge", label: "Hero Badge Text" },
  { key: "heroTitle", label: "Hero Main Headline" },
  { key: "heroSubtitle", label: "Hero Subtitle" },
  { key: "aboutText", label: "About Section Text" },
];

const AdminContent = () => {
  const [values, setValues] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetch = async () => {
      const { data } = await supabase.from("site_content").select("key, value");
      const map: Record<string, string> = {};
      (data || []).forEach((r: any) => { map[r.key] = r.value; });
      setValues(map);
      setLoading(false);
    };
    fetch();
  }, []);

  const handleSave = async () => {
    for (const { key } of contentKeys) {
      if (values[key] !== undefined) {
        await supabase.from("site_content").upsert({ key, value: values[key] }, { onConflict: "key" });
      }
    }
    toast.success("Site content saved to database");
  };

  if (loading) return <div className="text-muted-foreground">Loading...</div>;

  return (
    <div>
      <h1 className="mb-6 text-2xl font-extrabold text-foreground">Site Content</h1>

      <div className="space-y-6">
        <Card className="rounded-2xl border border-border p-6">
          <h2 className="mb-4 text-lg font-bold text-foreground">Hero Section</h2>
          <div className="space-y-4">
            {contentKeys.filter((c) => c.key.startsWith("hero")).map((c) => (
              <div key={c.key}>
                <label className="mb-1 block text-sm font-medium text-muted-foreground">{c.label}</label>
                {c.key === "heroBadge" ? (
                  <Input value={values[c.key] || ""} onChange={(e) => setValues((v) => ({ ...v, [c.key]: e.target.value }))} />
                ) : (
                  <textarea
                    className="flex w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                    rows={c.key === "heroSubtitle" ? 3 : 2}
                    value={values[c.key] || ""}
                    onChange={(e) => setValues((v) => ({ ...v, [c.key]: e.target.value }))}
                  />
                )}
              </div>
            ))}
          </div>
        </Card>

        <Card className="rounded-2xl border border-border p-6">
          <h2 className="mb-4 text-lg font-bold text-foreground">About Section</h2>
          <textarea
            className="flex w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            rows={5}
            value={values.aboutText || ""}
            onChange={(e) => setValues((v) => ({ ...v, aboutText: e.target.value }))}
          />
        </Card>

        <Button onClick={handleSave} className="rounded-xl shadow-md shadow-primary/20">
          <Save className="mr-2 h-4 w-4" /> Save All Changes
        </Button>
      </div>
    </div>
  );
};

export default AdminContent;
