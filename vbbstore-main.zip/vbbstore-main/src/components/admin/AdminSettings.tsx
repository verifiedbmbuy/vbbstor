import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import {
  Save, Globe, Mail, Phone, MapPin, Facebook, Twitter,
  Instagram, Youtube, Store, CreditCard, Shield, Bell, Clock, Plus, Trash2
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";

const settingsKeys = [
  "store_name", "store_email", "store_phone", "store_address",
  "store_currency", "store_timezone", "store_language",
  "social_facebook", "social_twitter", "social_instagram", "social_youtube", "social_tiktok",
  "whatsapp_number", "telegram_link",
  "maintenance_mode", "order_notifications", "message_notifications",
  "google_analytics_id", "facebook_pixel_id",
  "checkout_note", "order_prefix",
];

const AdminSettings = () => {
  const [values, setValues] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [wallets, setWallets] = useState<{ label: string; key: string; address: string }[]>([]);
  const [newWalletLabel, setNewWalletLabel] = useState("");

  useEffect(() => {
    const fetch = async () => {
      const { data } = await supabase.from("site_content").select("key, value");
      const map: Record<string, string> = {};
      const walletList: { label: string; key: string; address: string }[] = [];
      (data || []).forEach((r: any) => {
        map[r.key] = r.value;
        if (r.key.startsWith("wallet_")) {
          const label = r.key.replace("wallet_", "").toUpperCase();
          walletList.push({ label, key: r.key, address: r.value });
        }
      });
      setValues(map);
      if (walletList.length === 0) {
        setWallets([
          { label: "USDT", key: "wallet_usdt", address: "" },
          { label: "BTC", key: "wallet_btc", address: "" },
          { label: "ETH", key: "wallet_eth", address: "" },
        ]);
      } else {
        setWallets(walletList);
      }
      setLoading(false);
    };
    fetch();
  }, []);

  const handleSave = async () => {
    setSaving(true);
    try {
      for (const key of settingsKeys) {
        if (values[key] !== undefined) {
          await supabase.from("site_content").upsert({ key, value: values[key] }, { onConflict: "key" });
        }
      }
      for (const w of wallets) {
        await supabase.from("site_content").upsert({ key: w.key, value: w.address }, { onConflict: "key" });
      }
      toast.success("Settings saved");
    } catch {
      toast.error("Failed to save settings");
    }
    setSaving(false);
  };

  const addWallet = () => {
    const label = newWalletLabel.trim();
    if (!label) { toast.error("Enter a wallet name"); return; }
    const key = "wallet_" + label.toLowerCase().replace(/[^a-z0-9]/g, "_");
    if (wallets.some((w) => w.key === key)) { toast.error("Wallet already exists"); return; }
    setWallets((prev) => [...prev, { label: label.toUpperCase(), key, address: "" }]);
    setNewWalletLabel("");
  };

  const removeWallet = async (key: string) => {
    await supabase.from("site_content").delete().eq("key", key);
    setWallets((prev) => prev.filter((w) => w.key !== key));
    toast.success("Wallet removed");
  };

  const updateWalletAddress = (key: string, address: string) => {
    setWallets((prev) => prev.map((w) => (w.key === key ? { ...w, address } : w)));
  };

  const update = (key: string, val: string) => setValues((v) => ({ ...v, [key]: val }));

  if (loading) return <div className="text-muted-foreground">Loading settings...</div>;

  return (
    <div>
      <div className="mb-5 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-extrabold text-foreground">Settings</h1>
          <p className="text-sm text-muted-foreground">Configure your store, social links, integrations and more.</p>
        </div>
        <Button onClick={handleSave} disabled={saving} className="rounded-xl shadow-md shadow-primary/20">
          <Save className="mr-2 h-4 w-4" /> {saving ? "Saving..." : "Save All"}
        </Button>
      </div>

      <Tabs defaultValue="general">
        <TabsList className="mb-5 rounded-xl bg-muted">
          <TabsTrigger value="general" className="rounded-lg text-xs"><Store className="mr-1 h-3.5 w-3.5" /> General</TabsTrigger>
          <TabsTrigger value="social" className="rounded-lg text-xs"><Globe className="mr-1 h-3.5 w-3.5" /> Social</TabsTrigger>
          <TabsTrigger value="notifications" className="rounded-lg text-xs"><Bell className="mr-1 h-3.5 w-3.5" /> Notifications</TabsTrigger>
          <TabsTrigger value="integrations" className="rounded-lg text-xs"><CreditCard className="mr-1 h-3.5 w-3.5" /> Integrations</TabsTrigger>
          <TabsTrigger value="advanced" className="rounded-lg text-xs"><Shield className="mr-1 h-3.5 w-3.5" /> Advanced</TabsTrigger>
        </TabsList>

        {/* General */}
        <TabsContent value="general">
          <div className="grid gap-5 lg:grid-cols-2">
            <Card className="rounded-2xl border border-border p-5">
              <h3 className="mb-4 text-sm font-bold text-foreground flex items-center gap-2"><Store className="h-4 w-4" /> Store Information</h3>
              <div className="space-y-4">
                <div>
                  <label className="mb-1 block text-sm font-medium text-muted-foreground">Store Name</label>
                  <Input value={values.store_name || ""} onChange={(e) => update("store_name", e.target.value)} placeholder="VBB STORE" />
                </div>
                <div>
                  <label className="mb-1 block text-sm font-medium text-muted-foreground">Order Number Prefix</label>
                  <Input value={values.order_prefix || ""} onChange={(e) => update("order_prefix", e.target.value)} placeholder="ORD-" />
                </div>
                <div>
                  <label className="mb-1 block text-sm font-medium text-muted-foreground">Default Currency</label>
                  <select className="flex w-full rounded-md border border-input bg-background px-3 py-2 text-sm" value={values.store_currency || "USD"} onChange={(e) => update("store_currency", e.target.value)}>
                    <option value="USD">USD ($)</option>
                    <option value="EUR">EUR (€)</option>
                    <option value="GBP">GBP (£)</option>
                    <option value="AED">AED (د.إ)</option>
                    <option value="SAR">SAR (﷼)</option>
                  </select>
                </div>
                <div>
                  <label className="mb-1 block text-sm font-medium text-muted-foreground">Timezone</label>
                  <select className="flex w-full rounded-md border border-input bg-background px-3 py-2 text-sm" value={values.store_timezone || "UTC"} onChange={(e) => update("store_timezone", e.target.value)}>
                    <option value="UTC">UTC</option>
                    <option value="America/New_York">Eastern Time (US)</option>
                    <option value="America/Los_Angeles">Pacific Time (US)</option>
                    <option value="Europe/London">London</option>
                    <option value="Asia/Dubai">Dubai</option>
                    <option value="Asia/Kolkata">India</option>
                  </select>
                </div>
              </div>
            </Card>

            <Card className="rounded-2xl border border-border p-5">
              <h3 className="mb-4 text-sm font-bold text-foreground flex items-center gap-2"><Mail className="h-4 w-4" /> Contact Details</h3>
              <div className="space-y-4">
                <div>
                  <label className="mb-1 block text-sm font-medium text-muted-foreground">Email Address</label>
                  <Input value={values.store_email || ""} onChange={(e) => update("store_email", e.target.value)} placeholder="info@verifiedbmbuy.com" />
                </div>
                <div>
                  <label className="mb-1 block text-sm font-medium text-muted-foreground">Phone Number</label>
                  <Input value={values.store_phone || ""} onChange={(e) => update("store_phone", e.target.value)} placeholder="+1 234 567 890" />
                </div>
                <div>
                  <label className="mb-1 block text-sm font-medium text-muted-foreground">WhatsApp Number</label>
                  <Input value={values.whatsapp_number || ""} onChange={(e) => update("whatsapp_number", e.target.value)} placeholder="+1 234 567 890" />
                </div>
                <div>
                  <label className="mb-1 block text-sm font-medium text-muted-foreground">Address</label>
                  <textarea className="flex w-full rounded-md border border-input bg-background px-3 py-2 text-sm" rows={2} value={values.store_address || ""} onChange={(e) => update("store_address", e.target.value)} placeholder="Store address..." />
                </div>
              </div>
            </Card>

            <Card className="rounded-2xl border border-border p-5 lg:col-span-2">
              <h3 className="mb-4 text-sm font-bold text-foreground">Checkout Settings</h3>
              <div>
                <label className="mb-1 block text-sm font-medium text-muted-foreground">Checkout Note / Instructions</label>
                <textarea className="flex w-full rounded-md border border-input bg-background px-3 py-2 text-sm" rows={3} value={values.checkout_note || ""} onChange={(e) => update("checkout_note", e.target.value)} placeholder="Instructions shown to customers during checkout..." />
              </div>
            </Card>

            <Card className="rounded-2xl border border-border p-5 lg:col-span-2">
              <h3 className="mb-4 text-sm font-bold text-foreground flex items-center gap-2"><CreditCard className="h-4 w-4" /> Crypto Wallet Addresses</h3>
              <p className="mb-4 text-xs text-muted-foreground">These wallet addresses are shown to customers at checkout for payment.</p>
              <div className="space-y-4">
                {wallets.map((w) => (
                  <div key={w.key} className="flex items-end gap-2">
                    <div className="flex-1">
                      <label className="mb-1 block text-sm font-medium text-muted-foreground">{w.label} Address</label>
                      <Input value={w.address} onChange={(e) => updateWalletAddress(w.key, e.target.value)} placeholder={`Enter ${w.label} wallet address`} className="font-mono text-xs" />
                    </div>
                    <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive" onClick={() => removeWallet(w.key)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
                <div className="flex items-end gap-2 pt-2 border-t border-border">
                  <div className="flex-1">
                    <label className="mb-1 block text-sm font-medium text-muted-foreground">New Wallet Name</label>
                    <Input value={newWalletLabel} onChange={(e) => setNewWalletLabel(e.target.value)} placeholder="e.g. LTC, BNB, SOL" />
                  </div>
                  <Button variant="outline" onClick={addWallet} className="rounded-xl">
                    <Plus className="mr-1 h-4 w-4" /> Add
                  </Button>
                </div>
              </div>
            </Card>
          </div>
        </TabsContent>

        {/* Social Links */}
        <TabsContent value="social">
          <Card className="rounded-2xl border border-border p-5">
            <h3 className="mb-4 text-sm font-bold text-foreground flex items-center gap-2"><Globe className="h-4 w-4" /> Social Media Links</h3>
            <div className="grid gap-4 sm:grid-cols-2">
              {[
                { key: "social_facebook", label: "Facebook", icon: Facebook, placeholder: "https://facebook.com/vbbstore" },
                { key: "social_twitter", label: "Twitter / X", icon: Twitter, placeholder: "https://x.com/vbbstore" },
                { key: "social_instagram", label: "Instagram", icon: Instagram, placeholder: "https://instagram.com/vbbstore" },
                { key: "social_youtube", label: "YouTube", icon: Youtube, placeholder: "https://youtube.com/@vbbstore" },
                { key: "social_tiktok", label: "TikTok", icon: Globe, placeholder: "https://tiktok.com/@vbbstore" },
                { key: "telegram_link", label: "Telegram", icon: Globe, placeholder: "https://t.me/vbbstore" },
              ].map((s) => (
                <div key={s.key}>
                  <label className="mb-1 flex items-center gap-1.5 text-sm font-medium text-muted-foreground">
                    <s.icon className="h-3.5 w-3.5" /> {s.label}
                  </label>
                  <Input value={values[s.key] || ""} onChange={(e) => update(s.key, e.target.value)} placeholder={s.placeholder} />
                </div>
              ))}
            </div>
          </Card>
        </TabsContent>

        {/* Notifications */}
        <TabsContent value="notifications">
          <Card className="rounded-2xl border border-border p-5">
            <h3 className="mb-4 text-sm font-bold text-foreground flex items-center gap-2"><Bell className="h-4 w-4" /> Notification Preferences</h3>
            <div className="space-y-5">
              {[
                { key: "order_notifications", label: "Order Notifications", desc: "Get notified when new orders are placed" },
                { key: "message_notifications", label: "Message Notifications", desc: "Get notified when customers send messages" },
              ].map((n) => (
                <div key={n.key} className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-foreground">{n.label}</p>
                    <p className="text-xs text-muted-foreground">{n.desc}</p>
                  </div>
                  <Switch
                    checked={values[n.key] === "true"}
                    onCheckedChange={(v) => update(n.key, v ? "true" : "false")}
                  />
                </div>
              ))}
            </div>
          </Card>
        </TabsContent>

        {/* Integrations */}
        <TabsContent value="integrations">
          <Card className="rounded-2xl border border-border p-5">
            <h3 className="mb-4 text-sm font-bold text-foreground flex items-center gap-2"><CreditCard className="h-4 w-4" /> Tracking & Analytics</h3>
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label className="mb-1 block text-sm font-medium text-muted-foreground">Google Analytics ID</label>
                <Input value={values.google_analytics_id || ""} onChange={(e) => update("google_analytics_id", e.target.value)} placeholder="G-XXXXXXXXXX" />
              </div>
              <div>
                <label className="mb-1 block text-sm font-medium text-muted-foreground">Facebook Pixel ID</label>
                <Input value={values.facebook_pixel_id || ""} onChange={(e) => update("facebook_pixel_id", e.target.value)} placeholder="1234567890" />
              </div>
            </div>
          </Card>
        </TabsContent>

        {/* Advanced */}
        <TabsContent value="advanced">
          <Card className="rounded-2xl border border-border p-5">
            <h3 className="mb-4 text-sm font-bold text-foreground flex items-center gap-2"><Shield className="h-4 w-4" /> Advanced Settings</h3>
            <div className="space-y-5">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-foreground">Maintenance Mode</p>
                  <p className="text-xs text-muted-foreground">Put your site into maintenance mode. Only admins can access.</p>
                </div>
                <Switch
                  checked={values.maintenance_mode === "true"}
                  onCheckedChange={(v) => update("maintenance_mode", v ? "true" : "false")}
                />
              </div>
              <div>
                <label className="mb-1 block text-sm font-medium text-muted-foreground">Store Language</label>
                <select className="flex w-full rounded-md border border-input bg-background px-3 py-2 text-sm" value={values.store_language || "en"} onChange={(e) => update("store_language", e.target.value)}>
                  <option value="en">English</option>
                  <option value="ar">Arabic</option>
                  <option value="fr">French</option>
                  <option value="es">Spanish</option>
                  <option value="de">German</option>
                </select>
              </div>
            </div>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AdminSettings;
