import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Plus, Trash2, Save, X, Tag } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";

interface Coupon {
  id: string;
  code: string;
  discount_type: string;
  discount_value: number;
  min_order: number;
  max_uses: number | null;
  used_count: number;
  active: boolean;
  expires_at: string | null;
  created_at: string;
}

const AdminCoupons: React.FC = () => {
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [loading, setLoading] = useState(true);
  const [adding, setAdding] = useState(false);
  const [form, setForm] = useState({
    code: "", discount_type: "percentage", discount_value: 10, min_order: 0, max_uses: "", expires_at: "",
  });

  const fetchCoupons = async () => {
    const { data } = await supabase.from("coupons").select("*").order("created_at", { ascending: false });
    setCoupons((data as Coupon[]) || []);
    setLoading(false);
  };

  useEffect(() => { fetchCoupons(); }, []);

  const addCoupon = async () => {
    if (!form.code) { toast.error("Coupon code is required"); return; }
    const insert: Record<string, unknown> = {
      code: form.code.toUpperCase(),
      discount_type: form.discount_type,
      discount_value: form.discount_value,
      min_order: form.min_order,
    };
    if (form.max_uses) insert.max_uses = parseInt(form.max_uses);
    if (form.expires_at) insert.expires_at = form.expires_at;

    const { error } = await supabase.from("coupons").insert([insert as any]);
    if (error) { toast.error(error.message); return; }
    toast.success("Coupon created");
    setAdding(false);
    setForm({ code: "", discount_type: "percentage", discount_value: 10, min_order: 0, max_uses: "", expires_at: "" });
    fetchCoupons();
  };

  const toggleActive = async (coupon: Coupon) => {
    await supabase.from("coupons").update({ active: !coupon.active }).eq("id", coupon.id);
    fetchCoupons();
  };

  const deleteCoupon = async (id: string) => {
    await supabase.from("coupons").delete().eq("id", id);
    toast.success("Coupon deleted");
    fetchCoupons();
  };

  if (loading) return <div className="text-muted-foreground">Loading...</div>;

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-extrabold text-foreground">Coupons & Discounts</h1>
        <Button onClick={() => setAdding(true)} className="rounded-xl shadow-md shadow-primary/20">
          <Plus className="mr-2 h-4 w-4" /> Create Coupon
        </Button>
      </div>

      {adding && (
        <Card className="mb-6 rounded-2xl border border-primary/20 p-6">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-lg font-bold text-foreground">New Coupon</h2>
            <Button variant="ghost" size="icon" onClick={() => setAdding(false)}><X className="h-4 w-4" /></Button>
          </div>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            <div>
              <label className="mb-1 block text-sm font-medium text-muted-foreground">Code</label>
              <Input value={form.code} onChange={(e) => setForm((f) => ({ ...f, code: e.target.value }))} placeholder="SAVE20" className="uppercase" />
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium text-muted-foreground">Type</label>
              <select
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                value={form.discount_type}
                onChange={(e) => setForm((f) => ({ ...f, discount_type: e.target.value }))}
              >
                <option value="percentage">Percentage (%)</option>
                <option value="fixed">Fixed ($)</option>
              </select>
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium text-muted-foreground">Value</label>
              <Input type="number" value={form.discount_value} onChange={(e) => setForm((f) => ({ ...f, discount_value: Number(e.target.value) }))} />
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium text-muted-foreground">Min Order ($)</label>
              <Input type="number" value={form.min_order} onChange={(e) => setForm((f) => ({ ...f, min_order: Number(e.target.value) }))} />
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium text-muted-foreground">Max Uses (blank = unlimited)</label>
              <Input value={form.max_uses} onChange={(e) => setForm((f) => ({ ...f, max_uses: e.target.value }))} placeholder="Unlimited" />
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium text-muted-foreground">Expires At</label>
              <Input type="datetime-local" value={form.expires_at} onChange={(e) => setForm((f) => ({ ...f, expires_at: e.target.value }))} />
            </div>
          </div>
          <div className="mt-4 flex gap-2">
            <Button onClick={addCoupon} className="rounded-xl shadow-md shadow-primary/20">
              <Save className="mr-2 h-4 w-4" /> Create Coupon
            </Button>
            <Button variant="outline" onClick={() => setAdding(false)} className="rounded-xl">Cancel</Button>
          </div>
        </Card>
      )}

      <Card className="rounded-2xl border border-border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-muted/50">
                <th className="px-4 py-3 text-left font-semibold text-muted-foreground">Code</th>
                <th className="px-4 py-3 text-left font-semibold text-muted-foreground">Discount</th>
                <th className="px-4 py-3 text-left font-semibold text-muted-foreground">Min Order</th>
                <th className="px-4 py-3 text-left font-semibold text-muted-foreground">Usage</th>
                <th className="px-4 py-3 text-left font-semibold text-muted-foreground">Expires</th>
                <th className="px-4 py-3 text-left font-semibold text-muted-foreground">Active</th>
                <th className="px-4 py-3 text-right font-semibold text-muted-foreground">Actions</th>
              </tr>
            </thead>
            <tbody>
              {coupons.length === 0 ? (
                <tr><td colSpan={7} className="px-4 py-8 text-center text-muted-foreground">No coupons yet</td></tr>
              ) : (
                coupons.map((c) => (
                  <tr key={c.id} className="border-b border-border last:border-0 hover:bg-muted/30 transition-colors">
                    <td className="px-4 py-3">
                      <span className="inline-flex items-center gap-1.5 rounded-full bg-primary/10 px-3 py-1 font-mono text-xs font-bold text-primary">
                        <Tag className="h-3 w-3" /> {c.code}
                      </span>
                    </td>
                    <td className="px-4 py-3 font-bold text-foreground">
                      {c.discount_type === "percentage" ? `${c.discount_value}%` : `$${c.discount_value}`}
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">${c.min_order}</td>
                    <td className="px-4 py-3 text-muted-foreground">{c.used_count}/{c.max_uses ?? "∞"}</td>
                    <td className="px-4 py-3 text-muted-foreground">{c.expires_at ? new Date(c.expires_at).toLocaleDateString() : "Never"}</td>
                    <td className="px-4 py-3">
                      <Switch checked={c.active} onCheckedChange={() => toggleActive(c)} />
                    </td>
                    <td className="px-4 py-3 text-right">
                      <Button variant="ghost" size="icon" onClick={() => deleteCoupon(c.id)} className="h-8 w-8 text-destructive">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
};

export default AdminCoupons;
