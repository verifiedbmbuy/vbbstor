import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import {
  Save, Plus, Trash2, Search, Eye, Globe, Share2, Code2,
  FileText, ArrowRight, ExternalLink, CheckCircle2, XCircle,
  AlertCircle, Info, RefreshCw, Link2, Bot, Gauge, ShoppingBag,
  BookOpen, ChevronDown, ChevronUp
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";

// ─── Types ───────────────────────────────────────────────────────
interface SeoSetting {
  id: string;
  page_path: string;
  title: string | null;
  description: string | null;
  keywords: string | null;
  og_image: string | null;
  focus_keyword: string | null;
  schema_type: string | null;
  schema_markup: any;
  og_title: string | null;
  og_description: string | null;
  twitter_title: string | null;
  twitter_description: string | null;
  twitter_image: string | null;
  noindex: boolean | null;
  nofollow: boolean | null;
  canonical_url: string | null;
  robots_advanced: string | null;
}

interface Redirection {
  id: string;
  from_path: string;
  to_path: string;
  redirect_type: string;
  active: boolean;
}

// ─── SEO Score Calculator ────────────────────────────────────────
function calcSeoScore(form: any): { score: number; checks: { label: string; pass: boolean; tip: string }[] } {
  const checks = [
    { label: "Title present", pass: !!form.title && form.title.length > 0, tip: "Add a page title" },
    { label: "Title under 60 chars", pass: !!form.title && form.title.length <= 60 && form.title.length > 0, tip: "Keep title under 60 characters" },
    { label: "Meta description present", pass: !!form.description && form.description.length > 0, tip: "Add a meta description" },
    { label: "Description under 160 chars", pass: !!form.description && form.description.length <= 160 && form.description.length > 0, tip: "Keep description under 160 characters" },
    { label: "Focus keyword set", pass: !!form.focus_keyword && form.focus_keyword.length > 0, tip: "Set a focus keyword" },
    { label: "Keyword in title", pass: !!form.focus_keyword && !!form.title && form.title.toLowerCase().includes(form.focus_keyword.toLowerCase()), tip: "Include focus keyword in the title" },
    { label: "Keyword in description", pass: !!form.focus_keyword && !!form.description && form.description.toLowerCase().includes(form.focus_keyword.toLowerCase()), tip: "Include focus keyword in the description" },
    { label: "OG image set", pass: !!form.og_image && form.og_image.length > 0, tip: "Set an Open Graph image for social sharing" },
    { label: "Keywords / tags set", pass: !!form.keywords && form.keywords.length > 0, tip: "Add some keywords / tags" },
    { label: "Canonical URL set", pass: !!form.canonical_url && form.canonical_url.length > 0, tip: "Set a canonical URL to avoid duplicate content" },
  ];
  const passed = checks.filter((c) => c.pass).length;
  return { score: Math.round((passed / checks.length) * 100), checks };
}

function getScoreColor(score: number) {
  if (score >= 80) return "text-green-600";
  if (score >= 50) return "text-yellow-600";
  return "text-red-600";
}

function getScoreBg(score: number) {
  if (score >= 80) return "bg-green-500";
  if (score >= 50) return "bg-yellow-500";
  return "bg-red-500";
}

// ─── Expandable Score Badge with Tips ────────────────────────────
const ScoreBadgeWithTips = ({ seoData }: { seoData: any }) => {
  const [open, setOpen] = useState(false);
  const { score, checks } = calcSeoScore(seoData);
  const failedChecks = checks.filter((c) => !c.pass);

  return (
    <div className="relative">
      <button
        onClick={(e) => { e.stopPropagation(); setOpen(!open); }}
        className="inline-flex items-center gap-1 cursor-pointer"
      >
        <span className={`inline-block rounded-full px-2.5 py-0.5 text-xs font-bold text-white ${getScoreBg(score)}`}>{score}</span>
        {failedChecks.length > 0 && (
          open ? <ChevronUp className="h-3 w-3 text-muted-foreground" /> : <ChevronDown className="h-3 w-3 text-muted-foreground" />
        )}
      </button>
      {open && failedChecks.length > 0 && (
        <div className="absolute z-20 right-0 mt-1 w-72 rounded-xl border border-border bg-popover p-3 shadow-lg">
          <p className="text-xs font-bold text-foreground mb-2">Fix to improve score:</p>
          <div className="space-y-1.5 max-h-48 overflow-y-auto">
            {failedChecks.map((c) => (
              <div key={c.label} className="flex items-start gap-1.5">
                <XCircle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-red-400" />
                <div>
                  <p className="text-xs font-medium text-foreground">{c.label}</p>
                  <p className="text-[11px] text-muted-foreground">{c.tip}</p>
                </div>
              </div>
            ))}
          </div>
          {failedChecks.length === 0 && <p className="text-xs text-green-600">All checks passed! 🎉</p>}
        </div>
      )}
    </div>
  );
};

// ─── SERP Preview ────────────────────────────────────────────────
const SerpPreview = ({ title, description, path }: { title: string; description: string; path: string }) => (
  <div className="rounded-xl border border-border bg-white p-4">
    <p className="mb-1 text-xs text-[#202124]">verifiedbmbuy.com{path || "/"}</p>
    <p className="mb-1 text-[18px] leading-tight text-[#1a0dab] hover:underline cursor-pointer">
      {title || "Page Title — VBB STORE"}
    </p>
    <p className="text-sm text-[#4d5156] leading-snug">
      {description || "Add a meta description for this page to improve search visibility..."}
    </p>
  </div>
);

// ─── Social Preview Card ────────────────────────────────────────
const SocialPreview = ({ platform, title, description, image }: { platform: "facebook" | "twitter"; title: string; description: string; image: string }) => (
  <div className="rounded-xl border border-border overflow-hidden bg-white">
    {image && (
      <div className="h-40 bg-muted overflow-hidden">
        <img src={image} alt="Preview" className="h-full w-full object-cover" />
      </div>
    )}
    <div className="p-3 border-t border-border">
      <p className="text-[11px] uppercase text-muted-foreground mb-1">verifiedbmbuy.com</p>
      <p className="text-sm font-bold text-foreground leading-tight mb-1">{title || "Page Title"}</p>
      <p className="text-xs text-muted-foreground line-clamp-2">{description || "Page description..."}</p>
    </div>
  </div>
);

// ─── Schema Templates ───────────────────────────────────────────
const schemaTemplates: Record<string, any> = {
  WebPage: { "@type": "WebPage" },
  Product: {
    "@type": "Product",
    name: "",
    description: "",
    image: "",
    brand: { "@type": "Brand", name: "VBB STORE" },
    offers: { "@type": "Offer", price: "", priceCurrency: "USD", availability: "https://schema.org/InStock" },
  },
  Article: {
    "@type": "Article",
    headline: "",
    author: { "@type": "Person", name: "" },
    datePublished: "",
    image: "",
  },
  FAQPage: {
    "@type": "FAQPage",
    mainEntity: [{ "@type": "Question", name: "", acceptedAnswer: { "@type": "Answer", text: "" } }],
  },
  LocalBusiness: {
    "@type": "LocalBusiness",
    name: "VBB STORE",
    telephone: "",
    email: "",
    address: { "@type": "PostalAddress", streetAddress: "", addressLocality: "", addressCountry: "" },
  },
  Organization: {
    "@type": "Organization",
    name: "VBB STORE",
    url: "https://verifiedbmbuy.com",
    logo: "",
    sameAs: [],
  },
};

// ─── Main Component ─────────────────────────────────────────────
const AdminSEO = () => {
  const [activeTab, setActiveTab] = useState("pages");
  const [settings, setSettings] = useState<SeoSetting[]>([]);
  const [redirections, setRedirections] = useState<Redirection[]>([]);
  const [robotsTxt, setRobotsTxt] = useState("");
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<SeoSetting | null>(null);
  const [adding, setAdding] = useState(false);
  const [editTab, setEditTab] = useState("general");
  const [addRedirect, setAddRedirect] = useState(false);
  const [redirectForm, setRedirectForm] = useState({ from_path: "", to_path: "", redirect_type: "301" });
  const [products, setProducts] = useState<{ id: string; name: string }[]>([]);
  const [blogPosts, setBlogPosts] = useState<{ id: string; title: string; slug: string }[]>([]);

  const emptyForm = {
    page_path: "", title: "", description: "", keywords: "", og_image: "",
    focus_keyword: "", schema_type: "WebPage", schema_markup: "{}",
    og_title: "", og_description: "", twitter_title: "", twitter_description: "",
    twitter_image: "", noindex: false, nofollow: false, canonical_url: "", robots_advanced: "",
  };
  const [form, setForm] = useState(emptyForm);

  const fetchAll = async () => {
    setLoading(true);
    try {
      const [seoRes, redirRes, robotsRes, productsRes, blogRes] = await Promise.all([
        supabase.from("seo_settings").select("*").order("page_path"),
        supabase.from("redirections").select("*").order("created_at", { ascending: false }),
        supabase.from("site_content").select("value").eq("key", "robots_txt").maybeSingle(),
        supabase.from("products").select("id, name").order("name"),
        supabase.from("blog_posts").select("id, title, slug").order("title"),
      ]);
      if (seoRes.error) console.error("SEO settings fetch error:", seoRes.error);
      if (redirRes.error) console.error("Redirections fetch error:", redirRes.error);
      if (robotsRes.error) console.error("Robots fetch error:", robotsRes.error);
      setSettings((seoRes.data as any[]) || []);
      setRedirections((redirRes.data as any[]) || []);
      setRobotsTxt(robotsRes.data?.value || "");
      setProducts(productsRes.data || []);
      setBlogPosts(blogRes.data || []);
    } catch (e) {
      console.error("SEO fetch error:", e);
      toast.error("Failed to load SEO data");
    }
    setLoading(false);
  };

  useEffect(() => { fetchAll(); }, []);

  const startEdit = (s: SeoSetting) => {
    setEditing(s);
    setAdding(false);
    setEditTab("general");
    setForm({
      page_path: s.page_path,
      title: s.title || "",
      description: s.description || "",
      keywords: s.keywords || "",
      og_image: s.og_image || "",
      focus_keyword: s.focus_keyword || "",
      schema_type: s.schema_type || "WebPage",
      schema_markup: typeof s.schema_markup === "object" ? JSON.stringify(s.schema_markup, null, 2) : s.schema_markup || "{}",
      og_title: s.og_title || "",
      og_description: s.og_description || "",
      twitter_title: s.twitter_title || "",
      twitter_description: s.twitter_description || "",
      twitter_image: s.twitter_image || "",
      noindex: s.noindex || false,
      nofollow: s.nofollow || false,
      canonical_url: s.canonical_url || "",
      robots_advanced: s.robots_advanced || "",
    });
  };

  const startAdd = () => {
    setAdding(true);
    setEditing(null);
    setEditTab("general");
    setForm(emptyForm);
  };

  const cancel = () => { setEditing(null); setAdding(false); };

  const save = async () => {
    if (!form.page_path) { toast.error("Page path is required"); return; }
    let parsedSchema = {};
    try { parsedSchema = JSON.parse(form.schema_markup || "{}"); } catch { toast.error("Invalid JSON in schema markup"); return; }

    const payload = {
      page_path: form.page_path,
      title: form.title,
      description: form.description,
      keywords: form.keywords,
      og_image: form.og_image,
      focus_keyword: form.focus_keyword,
      schema_type: form.schema_type,
      schema_markup: parsedSchema,
      og_title: form.og_title,
      og_description: form.og_description,
      twitter_title: form.twitter_title,
      twitter_description: form.twitter_description,
      twitter_image: form.twitter_image,
      noindex: form.noindex,
      nofollow: form.nofollow,
      canonical_url: form.canonical_url,
      robots_advanced: form.robots_advanced,
    };

    let error;
    if (editing) {
      const result = await supabase.from("seo_settings").update(payload).eq("id", editing.id);
      error = result.error;
    } else {
      const result = await supabase.from("seo_settings").upsert(payload, { onConflict: "page_path" });
      error = result.error;
    }
    if (error) { toast.error(error.message); console.error("SEO save error:", error); return; }
    toast.success("SEO settings saved");
    cancel();
    fetchAll();
  };

  const deleteSetting = async (id: string) => {
    await supabase.from("seo_settings").delete().eq("id", id);
    toast.success("SEO setting deleted");
    fetchAll();
  };

  const saveRobotsTxt = async () => {
    const { error } = await supabase.from("site_content").update({ value: robotsTxt }).eq("key", "robots_txt");
    if (error) toast.error(error.message);
    else toast.success("robots.txt saved");
  };

  const saveRedirect = async () => {
    if (!redirectForm.from_path || !redirectForm.to_path) { toast.error("Both paths required"); return; }
    const { error } = await supabase.from("redirections").insert(redirectForm);
    if (error) toast.error(error.message);
    else { toast.success("Redirect added"); setAddRedirect(false); setRedirectForm({ from_path: "", to_path: "", redirect_type: "301" }); fetchAll(); }
  };

  const deleteRedirect = async (id: string) => {
    await supabase.from("redirections").delete().eq("id", id);
    toast.success("Redirect deleted");
    fetchAll();
  };

  const toggleRedirect = async (id: string, active: boolean) => {
    await supabase.from("redirections").update({ active: !active }).eq("id", id);
    fetchAll();
  };

  const { score, checks } = calcSeoScore(form);

  if (loading) return <div className="text-muted-foreground">Loading SEO Manager...</div>;

  // ─── Editing / Adding Page SEO ─────────────────────────────────
  if (editing || adding) {
    return (
      <div>
        <div className="mb-4 flex items-center gap-3">
          <Button variant="ghost" onClick={cancel} className="rounded-xl">← Back</Button>
          <h1 className="text-xl font-bold text-foreground">{editing ? "Edit SEO" : "New Page SEO"}: {form.page_path || "/"}</h1>
        </div>

        {/* SEO Score Bar */}
        <Card className="mb-4 rounded-2xl border border-border p-4">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Gauge className="h-5 w-5 text-muted-foreground" />
              <span className="text-sm font-bold text-foreground">SEO Score</span>
            </div>
            <div className="flex-1">
              <div className="h-3 w-full rounded-full bg-muted overflow-hidden">
                <div className={`h-3 rounded-full ${getScoreBg(score)} transition-all`} style={{ width: `${score}%` }} />
              </div>
            </div>
            <span className={`text-2xl font-extrabold ${getScoreColor(score)}`}>{score}/100</span>
          </div>
        </Card>

        <div className="grid gap-4 lg:grid-cols-3">
          {/* Left: Editor */}
          <div className="lg:col-span-2">
            <Tabs value={editTab} onValueChange={setEditTab}>
              <TabsList className="mb-4 w-full rounded-xl bg-muted">
                <TabsTrigger value="general" className="rounded-lg text-xs">General</TabsTrigger>
                <TabsTrigger value="social" className="rounded-lg text-xs">Social</TabsTrigger>
                <TabsTrigger value="schema" className="rounded-lg text-xs">Schema</TabsTrigger>
                <TabsTrigger value="advanced" className="rounded-lg text-xs">Advanced</TabsTrigger>
              </TabsList>

              {/* General Tab */}
              <TabsContent value="general">
                <Card className="rounded-2xl border border-border p-5 space-y-4">
                  <div>
                    <label className="mb-1 block text-sm font-medium text-muted-foreground">Page Path *</label>
                    <Input value={form.page_path} onChange={(e) => setForm((f) => ({ ...f, page_path: e.target.value }))} placeholder="/" />
                  </div>
                  <div>
                    <label className="mb-1 block text-sm font-medium text-muted-foreground">Focus Keyword</label>
                    <Input value={form.focus_keyword} onChange={(e) => setForm((f) => ({ ...f, focus_keyword: e.target.value }))} placeholder="verified business manager" />
                  </div>
                  <div>
                    <div className="flex justify-between mb-1">
                      <label className="text-sm font-medium text-muted-foreground">SEO Title</label>
                      <span className={`text-xs ${(form.title?.length || 0) > 60 ? "text-red-500" : "text-muted-foreground"}`}>{form.title?.length || 0}/60</span>
                    </div>
                    <Input value={form.title} onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))} placeholder="Page Title — VBB STORE" />
                  </div>
                  <div>
                    <div className="flex justify-between mb-1">
                      <label className="text-sm font-medium text-muted-foreground">Meta Description</label>
                      <span className={`text-xs ${(form.description?.length || 0) > 160 ? "text-red-500" : "text-muted-foreground"}`}>{form.description?.length || 0}/160</span>
                    </div>
                    <textarea className="flex w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background" rows={3} value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} placeholder="A compelling description for search engines..." />
                  </div>
                  <div>
                    <label className="mb-1 block text-sm font-medium text-muted-foreground">Keywords (comma-separated)</label>
                    <Input value={form.keywords} onChange={(e) => setForm((f) => ({ ...f, keywords: e.target.value }))} placeholder="verified bm, facebook ads, meta business" />
                  </div>
                  <div>
                    <label className="mb-1 block text-sm font-medium text-muted-foreground">Canonical URL</label>
                    <Input value={form.canonical_url} onChange={(e) => setForm((f) => ({ ...f, canonical_url: e.target.value }))} placeholder="https://verifiedbmbuy.com/" />
                  </div>

                  {/* SERP Preview */}
                  <div>
                    <p className="mb-2 text-sm font-bold text-foreground flex items-center gap-1"><Eye className="h-4 w-4" /> Google Preview</p>
                    <SerpPreview title={form.title} description={form.description} path={form.page_path} />
                  </div>
                </Card>
              </TabsContent>

              {/* Social Tab */}
              <TabsContent value="social">
                <Card className="rounded-2xl border border-border p-5 space-y-5">
                  {/* Facebook */}
                  <div>
                    <h3 className="mb-3 text-sm font-bold text-foreground flex items-center gap-1"><Share2 className="h-4 w-4" /> Facebook / Open Graph</h3>
                    <div className="space-y-3">
                      <Input value={form.og_title} onChange={(e) => setForm((f) => ({ ...f, og_title: e.target.value }))} placeholder="OG Title (defaults to SEO title)" />
                      <textarea className="flex w-full rounded-md border border-input bg-background px-3 py-2 text-sm" rows={2} value={form.og_description} onChange={(e) => setForm((f) => ({ ...f, og_description: e.target.value }))} placeholder="OG Description" />
                      <Input value={form.og_image} onChange={(e) => setForm((f) => ({ ...f, og_image: e.target.value }))} placeholder="OG Image URL" />
                    </div>
                    <div className="mt-3">
                      <p className="mb-1 text-xs text-muted-foreground">Preview:</p>
                      <SocialPreview platform="facebook" title={form.og_title || form.title} description={form.og_description || form.description} image={form.og_image} />
                    </div>
                  </div>

                  {/* Twitter */}
                  <div>
                    <h3 className="mb-3 text-sm font-bold text-foreground flex items-center gap-1"><Share2 className="h-4 w-4" /> Twitter Card</h3>
                    <div className="space-y-3">
                      <Input value={form.twitter_title} onChange={(e) => setForm((f) => ({ ...f, twitter_title: e.target.value }))} placeholder="Twitter Title (defaults to SEO title)" />
                      <textarea className="flex w-full rounded-md border border-input bg-background px-3 py-2 text-sm" rows={2} value={form.twitter_description} onChange={(e) => setForm((f) => ({ ...f, twitter_description: e.target.value }))} placeholder="Twitter Description" />
                      <Input value={form.twitter_image} onChange={(e) => setForm((f) => ({ ...f, twitter_image: e.target.value }))} placeholder="Twitter Image URL" />
                    </div>
                    <div className="mt-3">
                      <p className="mb-1 text-xs text-muted-foreground">Preview:</p>
                      <SocialPreview platform="twitter" title={form.twitter_title || form.title} description={form.twitter_description || form.description} image={form.twitter_image || form.og_image} />
                    </div>
                  </div>
                </Card>
              </TabsContent>

              {/* Schema Tab */}
              <TabsContent value="schema">
                <Card className="rounded-2xl border border-border p-5 space-y-4">
                  <div>
                    <label className="mb-1 block text-sm font-medium text-muted-foreground">Schema Type</label>
                    <select
                      className="flex w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                      value={form.schema_type}
                      onChange={(e) => {
                        const t = e.target.value;
                        setForm((f) => ({
                          ...f,
                          schema_type: t,
                          schema_markup: JSON.stringify({ "@context": "https://schema.org", ...schemaTemplates[t] }, null, 2),
                        }));
                      }}
                    >
                      {Object.keys(schemaTemplates).map((k) => (
                        <option key={k} value={k}>{k}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="mb-1 block text-sm font-medium text-muted-foreground">JSON-LD Markup</label>
                    <textarea
                      className="flex w-full rounded-md border border-input bg-background px-3 py-2 font-mono text-xs"
                      rows={14}
                      value={form.schema_markup}
                      onChange={(e) => setForm((f) => ({ ...f, schema_markup: e.target.value }))}
                    />
                    <p className="mt-1 text-xs text-muted-foreground">Paste or edit structured data (JSON-LD). Select a template above to get started.</p>
                  </div>
                </Card>
              </TabsContent>

              {/* Advanced Tab */}
              <TabsContent value="advanced">
                <Card className="rounded-2xl border border-border p-5 space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-foreground">No Index</p>
                      <p className="text-xs text-muted-foreground">Tell search engines not to index this page</p>
                    </div>
                    <Switch checked={form.noindex} onCheckedChange={(v) => setForm((f) => ({ ...f, noindex: v }))} />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-foreground">No Follow</p>
                      <p className="text-xs text-muted-foreground">Tell search engines not to follow links on this page</p>
                    </div>
                    <Switch checked={form.nofollow} onCheckedChange={(v) => setForm((f) => ({ ...f, nofollow: v }))} />
                  </div>
                  <div>
                    <label className="mb-1 block text-sm font-medium text-muted-foreground">Advanced Robots Meta</label>
                    <Input value={form.robots_advanced} onChange={(e) => setForm((f) => ({ ...f, robots_advanced: e.target.value }))} placeholder="max-snippet:-1, max-image-preview:large" />
                  </div>
                </Card>
              </TabsContent>
            </Tabs>

            <div className="mt-4 flex gap-2">
              <Button onClick={save} className="rounded-xl shadow-md shadow-primary/20">
                <Save className="mr-2 h-4 w-4" /> {editing ? "Update" : "Add Page"}
              </Button>
              <Button variant="outline" onClick={cancel} className="rounded-xl">Cancel</Button>
            </div>
          </div>

          {/* Right: SEO Checklist */}
          <div>
            <Card className="rounded-2xl border border-border p-4 sticky top-20">
              <h3 className="mb-3 text-sm font-bold text-foreground flex items-center gap-1"><Gauge className="h-4 w-4" /> SEO Checklist</h3>
              <div className="space-y-2">
                {checks.map((c) => (
                  <div key={c.label} className="flex items-start gap-2">
                    {c.pass ? (
                      <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-green-500" />
                    ) : (
                      <XCircle className="mt-0.5 h-4 w-4 shrink-0 text-red-400" />
                    )}
                    <div>
                      <p className={`text-xs font-medium ${c.pass ? "text-foreground" : "text-muted-foreground"}`}>{c.label}</p>
                      {!c.pass && <p className="text-[11px] text-muted-foreground">{c.tip}</p>}
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  // ─── Main SEO Manager Dashboard ────────────────────────────────
  return (
    <div>
      <h1 className="mb-1 text-2xl font-extrabold text-foreground">SEO Manager</h1>
      <p className="mb-5 text-sm text-muted-foreground">Optimize your site like RankMath — manage pages, schema, redirects, robots.txt, and submit to search engines.</p>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-5 rounded-xl bg-muted">
          <TabsTrigger value="pages" className="rounded-lg text-xs"><Globe className="mr-1 h-3.5 w-3.5" /> Pages</TabsTrigger>
          <TabsTrigger value="products" className="rounded-lg text-xs"><ShoppingBag className="mr-1 h-3.5 w-3.5" /> Products</TabsTrigger>
          <TabsTrigger value="blog" className="rounded-lg text-xs"><BookOpen className="mr-1 h-3.5 w-3.5" /> Blog</TabsTrigger>
          <TabsTrigger value="redirects" className="rounded-lg text-xs"><ArrowRight className="mr-1 h-3.5 w-3.5" /> Redirects</TabsTrigger>
          <TabsTrigger value="robots" className="rounded-lg text-xs"><Bot className="mr-1 h-3.5 w-3.5" /> Robots.txt</TabsTrigger>
          <TabsTrigger value="sitemap" className="rounded-lg text-xs"><FileText className="mr-1 h-3.5 w-3.5" /> Sitemap</TabsTrigger>
          <TabsTrigger value="submit" className="rounded-lg text-xs"><ExternalLink className="mr-1 h-3.5 w-3.5" /> Submit</TabsTrigger>
        </TabsList>

        {/* ─── Pages Tab ───────────────────────────────────────── */}
        <TabsContent value="pages">
          <div className="mb-4 flex justify-end">
            <Button onClick={startAdd} className="rounded-xl shadow-md shadow-primary/20">
              <Plus className="mr-2 h-4 w-4" /> Add Page
            </Button>
          </div>
          <Card className="rounded-2xl border border-border overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border bg-muted/50">
                    <th className="px-4 py-3 text-left font-semibold text-muted-foreground">Page</th>
                    <th className="px-4 py-3 text-left font-semibold text-muted-foreground">Title</th>
                    <th className="px-4 py-3 text-left font-semibold text-muted-foreground">Focus Keyword</th>
                    <th className="px-4 py-3 text-center font-semibold text-muted-foreground">Score</th>
                    <th className="px-4 py-3 text-right font-semibold text-muted-foreground">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {settings.filter(s => !s.page_path.startsWith("/product/") && !s.page_path.startsWith("/blog/")).map((s) => (
                      <tr key={s.id} className="border-b border-border last:border-0 hover:bg-muted/30 transition-colors">
                        <td className="px-4 py-3 font-medium text-primary">{s.page_path}</td>
                        <td className="px-4 py-3 text-foreground max-w-xs truncate">{s.title || "—"}</td>
                        <td className="px-4 py-3 text-muted-foreground">{s.focus_keyword || "—"}</td>
                        <td className="px-4 py-3 text-center">
                          <ScoreBadgeWithTips seoData={s} />
                        </td>
                        <td className="px-4 py-3 text-right">
                          <Button variant="ghost" size="sm" onClick={() => startEdit(s)} className="h-8">Edit</Button>
                          <Button variant="ghost" size="sm" onClick={() => deleteSetting(s.id)} className="h-8 text-destructive"><Trash2 className="h-4 w-4" /></Button>
                        </td>
                      </tr>
                    ))}
                  {settings.length === 0 && (
                    <tr><td colSpan={5} className="px-4 py-8 text-center text-muted-foreground">No pages configured. Click "Add Page" to start.</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </Card>
        </TabsContent>

        {/* ─── Products Tab ────────────────────────────────────── */}
        <TabsContent value="products">
          <Card className="rounded-2xl border border-border overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border bg-muted/50">
                    <th className="px-4 py-3 text-left font-semibold text-muted-foreground">Product</th>
                    <th className="px-4 py-3 text-left font-semibold text-muted-foreground">SEO Title</th>
                    <th className="px-4 py-3 text-left font-semibold text-muted-foreground">Focus Keyword</th>
                    <th className="px-4 py-3 text-center font-semibold text-muted-foreground">Score</th>
                    <th className="px-4 py-3 text-right font-semibold text-muted-foreground">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {products.map((p) => {
                    const productPath = `/product/${p.id}`;
                    const existing = settings.find((s) => s.page_path === productPath);
                    return (
                      <tr key={p.id} className="border-b border-border last:border-0 hover:bg-muted/30 transition-colors">
                        <td className="px-4 py-3 font-medium text-foreground">{p.name}</td>
                        <td className="px-4 py-3 text-muted-foreground max-w-xs truncate">{existing?.title || "—"}</td>
                        <td className="px-4 py-3 text-muted-foreground">{existing?.focus_keyword || "—"}</td>
                        <td className="px-4 py-3 text-center">
                          {existing ? <ScoreBadgeWithTips seoData={existing} /> : <span className="inline-block rounded-full px-2.5 py-0.5 text-xs font-bold text-white bg-muted-foreground">0</span>}
                        </td>
                        <td className="px-4 py-3 text-right">
                          {existing ? (
                            <Button variant="ghost" size="sm" onClick={() => startEdit(existing)} className="h-8">Edit</Button>
                          ) : (
                            <Button variant="ghost" size="sm" onClick={() => {
                              setAdding(true);
                              setEditing(null);
                              setEditTab("general");
                              setForm({
                                ...emptyForm,
                                page_path: productPath,
                                title: `${p.name} | VBB STORE`,
                                schema_type: "Product",
                                schema_markup: JSON.stringify({ ...schemaTemplates.Product, name: p.name }, null, 2),
                              });
                            }} className="h-8 text-primary">
                              <Plus className="mr-1 h-3.5 w-3.5" /> Add SEO
                            </Button>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                  {products.length === 0 && (
                    <tr><td colSpan={5} className="px-4 py-8 text-center text-muted-foreground">No products found.</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </Card>
        </TabsContent>

        {/* ─── Blog Posts Tab ──────────────────────────────────── */}
        <TabsContent value="blog">
          <Card className="rounded-2xl border border-border overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border bg-muted/50">
                    <th className="px-4 py-3 text-left font-semibold text-muted-foreground">Post</th>
                    <th className="px-4 py-3 text-left font-semibold text-muted-foreground">SEO Title</th>
                    <th className="px-4 py-3 text-left font-semibold text-muted-foreground">Focus Keyword</th>
                    <th className="px-4 py-3 text-center font-semibold text-muted-foreground">Score</th>
                    <th className="px-4 py-3 text-right font-semibold text-muted-foreground">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {blogPosts.map((bp) => {
                    const blogPath = `/blog/${bp.slug}`;
                    const existing = settings.find((s) => s.page_path === blogPath);
                    return (
                      <tr key={bp.id} className="border-b border-border last:border-0 hover:bg-muted/30 transition-colors">
                        <td className="px-4 py-3 font-medium text-foreground">{bp.title}</td>
                        <td className="px-4 py-3 text-muted-foreground max-w-xs truncate">{existing?.title || "—"}</td>
                        <td className="px-4 py-3 text-muted-foreground">{existing?.focus_keyword || "—"}</td>
                        <td className="px-4 py-3 text-center">
                          {existing ? <ScoreBadgeWithTips seoData={existing} /> : <span className="inline-block rounded-full px-2.5 py-0.5 text-xs font-bold text-white bg-muted-foreground">0</span>}
                        </td>
                        <td className="px-4 py-3 text-right">
                          {existing ? (
                            <Button variant="ghost" size="sm" onClick={() => startEdit(existing)} className="h-8">Edit</Button>
                          ) : (
                            <Button variant="ghost" size="sm" onClick={() => {
                              setAdding(true);
                              setEditing(null);
                              setEditTab("general");
                              setForm({
                                ...emptyForm,
                                page_path: blogPath,
                                title: `${bp.title} | VBB STORE Blog`,
                                schema_type: "Article",
                                schema_markup: JSON.stringify({ ...schemaTemplates.Article, headline: bp.title }, null, 2),
                              });
                            }} className="h-8 text-primary">
                              <Plus className="mr-1 h-3.5 w-3.5" /> Add SEO
                            </Button>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                  {blogPosts.length === 0 && (
                    <tr><td colSpan={5} className="px-4 py-8 text-center text-muted-foreground">No blog posts found.</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </Card>
        </TabsContent>

        {/* ─── Redirects Tab ───────────────────────────────────── */}
        <TabsContent value="redirects">
          <div className="mb-4 flex justify-end">
            <Button onClick={() => setAddRedirect(true)} className="rounded-xl shadow-md shadow-primary/20">
              <Plus className="mr-2 h-4 w-4" /> Add Redirect
            </Button>
          </div>
          {addRedirect && (
            <Card className="mb-4 rounded-2xl border border-primary/20 p-5">
              <h3 className="mb-3 text-sm font-bold text-foreground">New Redirect</h3>
              <div className="grid gap-3 sm:grid-cols-3">
                <Input value={redirectForm.from_path} onChange={(e) => setRedirectForm((f) => ({ ...f, from_path: e.target.value }))} placeholder="From: /old-page" />
                <Input value={redirectForm.to_path} onChange={(e) => setRedirectForm((f) => ({ ...f, to_path: e.target.value }))} placeholder="To: /new-page" />
                <select className="flex rounded-md border border-input bg-background px-3 py-2 text-sm" value={redirectForm.redirect_type} onChange={(e) => setRedirectForm((f) => ({ ...f, redirect_type: e.target.value }))}>
                  <option value="301">301 Permanent</option>
                  <option value="302">302 Temporary</option>
                </select>
              </div>
              <div className="mt-3 flex gap-2">
                <Button onClick={saveRedirect} size="sm" className="rounded-xl"><Save className="mr-1 h-3.5 w-3.5" /> Save</Button>
                <Button variant="outline" size="sm" onClick={() => setAddRedirect(false)} className="rounded-xl">Cancel</Button>
              </div>
            </Card>
          )}
          <Card className="rounded-2xl border border-border overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border bg-muted/50">
                    <th className="px-4 py-3 text-left font-semibold text-muted-foreground">From</th>
                    <th className="px-4 py-3 text-left font-semibold text-muted-foreground">To</th>
                    <th className="px-4 py-3 text-center font-semibold text-muted-foreground">Type</th>
                    <th className="px-4 py-3 text-center font-semibold text-muted-foreground">Active</th>
                    <th className="px-4 py-3 text-right font-semibold text-muted-foreground">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {redirections.map((r) => (
                    <tr key={r.id} className="border-b border-border last:border-0 hover:bg-muted/30 transition-colors">
                      <td className="px-4 py-3 font-medium text-foreground">{r.from_path}</td>
                      <td className="px-4 py-3 text-primary">{r.to_path}</td>
                      <td className="px-4 py-3 text-center"><span className="rounded bg-muted px-2 py-0.5 text-xs font-bold">{r.redirect_type}</span></td>
                      <td className="px-4 py-3 text-center"><Switch checked={r.active} onCheckedChange={() => toggleRedirect(r.id, r.active)} /></td>
                      <td className="px-4 py-3 text-right">
                        <Button variant="ghost" size="sm" onClick={() => deleteRedirect(r.id)} className="h-8 text-destructive"><Trash2 className="h-4 w-4" /></Button>
                      </td>
                    </tr>
                  ))}
                  {redirections.length === 0 && (
                    <tr><td colSpan={5} className="px-4 py-8 text-center text-muted-foreground">No redirects configured.</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </Card>
        </TabsContent>

        {/* ─── Robots.txt Tab ──────────────────────────────────── */}
        <TabsContent value="robots">
          <Card className="rounded-2xl border border-border p-5">
            <h3 className="mb-3 text-sm font-bold text-foreground flex items-center gap-1"><Bot className="h-4 w-4" /> robots.txt Editor</h3>
            <textarea
              className="flex w-full rounded-md border border-input bg-background px-3 py-2 font-mono text-xs"
              rows={12}
              value={robotsTxt}
              onChange={(e) => setRobotsTxt(e.target.value)}
            />
            <Button onClick={saveRobotsTxt} className="mt-3 rounded-xl shadow-md shadow-primary/20">
              <Save className="mr-2 h-4 w-4" /> Save robots.txt
            </Button>
          </Card>
        </TabsContent>

        {/* ─── Sitemap Tab ─────────────────────────────────────── */}
        <TabsContent value="sitemap">
          <Card className="rounded-2xl border border-border p-5">
            <h3 className="mb-3 text-sm font-bold text-foreground flex items-center gap-1"><FileText className="h-4 w-4" /> Sitemap</h3>
            <p className="mb-4 text-sm text-muted-foreground">Your sitemap is auto-generated from your pages, products, and blog posts.</p>
            <div className="rounded-xl bg-muted p-4 font-mono text-xs leading-relaxed max-h-96 overflow-y-auto">
              <p className="text-muted-foreground mb-2">&lt;?xml version="1.0" encoding="UTF-8"?&gt;</p>
              <p className="text-muted-foreground">&lt;urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"&gt;</p>
              {["/", "/shop", "/blog", "/about", "/contact", "/faq", "/terms", "/privacy", "/refund-policy", "/replacement-guarantee"].map((p) => (
                <div key={p} className="ml-4 text-foreground">
                  <p>&lt;url&gt;</p>
                  <p className="ml-4">&lt;loc&gt;https://verifiedbmbuy.com{p}&lt;/loc&gt;</p>
                  <p className="ml-4">&lt;changefreq&gt;weekly&lt;/changefreq&gt;</p>
                  <p className="ml-4">&lt;priority&gt;{p === "/" ? "1.0" : "0.8"}&lt;/priority&gt;</p>
                  <p>&lt;/url&gt;</p>
                </div>
              ))}
              {products.map((p) => (
                <div key={p.id} className="ml-4 text-foreground">
                  <p>&lt;url&gt;</p>
                  <p className="ml-4">&lt;loc&gt;https://verifiedbmbuy.com/product/{p.id}&lt;/loc&gt;</p>
                  <p className="ml-4">&lt;changefreq&gt;weekly&lt;/changefreq&gt;</p>
                  <p className="ml-4">&lt;priority&gt;0.9&lt;/priority&gt;</p>
                  <p>&lt;/url&gt;</p>
                </div>
              ))}
              <p className="text-muted-foreground">&lt;/urlset&gt;</p>
            </div>
            <p className="mt-3 text-xs text-muted-foreground">
              <Info className="inline h-3 w-3 mr-1" />
              Products and blog posts are automatically included. Submit this URL to search engines: <code className="bg-muted px-1 rounded">https://verifiedbmbuy.com/sitemap.xml</code>
            </p>
          </Card>
        </TabsContent>

        {/* ─── Submit to Search Engines Tab ─────────────────────── */}
        <TabsContent value="submit">
          <Card className="rounded-2xl border border-border p-5">
            <h3 className="mb-3 text-sm font-bold text-foreground flex items-center gap-1"><ExternalLink className="h-4 w-4" /> Submit to Search Engines</h3>
            <p className="mb-5 text-sm text-muted-foreground">Submit your site to major search engines for faster indexing.</p>
            <div className="grid gap-4 sm:grid-cols-2">
              {[
                { name: "Google Search Console", url: "https://search.google.com/search-console", desc: "Submit sitemap & monitor indexing", color: "from-blue-500 to-blue-600" },
                { name: "Bing Webmaster Tools", url: "https://www.bing.com/webmasters", desc: "Submit to Bing & Yahoo", color: "from-teal-500 to-teal-600" },
                { name: "Google PageSpeed Insights", url: "https://pagespeed.web.dev/analysis?url=https://verifiedbmbuy.com", desc: "Check page speed & Core Web Vitals", color: "from-green-500 to-green-600" },
                { name: "Google Rich Results Test", url: "https://search.google.com/test/rich-results?url=https://verifiedbmbuy.com", desc: "Test structured data & schema", color: "from-orange-500 to-orange-600" },
                { name: "Google Mobile-Friendly Test", url: "https://search.google.com/test/mobile-friendly?url=https://verifiedbmbuy.com", desc: "Test mobile responsiveness", color: "from-purple-500 to-purple-600" },
                { name: "Yandex Webmaster", url: "https://webmaster.yandex.com", desc: "Submit to Yandex search engine", color: "from-red-500 to-red-600" },
              ].map((engine) => (
                <a key={engine.name} href={engine.url} target="_blank" rel="noopener noreferrer" className="group">
                  <Card className="rounded-xl border border-border p-4 hover:shadow-md transition-shadow cursor-pointer">
                    <CardContent className="flex items-center gap-3 p-0">
                      <div className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br ${engine.color} shadow-md`}>
                        <ExternalLink className="h-4 w-4 text-white" />
                      </div>
                      <div>
                        <p className="text-sm font-bold text-foreground group-hover:text-primary transition-colors">{engine.name}</p>
                        <p className="text-xs text-muted-foreground">{engine.desc}</p>
                      </div>
                    </CardContent>
                  </Card>
                </a>
              ))}
            </div>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AdminSEO;
