import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import {
  ChevronDown, ChevronUp, CheckCircle2, XCircle, Gauge,
  Eye, Share2, Code2, Save, Loader2
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import { calcSeoScore } from "./SeoScoreIndicator";

interface InlineSeoEditorProps {
  pagePath: string;
  defaultTitle?: string;
  defaultDescription?: string;
  defaultSchemaType?: string;
  defaultSchemaData?: Record<string, any>;
  onSaved?: () => void;
}

interface SeoForm {
  title: string;
  description: string;
  keywords: string;
  focus_keyword: string;
  og_image: string;
  og_title: string;
  og_description: string;
  twitter_title: string;
  twitter_description: string;
  twitter_image: string;
  canonical_url: string;
  schema_type: string;
  schema_markup: string;
  noindex: boolean;
  nofollow: boolean;
  robots_advanced: string;
}

const emptySeoForm: SeoForm = {
  title: "", description: "", keywords: "", focus_keyword: "",
  og_image: "", og_title: "", og_description: "",
  twitter_title: "", twitter_description: "", twitter_image: "",
  canonical_url: "", schema_type: "WebPage", schema_markup: "{}",
  noindex: false, nofollow: false, robots_advanced: "",
};

const schemaTemplates: Record<string, any> = {
  WebPage: { "@type": "WebPage" },
  Product: {
    "@type": "Product", name: "", description: "", image: "",
    brand: { "@type": "Brand", name: "VBB STORE" },
    offers: { "@type": "Offer", price: "", priceCurrency: "USD", availability: "https://schema.org/InStock" },
  },
  Article: {
    "@type": "Article", headline: "", author: { "@type": "Person", name: "" },
    datePublished: "", image: "",
  },
  FAQPage: {
    "@type": "FAQPage",
    mainEntity: [{ "@type": "Question", name: "", acceptedAnswer: { "@type": "Answer", text: "" } }],
  },
};

function getScoreBg(score: number) {
  if (score >= 80) return "bg-green-500";
  if (score >= 50) return "bg-yellow-500";
  return "bg-red-500";
}

function getScoreColor(score: number) {
  if (score >= 80) return "text-green-600";
  if (score >= 50) return "text-yellow-600";
  return "text-red-600";
}

const SerpPreview = ({ title, description, path }: { title: string; description: string; path: string }) => (
  <div className="rounded-lg border border-border bg-white p-3">
    <p className="mb-0.5 text-[11px] text-[#202124]">verifiedbmbuy.com{path || "/"}</p>
    <p className="mb-0.5 text-[15px] leading-tight text-[#1a0dab] hover:underline cursor-pointer">
      {title || "Page Title — VBB STORE"}
    </p>
    <p className="text-xs text-[#4d5156] leading-snug">
      {description || "Add a meta description..."}
    </p>
  </div>
);

const SocialPreview = ({ title, description, image }: { title: string; description: string; image: string }) => (
  <div className="rounded-lg border border-border overflow-hidden bg-white">
    {image && (
      <div className="h-28 bg-muted overflow-hidden">
        <img src={image} alt="Preview" className="h-full w-full object-cover" />
      </div>
    )}
    <div className="p-2 border-t border-border">
      <p className="text-[10px] uppercase text-muted-foreground mb-0.5">verifiedbmbuy.com</p>
      <p className="text-xs font-bold text-foreground leading-tight mb-0.5">{title || "Page Title"}</p>
      <p className="text-[10px] text-muted-foreground line-clamp-2">{description || "Description..."}</p>
    </div>
  </div>
);

const InlineSeoEditor = ({
  pagePath,
  defaultTitle = "",
  defaultDescription = "",
  defaultSchemaType = "WebPage",
  defaultSchemaData,
  onSaved,
}: InlineSeoEditorProps) => {
  const [open, setOpen] = useState(false);
  const [activeSection, setActiveSection] = useState<string>("general");
  const [form, setForm] = useState<SeoForm>(emptySeoForm);
  const [existingId, setExistingId] = useState<string | null>(null);
  const [loaded, setLoaded] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!pagePath) return;
    supabase.from("seo_settings").select("*").eq("page_path", pagePath).maybeSingle()
      .then(({ data }) => {
        if (data) {
          setExistingId(data.id);
          setForm({
            title: data.title || "",
            description: data.description || "",
            keywords: data.keywords || "",
            focus_keyword: data.focus_keyword || "",
            og_image: data.og_image || "",
            og_title: data.og_title || "",
            og_description: data.og_description || "",
            twitter_title: data.twitter_title || "",
            twitter_description: data.twitter_description || "",
            twitter_image: data.twitter_image || "",
            canonical_url: data.canonical_url || "",
            schema_type: data.schema_type || defaultSchemaType,
            schema_markup: typeof data.schema_markup === "object" ? JSON.stringify(data.schema_markup, null, 2) : String(data.schema_markup || "{}"),
            noindex: data.noindex || false,
            nofollow: data.nofollow || false,
            robots_advanced: data.robots_advanced || "",
          });
        } else {
          const canonical = `https://verifiedbmbuy.com${pagePath}`;
          setForm({
            ...emptySeoForm,
            title: defaultTitle,
            description: defaultDescription,
            canonical_url: canonical,
            schema_type: defaultSchemaType,
            schema_markup: defaultSchemaData ? JSON.stringify(defaultSchemaData, null, 2) : JSON.stringify(schemaTemplates[defaultSchemaType] || {}, null, 2),
          });
        }
        setLoaded(true);
      });
  }, [pagePath]);

  const { score, checks } = calcSeoScore(form);
  const failedChecks = checks.filter((c) => !c.pass);

  const saveSeo = async () => {
    if (saving) return;
    setSaving(true);
    let parsedSchema = {};
    try { parsedSchema = JSON.parse(form.schema_markup || "{}"); } catch { toast.error("Invalid JSON in schema"); setSaving(false); return; }

    const payload = {
      page_path: pagePath,
      title: form.title,
      description: form.description,
      keywords: form.keywords,
      focus_keyword: form.focus_keyword,
      og_image: form.og_image,
      og_title: form.og_title,
      og_description: form.og_description,
      twitter_title: form.twitter_title,
      twitter_description: form.twitter_description,
      twitter_image: form.twitter_image,
      canonical_url: form.canonical_url,
      schema_type: form.schema_type,
      schema_markup: parsedSchema,
      noindex: form.noindex,
      nofollow: form.nofollow,
      robots_advanced: form.robots_advanced,
    };

    // Always use upsert to handle both new and existing records reliably
    const result = await supabase
      .from("seo_settings")
      .upsert(payload, { onConflict: "page_path" })
      .select();

    if (result.error) {
      toast.error("SEO save failed: " + result.error.message);
      console.error("SEO save error:", result.error);
    } else {
      if (result.data?.[0]) setExistingId(result.data[0].id);
      toast.success("SEO settings saved");
      onSaved?.();
    }
    setSaving(false);
  };

  const sections = [
    { id: "general", label: "General" },
    { id: "social", label: "Social" },
    { id: "schema", label: "Schema" },
    { id: "advanced", label: "Advanced" },
  ];

  if (!loaded) return null;

  return (
    <div className="mt-4 rounded-xl border border-border bg-muted/30">
      {/* Header bar */}
      <button
        onClick={() => setOpen(!open)}
        className="flex w-full items-center justify-between px-4 py-3 cursor-pointer hover:bg-muted/50 transition-colors rounded-xl"
      >
        <div className="flex items-center gap-3">
          <Gauge className="h-4 w-4 text-muted-foreground" />
          <span className="text-sm font-bold text-foreground">SEO Settings</span>
          <span className={`inline-block rounded-full px-2.5 py-0.5 text-xs font-bold text-white ${getScoreBg(score)}`}>{score}/100</span>
          {failedChecks.length > 0 && (
            <span className="text-[11px] text-muted-foreground">{failedChecks.length} issue{failedChecks.length > 1 ? "s" : ""}</span>
          )}
        </div>
        {open ? <ChevronUp className="h-4 w-4 text-muted-foreground" /> : <ChevronDown className="h-4 w-4 text-muted-foreground" />}
      </button>

      {open && (
        <div className="border-t border-border px-4 pb-4">
          {/* Section tabs */}
          <div className="flex gap-1 my-3 rounded-lg bg-muted p-1">
            {sections.map((s) => (
              <button
                key={s.id}
                onClick={() => setActiveSection(s.id)}
                className={`flex-1 rounded-md px-3 py-1.5 text-xs font-medium transition-colors ${activeSection === s.id ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"}`}
              >
                {s.label}
              </button>
            ))}
          </div>

          <div className="grid gap-4 lg:grid-cols-3">
            {/* Left: Editor */}
            <div className="lg:col-span-2 space-y-3">
              {/* General */}
              {activeSection === "general" && (
                <>
                  <div>
                    <label className="mb-1 block text-xs font-medium text-muted-foreground">Focus Keyword</label>
                    <Input value={form.focus_keyword} onChange={(e) => setForm((f) => ({ ...f, focus_keyword: e.target.value }))} placeholder="e.g. verified business manager" className="h-8 text-sm" />
                  </div>
                  <div>
                    <div className="flex justify-between mb-1">
                      <label className="text-xs font-medium text-muted-foreground">SEO Title</label>
                      <span className={`text-[10px] ${(form.title?.length || 0) > 60 ? "text-destructive" : "text-muted-foreground"}`}>{form.title?.length || 0}/60</span>
                    </div>
                    <Input value={form.title} onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))} placeholder="Page Title — VBB STORE" className="h-8 text-sm" />
                  </div>
                  <div>
                    <div className="flex justify-between mb-1">
                      <label className="text-xs font-medium text-muted-foreground">Meta Description</label>
                      <span className={`text-[10px] ${(form.description?.length || 0) > 160 ? "text-destructive" : "text-muted-foreground"}`}>{form.description?.length || 0}/160</span>
                    </div>
                    <textarea className="flex w-full rounded-md border border-input bg-background px-3 py-2 text-sm" rows={2} value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} placeholder="Meta description..." />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-medium text-muted-foreground">Keywords (comma-separated)</label>
                    <Input value={form.keywords} onChange={(e) => setForm((f) => ({ ...f, keywords: e.target.value }))} placeholder="keyword1, keyword2" className="h-8 text-sm" />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-medium text-muted-foreground">Canonical URL</label>
                    <Input value={form.canonical_url} onChange={(e) => setForm((f) => ({ ...f, canonical_url: e.target.value }))} placeholder="https://verifiedbmbuy.com/..." className="h-8 text-sm" />
                  </div>
                  <div>
                    <p className="mb-1 text-xs font-medium text-muted-foreground flex items-center gap-1"><Eye className="h-3 w-3" /> Google Preview</p>
                    <SerpPreview title={form.title} description={form.description} path={pagePath} />
                  </div>
                </>
              )}

              {/* Social */}
              {activeSection === "social" && (
                <>
                  <div>
                    <h4 className="mb-2 text-xs font-bold text-foreground flex items-center gap-1"><Share2 className="h-3 w-3" /> Open Graph / Facebook</h4>
                    <div className="space-y-2">
                      <Input value={form.og_title} onChange={(e) => setForm((f) => ({ ...f, og_title: e.target.value }))} placeholder="OG Title (defaults to SEO title)" className="h-8 text-sm" />
                      <textarea className="flex w-full rounded-md border border-input bg-background px-3 py-2 text-sm" rows={2} value={form.og_description} onChange={(e) => setForm((f) => ({ ...f, og_description: e.target.value }))} placeholder="OG Description" />
                      <Input value={form.og_image} onChange={(e) => setForm((f) => ({ ...f, og_image: e.target.value }))} placeholder="OG Image URL" className="h-8 text-sm" />
                    </div>
                    <div className="mt-2">
                      <SocialPreview title={form.og_title || form.title} description={form.og_description || form.description} image={form.og_image} />
                    </div>
                  </div>
                  <div className="mt-3">
                    <h4 className="mb-2 text-xs font-bold text-foreground flex items-center gap-1"><Share2 className="h-3 w-3" /> Twitter Card</h4>
                    <div className="space-y-2">
                      <Input value={form.twitter_title} onChange={(e) => setForm((f) => ({ ...f, twitter_title: e.target.value }))} placeholder="Twitter Title" className="h-8 text-sm" />
                      <textarea className="flex w-full rounded-md border border-input bg-background px-3 py-2 text-sm" rows={2} value={form.twitter_description} onChange={(e) => setForm((f) => ({ ...f, twitter_description: e.target.value }))} placeholder="Twitter Description" />
                      <Input value={form.twitter_image} onChange={(e) => setForm((f) => ({ ...f, twitter_image: e.target.value }))} placeholder="Twitter Image URL" className="h-8 text-sm" />
                    </div>
                    <div className="mt-2">
                      <SocialPreview title={form.twitter_title || form.title} description={form.twitter_description || form.description} image={form.twitter_image || form.og_image} />
                    </div>
                  </div>
                </>
              )}

              {/* Schema */}
              {activeSection === "schema" && (
                <>
                  <div>
                    <label className="mb-1 block text-xs font-medium text-muted-foreground">Schema Type</label>
                    <select className="flex h-8 w-full rounded-md border border-input bg-background px-3 text-sm" value={form.schema_type} onChange={(e) => {
                      const type = e.target.value;
                      setForm((f) => ({
                        ...f,
                        schema_type: type,
                        schema_markup: JSON.stringify({ "@context": "https://schema.org", ...(schemaTemplates[type] || {}) }, null, 2),
                      }));
                    }}>
                      {Object.keys(schemaTemplates).map((t) => <option key={t} value={t}>{t}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-medium text-muted-foreground flex items-center gap-1"><Code2 className="h-3 w-3" /> JSON-LD Schema Markup</label>
                    <textarea className="flex w-full rounded-md border border-input bg-background px-3 py-2 font-mono text-xs" rows={8} value={form.schema_markup} onChange={(e) => setForm((f) => ({ ...f, schema_markup: e.target.value }))} />
                  </div>
                </>
              )}

              {/* Advanced */}
              {activeSection === "advanced" && (
                <>
                  <div className="flex items-center gap-3">
                    <Switch checked={form.noindex} onCheckedChange={(v) => setForm((f) => ({ ...f, noindex: v }))} />
                    <label className="text-xs font-medium text-foreground">No Index</label>
                    <span className="text-[10px] text-muted-foreground">Prevent search engines from indexing</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Switch checked={form.nofollow} onCheckedChange={(v) => setForm((f) => ({ ...f, nofollow: v }))} />
                    <label className="text-xs font-medium text-foreground">No Follow</label>
                    <span className="text-[10px] text-muted-foreground">Prevent search engines from following links</span>
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-medium text-muted-foreground">Advanced Robots Meta</label>
                    <Input value={form.robots_advanced} onChange={(e) => setForm((f) => ({ ...f, robots_advanced: e.target.value }))} placeholder="max-snippet:-1, max-image-preview:large" className="h-8 text-sm" />
                  </div>
                </>
              )}

              <Button onClick={saveSeo} disabled={saving} size="sm" className="rounded-lg mt-2">
                {saving ? <Loader2 className="mr-1 h-3 w-3 animate-spin" /> : <Save className="mr-1 h-3 w-3" />}
                Save SEO
              </Button>
            </div>

            {/* Right: Checklist */}
            <div>
              <div className="rounded-lg border border-border bg-background p-3 sticky top-20">
                <div className="flex items-center gap-2 mb-2">
                  <Gauge className="h-4 w-4 text-muted-foreground" />
                  <span className="text-xs font-bold text-foreground">SEO Score</span>
                  <span className={`text-lg font-extrabold ${getScoreColor(score)}`}>{score}</span>
                </div>
                <div className="h-2 w-full rounded-full bg-muted overflow-hidden mb-3">
                  <div className={`h-2 rounded-full ${getScoreBg(score)} transition-all`} style={{ width: `${score}%` }} />
                </div>
                <div className="space-y-1.5">
                  {checks.map((c) => (
                    <div key={c.label} className="flex items-start gap-1.5">
                      {c.pass ? (
                        <CheckCircle2 className="mt-0.5 h-3 w-3 shrink-0 text-green-500" />
                      ) : (
                        <XCircle className="mt-0.5 h-3 w-3 shrink-0 text-red-400" />
                      )}
                      <div>
                        <p className={`text-[11px] font-medium ${c.pass ? "text-foreground" : "text-muted-foreground"}`}>{c.label}</p>
                        {!c.pass && <p className="text-[10px] text-muted-foreground">{c.tip}</p>}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default InlineSeoEditor;
