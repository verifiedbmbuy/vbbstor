import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Download, Database, FileText, Package, Tag, ShoppingCart, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { toast } from "sonner";

const exportTables = [
  { key: "products", label: "Products", icon: Package },
  { key: "blog_posts", label: "Blog Posts", icon: FileText },
  { key: "orders", label: "Orders", icon: ShoppingCart },
  { key: "coupons", label: "Coupons", icon: Tag },
  { key: "seo_settings", label: "SEO Settings", icon: Database },
  { key: "site_content", label: "Site Content", icon: FileText },
  { key: "redirections", label: "Redirections", icon: RefreshCw },
];

const AdminBackups = () => {
  const [exporting, setExporting] = useState<string | null>(null);

  const exportTable = async (table: string) => {
    setExporting(table);
    try {
      const { data, error } = await supabase.from(table as any).select("*");
      if (error) throw error;
      const json = JSON.stringify(data, null, 2);
      const blob = new Blob([json], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${table}_export_${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(url);
      toast.success(`${table} exported successfully`);
    } catch (err: any) {
      toast.error("Export failed: " + (err?.message || "Unknown error"));
    }
    setExporting(null);
  };

  const exportAll = async () => {
    setExporting("all");
    try {
      const allData: Record<string, any> = {};
      for (const t of exportTables) {
        const { data } = await supabase.from(t.key as any).select("*");
        allData[t.key] = data || [];
      }
      const json = JSON.stringify(allData, null, 2);
      const blob = new Blob([json], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `vbb_store_full_backup_${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(url);
      toast.success("Full backup exported");
    } catch (err: any) {
      toast.error("Backup failed: " + (err?.message || "Unknown error"));
    }
    setExporting(null);
  };

  return (
    <div>
      <div className="mb-5 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-extrabold text-foreground">Export & Backup</h1>
          <p className="text-sm text-muted-foreground">Download your store data as JSON files.</p>
        </div>
        <Button onClick={exportAll} disabled={!!exporting} className="rounded-xl shadow-md shadow-primary/20">
          <Download className="mr-2 h-4 w-4" /> {exporting === "all" ? "Exporting..." : "Export All"}
        </Button>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {exportTables.map((t) => (
          <Card key={t.key} className="rounded-2xl border border-border p-5">
            <div className="flex items-center gap-3 mb-4">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-muted">
                <t.icon className="h-5 w-5 text-muted-foreground" />
              </div>
              <div>
                <p className="text-sm font-bold text-foreground">{t.label}</p>
                <p className="text-xs text-muted-foreground">{t.key}</p>
              </div>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => exportTable(t.key)}
              disabled={!!exporting}
              className="w-full rounded-xl"
            >
              <Download className="mr-2 h-3.5 w-3.5" />
              {exporting === t.key ? "Exporting..." : "Export JSON"}
            </Button>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default AdminBackups;
