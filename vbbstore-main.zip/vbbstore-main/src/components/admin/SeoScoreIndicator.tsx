import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { ChevronDown, ChevronUp, XCircle, CheckCircle2, Gauge } from "lucide-react";

interface SeoData {
  title: string | null;
  description: string | null;
  focus_keyword: string | null;
  og_image: string | null;
  keywords: string | null;
  canonical_url: string | null;
}

export function calcSeoScore(form: SeoData): { score: number; checks: { label: string; pass: boolean; tip: string }[] } {
  const checks = [
    { label: "Title present", pass: !!form.title && form.title.length > 0, tip: "Add a page title" },
    { label: "Title under 60 chars", pass: !!form.title && form.title.length <= 60 && form.title.length > 0, tip: "Keep title under 60 characters" },
    { label: "Meta description present", pass: !!form.description && form.description.length > 0, tip: "Add a meta description" },
    { label: "Description under 160 chars", pass: !!form.description && form.description.length <= 160 && form.description.length > 0, tip: "Keep description under 160 characters" },
    { label: "Focus keyword set", pass: !!form.focus_keyword && form.focus_keyword.length > 0, tip: "Set a focus keyword" },
    { label: "Keyword in title", pass: !!form.focus_keyword && !!form.title && form.title.toLowerCase().includes(form.focus_keyword.toLowerCase()), tip: "Include focus keyword in the title" },
    { label: "Keyword in description", pass: !!form.focus_keyword && !!form.description && form.description.toLowerCase().includes(form.focus_keyword.toLowerCase()), tip: "Include focus keyword in the description" },
    { label: "OG image set", pass: !!form.og_image && form.og_image.length > 0, tip: "Set an Open Graph image for social sharing" },
    { label: "Keywords / tags set", pass: !!form.keywords && form.keywords.length > 0, tip: "Add some keywords / tags" },
    { label: "Canonical URL set", pass: !!form.canonical_url && form.canonical_url.length > 0, tip: "Set a canonical URL to avoid duplicate content" },
  ];
  const passed = checks.filter((c) => c.pass).length;
  return { score: Math.round((passed / checks.length) * 100), checks };
}

function getScoreBg(score: number) {
  if (score >= 80) return "bg-green-500";
  if (score >= 50) return "bg-yellow-500";
  return "bg-red-500";
}

export const SeoScoreIndicator = ({ pagePath }: { pagePath: string }) => {
  const [seoData, setSeoData] = useState<SeoData | null>(null);
  const [loaded, setLoaded] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    supabase.from("seo_settings").select("title, description, focus_keyword, og_image, keywords, canonical_url")
      .eq("page_path", pagePath).maybeSingle()
      .then(({ data }) => { setSeoData(data); setLoaded(true); });
  }, [pagePath]);

  if (!loaded) return <span className="text-xs text-muted-foreground">…</span>;

  if (!seoData) {
    return (
      <div className="flex items-center gap-1">
        <span className="inline-block rounded-full px-2 py-0.5 text-xs font-bold text-white bg-muted-foreground">—</span>
        <span className="text-[10px] text-muted-foreground">No SEO</span>
      </div>
    );
  }

  const { score, checks } = calcSeoScore(seoData);
  const failedChecks = checks.filter((c) => !c.pass);
  const passedChecks = checks.filter((c) => c.pass);

  return (
    <div className="relative">
      <button
        onClick={(e) => { e.stopPropagation(); setOpen(!open); }}
        className="inline-flex items-center gap-1 cursor-pointer"
      >
        <span className={`inline-block rounded-full px-2.5 py-0.5 text-xs font-bold text-white ${getScoreBg(score)}`}>{score}</span>
        {open ? <ChevronUp className="h-3 w-3 text-muted-foreground" /> : <ChevronDown className="h-3 w-3 text-muted-foreground" />}
      </button>
      {open && (
        <div className="absolute z-30 right-0 mt-1 w-80 rounded-xl border border-border bg-popover p-3 shadow-lg">
          <div className="flex items-center gap-2 mb-2">
            <Gauge className="h-4 w-4 text-muted-foreground" />
            <span className="text-xs font-bold text-foreground">SEO Score: {score}/100</span>
          </div>
          {failedChecks.length > 0 && (
            <>
              <p className="text-[11px] font-semibold text-destructive mb-1">Issues to fix:</p>
              <div className="space-y-1 mb-2">
                {failedChecks.map((c) => (
                  <div key={c.label} className="flex items-start gap-1.5">
                    <XCircle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-red-400" />
                    <div>
                      <p className="text-[11px] font-medium text-foreground">{c.label}</p>
                      <p className="text-[10px] text-muted-foreground">{c.tip}</p>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
          {passedChecks.length > 0 && (
            <>
              <p className="text-[11px] font-semibold text-green-600 mb-1">Passed:</p>
              <div className="space-y-0.5">
                {passedChecks.map((c) => (
                  <div key={c.label} className="flex items-center gap-1.5">
                    <CheckCircle2 className="h-3 w-3 shrink-0 text-green-500" />
                    <p className="text-[11px] text-muted-foreground">{c.label}</p>
                  </div>
                ))}
              </div>
            </>
          )}
          <p className="mt-2 text-[10px] text-muted-foreground italic">Go to SEO Manager → edit this page to improve score.</p>
        </div>
      )}
    </div>
  );
};

export default SeoScoreIndicator;
