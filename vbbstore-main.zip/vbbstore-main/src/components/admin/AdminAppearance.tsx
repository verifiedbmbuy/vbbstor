import { useState } from "react";
import { Palette, Type, Layout, Monitor, Smartphone, Save, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";

const colorPresets = [
  { name: "Default Blue", primary: "#2563eb", accent: "#3b82f6" },
  { name: "Forest Green", primary: "#16a34a", accent: "#22c55e" },
  { name: "Royal Purple", primary: "#7c3aed", accent: "#8b5cf6" },
  { name: "Sunset Orange", primary: "#ea580c", accent: "#f97316" },
  { name: "Rose Red", primary: "#e11d48", accent: "#f43f5e" },
  { name: "Slate Gray", primary: "#475569", accent: "#64748b" },
];

const AdminAppearance = () => {
  const { toast } = useToast();
  const [selectedPreset, setSelectedPreset] = useState(0);

  const handleSave = () => {
    toast({
      title: "Appearance saved",
      description: "Your appearance settings have been updated. Note: This is a preview — full theme customization coming soon.",
    });
  };

  return (
    <div className="max-w-4xl">
      {/* WordPress-style notice */}
      <div className="mb-4 rounded border-l-4 border-[#dba617] bg-white p-3 text-[13px] text-[#1d2327] shadow-sm">
        <strong>Customize</strong> — Appearance customization is in preview mode. Full theme support coming soon.
      </div>

      <div className="space-y-6">
        {/* Color Scheme */}
        <Card className="rounded border border-[#c3c4c7] bg-white shadow-sm">
          <div className="border-b border-[#c3c4c7] px-4 py-3">
            <h2 className="flex items-center gap-2 text-sm font-semibold text-[#1d2327]">
              <Palette className="h-4 w-4" />
              Color Scheme
            </h2>
          </div>
          <CardContent className="p-4">
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
              {colorPresets.map((preset, i) => (
                <button
                  key={preset.name}
                  onClick={() => setSelectedPreset(i)}
                  className={`relative flex items-center gap-3 rounded border p-3 text-left transition-all ${
                    selectedPreset === i
                      ? "border-[#2271b1] bg-[#f0f6fc] shadow-sm"
                      : "border-[#c3c4c7] hover:border-[#8c8f94]"
                  }`}
                >
                  <div className="flex gap-1">
                    <div className="h-6 w-6 rounded-full shadow-inner" style={{ backgroundColor: preset.primary }} />
                    <div className="h-6 w-6 rounded-full shadow-inner" style={{ backgroundColor: preset.accent }} />
                  </div>
                  <span className="text-[13px] text-[#1d2327]">{preset.name}</span>
                  {selectedPreset === i && (
                    <Check className="absolute right-2 top-2 h-4 w-4 text-[#2271b1]" />
                  )}
                </button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Typography */}
        <Card className="rounded border border-[#c3c4c7] bg-white shadow-sm">
          <div className="border-b border-[#c3c4c7] px-4 py-3">
            <h2 className="flex items-center gap-2 text-sm font-semibold text-[#1d2327]">
              <Type className="h-4 w-4" />
              Typography
            </h2>
          </div>
          <CardContent className="p-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label className="mb-1 block text-[13px] font-medium text-[#1d2327]">Heading Font</label>
                <Input defaultValue="Plus Jakarta Sans" className="text-[13px]" />
              </div>
              <div>
                <label className="mb-1 block text-[13px] font-medium text-[#1d2327]">Body Font</label>
                <Input defaultValue="Plus Jakarta Sans" className="text-[13px]" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Layout */}
        <Card className="rounded border border-[#c3c4c7] bg-white shadow-sm">
          <div className="border-b border-[#c3c4c7] px-4 py-3">
            <h2 className="flex items-center gap-2 text-sm font-semibold text-[#1d2327]">
              <Layout className="h-4 w-4" />
              Layout
            </h2>
          </div>
          <CardContent className="p-4">
            <div className="flex gap-4">
              <button className="flex flex-col items-center gap-2 rounded border border-[#2271b1] bg-[#f0f6fc] p-4 shadow-sm">
                <Monitor className="h-8 w-8 text-[#2271b1]" />
                <span className="text-[12px] font-medium text-[#2271b1]">Wide</span>
              </button>
              <button className="flex flex-col items-center gap-2 rounded border border-[#c3c4c7] p-4 hover:border-[#8c8f94]">
                <Smartphone className="h-8 w-8 text-[#646970]" />
                <span className="text-[12px] font-medium text-[#646970]">Boxed</span>
              </button>
            </div>
          </CardContent>
        </Card>

        <Button
          onClick={handleSave}
          className="bg-[#2271b1] hover:bg-[#135e96] text-white text-[13px] px-4"
        >
          <Save className="mr-2 h-4 w-4" />
          Save Changes
        </Button>
      </div>
    </div>
  );
};

export default AdminAppearance;
