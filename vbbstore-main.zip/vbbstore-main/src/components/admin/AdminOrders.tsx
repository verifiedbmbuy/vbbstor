import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { toast } from "sonner";

interface Order {
  id: string;
  order_number: string;
  product: string;
  customer: string;
  email: string;
  amount: number;
  status: string;
  date: string;
}

const AdminOrders = () => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<string>("all");

  const fetchOrders = async () => {
    const { data } = await supabase.from("orders").select("*").order("date", { ascending: false });
    setOrders((data as Order[]) || []);
    setLoading(false);
  };

  useEffect(() => { fetchOrders(); }, []);

  const updateStatus = async (id: string, status: string) => {
    await supabase.from("orders").update({ status }).eq("id", id);
    toast.success(`Order marked as ${status}`);
    fetchOrders();
  };

  const filtered = filter === "all" ? orders : orders.filter((o) => o.status === filter);
  const totalRevenue = orders.filter((o) => o.status === "completed").reduce((s, o) => s + Number(o.amount), 0);
  const pendingCount = orders.filter((o) => o.status === "pending").length;

  if (loading) return <div className="text-muted-foreground">Loading...</div>;

  return (
    <div>
      <h1 className="mb-6 text-2xl font-extrabold text-foreground">Orders</h1>

      <div className="mb-6 grid gap-4 sm:grid-cols-3">
        <Card className="rounded-2xl border border-border p-5">
          <p className="text-sm text-muted-foreground">Total Orders</p>
          <p className="text-3xl font-extrabold text-foreground">{orders.length}</p>
        </Card>
        <Card className="rounded-2xl border border-border p-5">
          <p className="text-sm text-muted-foreground">Pending</p>
          <p className="text-3xl font-extrabold text-yellow-600">{pendingCount}</p>
        </Card>
        <Card className="rounded-2xl border border-border p-5">
          <p className="text-sm text-muted-foreground">Revenue</p>
          <p className="text-3xl font-extrabold text-green-600">${totalRevenue}</p>
        </Card>
      </div>

      <div className="mb-4 flex gap-2">
        {["all", "pending", "completed", "cancelled"].map((f) => (
          <Button key={f} variant={filter === f ? "default" : "outline"} size="sm" onClick={() => setFilter(f)} className="rounded-full capitalize">
            {f}
          </Button>
        ))}
      </div>

      <Card className="rounded-2xl border border-border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-muted/50">
                <th className="px-4 py-3 text-left font-semibold text-muted-foreground">Order</th>
                <th className="px-4 py-3 text-left font-semibold text-muted-foreground">Product</th>
                <th className="px-4 py-3 text-left font-semibold text-muted-foreground">Customer</th>
                <th className="px-4 py-3 text-left font-semibold text-muted-foreground">Amount</th>
                <th className="px-4 py-3 text-left font-semibold text-muted-foreground">Status</th>
                <th className="px-4 py-3 text-left font-semibold text-muted-foreground">Date</th>
                <th className="px-4 py-3 text-right font-semibold text-muted-foreground">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((o) => (
                <tr key={o.id} className="border-b border-border last:border-0 hover:bg-muted/30 transition-colors">
                  <td className="px-4 py-3 font-medium text-foreground">{o.order_number}</td>
                  <td className="px-4 py-3 text-muted-foreground max-w-[200px] truncate">{o.product}</td>
                  <td className="px-4 py-3 text-foreground">{o.customer}</td>
                  <td className="px-4 py-3 font-bold text-foreground">${o.amount}</td>
                  <td className="px-4 py-3">
                    <span className={`rounded-full px-2.5 py-1 text-xs font-bold ${
                      o.status === "completed" ? "bg-green-100 text-green-700" :
                      o.status === "pending" ? "bg-yellow-100 text-yellow-700" :
                      "bg-red-100 text-red-700"
                    }`}>{o.status}</span>
                  </td>
                  <td className="px-4 py-3 text-muted-foreground">{o.date}</td>
                  <td className="px-4 py-3 text-right">
                    <div className="flex justify-end gap-1">
                      {o.status !== "completed" && (
                        <Button size="sm" variant="outline" className="h-7 rounded-lg text-xs" onClick={() => updateStatus(o.id, "completed")}>Complete</Button>
                      )}
                      {o.status !== "cancelled" && (
                        <Button size="sm" variant="outline" className="h-7 rounded-lg text-xs text-destructive hover:text-destructive" onClick={() => updateStatus(o.id, "cancelled")}>Cancel</Button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
};

export default AdminOrders;
