import { useState, useEffect, useRef, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Plus, Pencil, Trash2, X, Save, Image } from "lucide-react";
import { SeoScoreIndicator } from "./SeoScoreIndicator";
import InlineSeoEditor from "./InlineSeoEditor";
import MediaPicker from "./MediaPicker";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { toast } from "sonner";

interface BlogPost {
  id: string;
  slug: string;
  title: string;
  excerpt: string;
  content: string;
  category: string;
  date: string;
  read_time: string;
  author: string;
  published: boolean;
}

const emptyForm = { slug: "", title: "", excerpt: "", content: "", category: "", date: new Date().toISOString().split("T")[0], read_time: "5 min read", author: "VBB STORE Team", published: true };

const AdminBlog = () => {
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<BlogPost | null>(null);
  const [adding, setAdding] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [autoSavedId, setAutoSavedId] = useState<string | null>(null);
  const [autoSaveStatus, setAutoSaveStatus] = useState<string>("");
  const autoSaveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [mediaPickerOpen, setMediaPickerOpen] = useState(false);
  const contentRef = useRef<HTMLTextAreaElement>(null);

  const fetchPosts = async () => {
    const { data } = await supabase.from("blog_posts").select("*").order("date", { ascending: false });
    setPosts((data as BlogPost[]) || []);
    setLoading(false);
  };

  useEffect(() => { fetchPosts(); }, []);

  const startEdit = (p: BlogPost) => {
    setEditing(p);
    setForm({ slug: p.slug, title: p.title, excerpt: p.excerpt, content: p.content, category: p.category, date: p.date, read_time: p.read_time, author: p.author, published: p.published });
    setAdding(false);
  };

  const startAdd = () => { setAdding(true); setEditing(null); setForm(emptyForm); setAutoSavedId(null); setAutoSaveStatus(""); };
  const cancel = () => { setEditing(null); setAdding(false); setAutoSavedId(null); setAutoSaveStatus(""); if (autoSaveTimer.current) clearTimeout(autoSaveTimer.current); };

  // Auto-save as draft
  const autoSaveDraft = useCallback(async (currentForm: typeof emptyForm, editingPost: BlogPost | null, savedId: string | null) => {
    if (!currentForm.title.trim()) return;
    const slug = currentForm.slug || currentForm.title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
    const row = { ...currentForm, slug, published: false };
    try {
      if (editingPost) {
        await supabase.from("blog_posts").update(row).eq("id", editingPost.id);
        setAutoSaveStatus("Draft auto-saved");
      } else if (savedId) {
        await supabase.from("blog_posts").update(row).eq("id", savedId);
        setAutoSaveStatus("Draft auto-saved");
      } else {
        const { data } = await supabase.from("blog_posts").insert([row]).select();
        if (data && data[0]) {
          setAutoSavedId(data[0].id);
          setAutoSaveStatus("Draft auto-saved");
        }
      }
      fetchPosts();
    } catch { /* silent */ }
  }, []);

  const triggerAutoSave = useCallback((newForm: typeof emptyForm) => {
    if (autoSaveTimer.current) clearTimeout(autoSaveTimer.current);
    if (!newForm.title.trim()) return;
    setAutoSaveStatus("Saving...");
    autoSaveTimer.current = setTimeout(() => {
      autoSaveDraft(newForm, editing, autoSavedId);
    }, 3000);
  }, [editing, autoSavedId, autoSaveDraft]);

  const updateForm = (updater: (f: typeof emptyForm) => typeof emptyForm) => {
    setForm((prev) => {
      const next = updater(prev);
      triggerAutoSave(next);
      return next;
    });
  };

  const saveAsDraft = async () => {
    if (!form.title.trim()) { toast.error("At least a title is required to save as draft"); return; }
    const slug = form.slug || form.title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
    const row = { ...form, slug, published: false };
    if (editing) {
      await supabase.from("blog_posts").update(row).eq("id", editing.id);
      toast.success("Post saved as draft");
    } else {
      await supabase.from("blog_posts").insert([row]);
      toast.success("Post saved as draft");
    }
    cancel();
    fetchPosts();
  };

  const upsertCanonical = async (slug: string, type: string) => {
    const pagePath = `/${type}/${slug}`;
    const canonical = `https://verifiedbmbuy.com${pagePath}`;
    await supabase.from("seo_settings").upsert(
      { page_path: pagePath, canonical_url: canonical },
      { onConflict: "page_path" }
    );
  };

  const save = async () => {
    if (!form.title || !form.content) {
      toast.info("Form incomplete — saving as draft instead");
      await saveAsDraft();
      return;
    }
    const slug = form.slug || form.title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
    const row = { ...form, slug };
    if (editing) {
      await supabase.from("blog_posts").update(row).eq("id", editing.id);
      toast.success("Post updated");
    } else {
      await supabase.from("blog_posts").insert([row]);
      toast.success("Post published");
    }
    await upsertCanonical(slug, "blog");
    cancel();
    fetchPosts();
  };

  const deletePost = async (id: string) => {
    await supabase.from("blog_posts").delete().eq("id", id);
    toast.success("Post deleted");
    if (editing?.id === id) cancel();
    fetchPosts();
  };

  if (loading) return <div className="text-muted-foreground">Loading...</div>;

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-extrabold text-foreground">Blog Posts ({posts.length})</h1>
        <Button onClick={startAdd} className="rounded-xl shadow-md shadow-primary/20">
          <Plus className="mr-2 h-4 w-4" /> New Post
        </Button>
      </div>

      {(editing || adding) && (
        <Card className="mb-6 rounded-2xl border border-primary/20 p-6">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-lg font-bold text-foreground">{editing ? "Edit Post" : "New Post"}</h2>
            <Button variant="ghost" size="icon" onClick={cancel}><X className="h-4 w-4" /></Button>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="sm:col-span-2">
              <label className="mb-1 block text-sm font-medium text-muted-foreground">Title</label>
              <Input value={form.title} onChange={(e) => updateForm((f) => ({ ...f, title: e.target.value }))} />
              {form.title.trim() && (
                <div className="mt-2 flex items-center gap-2 rounded-lg border border-border bg-muted/50 px-3 py-2">
                  <span className="text-xs font-semibold text-muted-foreground">Permalink:</span>
                  <span className="text-xs text-primary break-all">
                    https://verifiedbmbuy.com/blog/{form.slug || form.title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "")}
                  </span>
                  <button
                    type="button"
                    className="ml-auto text-xs font-medium text-primary hover:underline"
                    onClick={() => {
                      const slug = prompt("Edit slug:", form.slug || form.title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, ""));
                      if (slug !== null) updateForm((f) => ({ ...f, slug }));
                    }}
                  >
                    Edit
                  </button>
                </div>
              )}
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium text-muted-foreground">Category</label>
              <Input value={form.category} onChange={(e) => updateForm((f) => ({ ...f, category: e.target.value }))} />
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium text-muted-foreground">Slug (auto-generated if empty)</label>
              <Input value={form.slug} onChange={(e) => updateForm((f) => ({ ...f, slug: e.target.value }))} placeholder="auto-generated" />
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium text-muted-foreground">Read Time</label>
              <Input value={form.read_time} onChange={(e) => updateForm((f) => ({ ...f, read_time: e.target.value }))} />
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium text-muted-foreground">Date</label>
              <Input type="date" value={form.date} onChange={(e) => updateForm((f) => ({ ...f, date: e.target.value }))} />
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium text-muted-foreground">Author</label>
              <Input value={form.author} onChange={(e) => updateForm((f) => ({ ...f, author: e.target.value }))} />
            </div>
            <div className="flex items-center gap-2">
              <input type="checkbox" checked={form.published} onChange={(e) => updateForm((f) => ({ ...f, published: e.target.checked }))} className="rounded" />
              <label className="text-sm font-medium text-muted-foreground">Published</label>
            </div>
            <div className="sm:col-span-2">
              <label className="mb-1 block text-sm font-medium text-muted-foreground">Excerpt</label>
              <textarea className="flex w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring" rows={2} value={form.excerpt} onChange={(e) => updateForm((f) => ({ ...f, excerpt: e.target.value }))} />
            </div>
            <div className="sm:col-span-2">
              <div className="mb-1 flex items-center justify-between">
                <label className="block text-sm font-medium text-muted-foreground">Content (Markdown)</label>
                <Button type="button" variant="ghost" size="sm" onClick={() => setMediaPickerOpen(true)} className="gap-1.5 text-xs h-7">
                  <Image className="h-3.5 w-3.5" /> Insert Image from Media
                </Button>
              </div>
              <textarea
                ref={contentRef}
                className="flex w-full rounded-md border border-input bg-background px-3 py-2 text-sm font-mono ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                rows={8}
                value={form.content}
                onChange={(e) => updateForm((f) => ({ ...f, content: e.target.value }))}
              />
              <MediaPicker
                open={mediaPickerOpen}
                onClose={() => setMediaPickerOpen(false)}
                onSelect={(url) => {
                  const textarea = contentRef.current;
                  const md = `\n![image](${url})\n`;
                  if (textarea) {
                    const start = textarea.selectionStart;
                    const newContent = form.content.slice(0, start) + md + form.content.slice(start);
                    updateForm((f) => ({ ...f, content: newContent }));
                  } else {
                    updateForm((f) => ({ ...f, content: f.content + md }));
                  }
                }}
              />
            </div>
          </div>

          {/* Inline SEO Editor */}
          {(editing || autoSavedId) && (
            <InlineSeoEditor
              pagePath={`/blog/${editing?.slug || form.slug || form.title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "")}`}
              defaultTitle={`${form.title} | VBB STORE Blog`}
              defaultDescription={form.excerpt}
              defaultSchemaType="Article"
              defaultSchemaData={{ "@type": "Article", headline: form.title, author: { "@type": "Person", name: form.author }, datePublished: form.date }}
            />
          )}

          <div className="mt-4 flex items-center gap-2">
            {autoSaveStatus && <span className="text-xs text-muted-foreground italic">{autoSaveStatus}</span>}
           <Button onClick={save} className="rounded-xl shadow-md shadow-primary/20">
              <Save className="mr-2 h-4 w-4" /> {editing ? "Save" : "Publish"}
            </Button>
            <Button variant="secondary" onClick={saveAsDraft} className="rounded-xl">
              Save as Draft
            </Button>
            <Button variant="outline" onClick={cancel} className="rounded-xl">Cancel</Button>
          </div>
        </Card>
      )}

      <Card className="rounded-2xl border border-border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-muted/50">
                <th className="px-4 py-3 text-left font-semibold text-muted-foreground">Title</th>
                <th className="px-4 py-3 text-left font-semibold text-muted-foreground">Category</th>
                <th className="px-4 py-3 text-left font-semibold text-muted-foreground">Date</th>
                <th className="px-4 py-3 text-center font-semibold text-muted-foreground">SEO</th>
                <th className="px-4 py-3 text-left font-semibold text-muted-foreground">Status</th>
                <th className="px-4 py-3 text-right font-semibold text-muted-foreground">Actions</th>
              </tr>
            </thead>
            <tbody>
              {posts.map((p) => (
                <tr key={p.id} className="border-b border-border last:border-0 hover:bg-muted/30 transition-colors">
                  <td className="px-4 py-3 font-medium text-foreground max-w-xs truncate">{p.title}</td>
                  <td className="px-4 py-3"><span className="rounded-full bg-primary/10 px-2.5 py-1 text-xs font-bold text-primary">{p.category}</span></td>
                  <td className="px-4 py-3 text-muted-foreground">{p.date}</td>
                  <td className="px-4 py-3 text-center">
                    <SeoScoreIndicator pagePath={`/blog/${p.slug}`} />
                  </td>
                  <td className="px-4 py-3">
                    <span className={`rounded-full px-2.5 py-1 text-xs font-bold ${p.published ? "bg-green-100 text-green-700" : "bg-yellow-100 text-yellow-700"}`}>
                      {p.published ? "Published" : "Draft"}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <Button variant="ghost" size="icon" onClick={() => startEdit(p)} className="h-8 w-8"><Pencil className="h-4 w-4" /></Button>
                    <Button variant="ghost" size="icon" onClick={() => deletePost(p.id)} className="h-8 w-8 text-destructive hover:text-destructive"><Trash2 className="h-4 w-4" /></Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
};

export default AdminBlog;
