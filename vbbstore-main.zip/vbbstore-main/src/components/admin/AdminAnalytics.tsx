import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Package, FileText, ShoppingCart, DollarSign, TrendingUp, Users, Mail } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const AdminAnalytics = () => {
  const [stats, setStats] = useState({
    totalProducts: 0,
    totalPosts: 0,
    totalOrders: 0,
    pendingOrders: 0,
    completedOrders: 0,
    cancelledOrders: 0,
    revenue: 0,
    unreadMessages: 0,
    totalMessages: 0,
    activeCoupons: 0,
  });
  const [recentOrders, setRecentOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const [products, posts, orders, messages, coupons] = await Promise.all([
          supabase.from("products").select("id"),
          supabase.from("blog_posts").select("id"),
          supabase.from("orders").select("*"),
          supabase.from("contact_messages").select("id, read"),
          supabase.from("coupons").select("id, active"),
        ]);

        if (orders.error) throw orders.error;

        const orderData = (orders.data || []) as any[];
        const msgData = (messages.data || []) as any[];

        setStats({
          totalProducts: (products.data || []).length,
          totalPosts: (posts.data || []).length,
          totalOrders: orderData.length,
          pendingOrders: orderData.filter((o) => o.status === "pending").length,
          completedOrders: orderData.filter((o) => o.status === "completed").length,
          cancelledOrders: orderData.filter((o) => o.status === "cancelled").length,
          revenue: orderData.filter((o) => o.status === "completed").reduce((s: number, o: any) => s + Number(o.amount), 0),
          unreadMessages: msgData.filter((m) => !m.read).length,
          totalMessages: msgData.length,
          activeCoupons: ((coupons.data || []) as any[]).filter((c) => c.active).length,
        });

        setRecentOrders(orderData.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).slice(0, 5));
      } catch (err: any) {
        console.error("Analytics fetch error:", err);
        setError(err?.message || "Failed to load analytics");
      } finally {
        setLoading(false);
      }
    };
    fetchStats();
  }, []);

  if (loading) return <div className="text-muted-foreground">Loading analytics...</div>;
  if (error) return <div className="text-red-500">Error: {error}. Please refresh or check your connection.</div>;

  const cards = [
    { label: "Total Revenue", value: `$${stats.revenue}`, icon: DollarSign, color: "from-green-500 to-green-600" },
    { label: "Total Orders", value: stats.totalOrders, icon: ShoppingCart, color: "from-primary to-blue-600" },
    { label: "Pending Orders", value: stats.pendingOrders, icon: TrendingUp, color: "from-orange-500 to-orange-600" },
    { label: "Products", value: stats.totalProducts, icon: Package, color: "from-purple-500 to-purple-600" },
    { label: "Blog Posts", value: stats.totalPosts, icon: FileText, color: "from-cyan-500 to-cyan-600" },
    { label: "Unread Messages", value: stats.unreadMessages, icon: Mail, color: "from-red-500 to-red-600" },
    { label: "Active Coupons", value: stats.activeCoupons, icon: Users, color: "from-pink-500 to-pink-600" },
    { label: "Completed Orders", value: stats.completedOrders, icon: ShoppingCart, color: "from-emerald-500 to-emerald-600" },
  ];

  return (
    <div>
      <h1 className="mb-6 text-2xl font-extrabold text-foreground">Analytics Overview</h1>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {cards.map((s) => (
          <Card key={s.label} className="rounded-2xl border border-border">
            <CardContent className="flex items-center gap-4 p-5">
              <div className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br ${s.color} shadow-md`}>
                <s.icon className="h-5 w-5 text-white" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">{s.label}</p>
                <p className="text-xl font-extrabold text-foreground">{s.value}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Order breakdown */}
      <div className="mt-8 grid gap-6 lg:grid-cols-2">
        <Card className="rounded-2xl border border-border p-6">
          <h2 className="mb-4 text-lg font-bold text-foreground">Order Status Breakdown</h2>
          <div className="space-y-3">
            {[
              { label: "Completed", value: stats.completedOrders, pct: stats.totalOrders ? Math.round((stats.completedOrders / stats.totalOrders) * 100) : 0, color: "bg-green-500" },
              { label: "Pending", value: stats.pendingOrders, pct: stats.totalOrders ? Math.round((stats.pendingOrders / stats.totalOrders) * 100) : 0, color: "bg-yellow-500" },
              { label: "Cancelled", value: stats.cancelledOrders, pct: stats.totalOrders ? Math.round((stats.cancelledOrders / stats.totalOrders) * 100) : 0, color: "bg-red-500" },
            ].map((s) => (
              <div key={s.label}>
                <div className="mb-1 flex justify-between text-sm">
                  <span className="text-foreground font-medium">{s.label}</span>
                  <span className="text-muted-foreground">{s.value} ({s.pct}%)</span>
                </div>
                <div className="h-2 w-full rounded-full bg-muted">
                  <div className={`h-2 rounded-full ${s.color} transition-all`} style={{ width: `${s.pct}%` }} />
                </div>
              </div>
            ))}
          </div>
        </Card>

        <Card className="rounded-2xl border border-border p-6">
          <h2 className="mb-4 text-lg font-bold text-foreground">Recent Orders</h2>
          <div className="space-y-3">
            {recentOrders.map((o) => (
              <div key={o.id} className="flex items-center justify-between rounded-xl bg-muted/50 p-3">
                <div>
                  <p className="text-sm font-medium text-foreground">{o.order_number}</p>
                  <p className="text-xs text-muted-foreground">{o.customer} · {o.product}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-bold text-foreground">${o.amount}</p>
                  <span className={`rounded-full px-2 py-0.5 text-xs font-bold ${
                    o.status === "completed" ? "bg-green-100 text-green-700" :
                    o.status === "pending" ? "bg-yellow-100 text-yellow-700" :
                    "bg-red-100 text-red-700"
                  }`}>{o.status}</span>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
};

export default AdminAnalytics;
