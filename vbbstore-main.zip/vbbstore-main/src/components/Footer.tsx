import { Link } from "react-router-dom";
import { MessageCircle, Send, Mail } from "lucide-react";
import heroLogo from "@/assets/hero-logo.jpg";

const Footer = () => {
  return (
    <footer className="border-t border-border bg-card py-14 text-foreground">
      <div className="container">
        <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-5">
          <div className="lg:col-span-1">
            <div className="mb-5 flex items-center gap-3">
              <img src={heroLogo} alt="VBB Store logo" className="h-11 w-11 rounded-3xl object-cover ring-2 ring-primary/20" />
              <span className="text-lg font-extrabold">VBB STORE</span>
            </div>
            <p className="text-sm leading-relaxed text-muted-foreground">
              Trusted provider of verified Meta Business Manager and WhatsApp API accounts since 2020.
            </p>
          </div>

          <div>
            <h3 className="mb-4 text-sm font-bold uppercase tracking-wider text-foreground/80">Quick Links</h3>
            <nav className="flex flex-col gap-2.5 text-sm text-muted-foreground">
              <Link to="/" className="transition-colors hover:text-primary">Homepage</Link>
              <Link to="/shop" className="transition-colors hover:text-primary">All Products</Link>
              <Link to="/blog" className="transition-colors hover:text-primary">Latest Articles</Link>
              <Link to="/about" className="transition-colors hover:text-primary">About VBB STORE</Link>
              <Link to="/contact" className="transition-colors hover:text-primary">Support & Contact</Link>
              <Link to="/cart" className="transition-colors hover:text-primary">Shopping Cart</Link>
            </nav>
          </div>

          <div>
            <h3 className="mb-4 text-sm font-bold uppercase tracking-wider text-foreground/80">Products</h3>
            <nav className="flex flex-col gap-2.5 text-sm text-muted-foreground" aria-label="Products">
              <Link to="/shop?category=Verified+BM" className="transition-colors hover:text-primary">Verified BM</Link>
              <Link to="/shop?category=WhatsApp+API" className="transition-colors hover:text-primary">WhatsApp API</Link>
              <Link to="/shop?category=Facebook+Ads" className="transition-colors hover:text-primary">Facebook Ads Accounts</Link>
              <Link to="/shop?category=TikTok+Ads" className="transition-colors hover:text-primary">TikTok Ads</Link>
              <Link to="/shop?category=Google+Ads" className="transition-colors hover:text-primary">Google Ads</Link>
              <Link to="/shop?category=Reinstated+Profiles" className="transition-colors hover:text-primary">Reinstated Profiles</Link>
            </nav>
          </div>

          <div>
            <h3 className="mb-4 text-sm font-bold uppercase tracking-wider text-foreground/80">Important Links</h3>
            <nav className="flex flex-col gap-2.5 text-sm text-muted-foreground" aria-label="Important links">
              <Link to="/terms" className="transition-colors hover:text-primary">Terms of Service</Link>
              <Link to="/privacy" className="transition-colors hover:text-primary">Privacy Policy</Link>
              <Link to="/refund" className="transition-colors hover:text-primary">Refund Policy</Link>
              <Link to="/replacement" className="transition-colors hover:text-primary">Replacement Guarantee</Link>
              <Link to="/faq" className="transition-colors hover:text-primary">FAQ</Link>
            </nav>
          </div>

          <div>
            <h3 className="mb-4 text-sm font-bold uppercase tracking-wider text-foreground/80">Contact Us</h3>
            <div className="flex flex-col gap-3 text-sm text-muted-foreground">
              <a href="https://wa.me/8801302669333" className="flex items-center gap-2.5 transition-colors hover:text-primary">
                <MessageCircle className="h-4 w-4" /> WhatsApp
              </a>
              <a href="https://t.me/Verifiedbmbuy" className="flex items-center gap-2.5 transition-colors hover:text-primary">
                <Send className="h-4 w-4" /> Telegram
              </a>
              <a href="mailto:info@verifiedbmbuy.com" className="flex items-center gap-2.5 transition-colors hover:text-primary">
                <Mail className="h-4 w-4" /> info@verifiedbmbuy.com
              </a>
            </div>
          </div>
        </div>
        <div className="mt-10 border-t border-border pt-6 text-center text-sm text-muted-foreground">
          © {new Date().getFullYear()} VBB STORE. All rights reserved. | Verified BM & WhatsApp API Provider
        </div>
      </div>
    </footer>
  );
};

export default Footer;
