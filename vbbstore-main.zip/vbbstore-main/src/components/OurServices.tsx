import { ShieldCheck, MessageSquare, BarChart3, UserCheck, Sparkles, Package, Settings, Users } from "lucide-react";

const services = [
  { icon: ShieldCheck, title: "Verified Business Managers", desc: "BMs with real documentation and top trust scores — ready for serious advertising.", highlight: true },
  { icon: MessageSquare, title: "WhatsApp Business API", desc: "Enterprise WABA accounts set up for chatbots, bulk messaging, and customer support." },
  { icon: BarChart3, title: "Facebook Ads Accounts", desc: "Ad accounts with different spending limits so you can start running campaigns right away." },
  { icon: UserCheck, title: "Reinstated Profiles", desc: "Recovered Facebook profiles with clean records and full functionality." },
  { icon: Sparkles, title: "TikTok & Google Ads", desc: "Ready-to-use ad accounts for TikTok and Google. Start running campaigns on day one." },
  { icon: Package, title: "Bulk Orders", desc: "Need 10, 50, or 100 accounts? We offer volume pricing for agencies and resellers." },
  { icon: Settings, title: "Custom Setups", desc: "We'll configure accounts to match your exact requirements — just tell us what you need." },
  { icon: Users, title: "Dedicated Account Manager", desc: "Big orders get a personal point of contact for smooth onboarding and ongoing support." },
];

const OurServices = () => {
  return (
    <section className="py-16 md:py-24 bg-gradient-to-b from-muted/30 to-muted/80">
      <div className="container">
        <div className="mb-12 text-center animate-fade-in">
          <p className="mb-3 text-sm font-bold uppercase tracking-widest text-primary">Our Services</p>
          <h2 className="mb-4 text-3xl font-extrabold text-foreground md:text-5xl">
            What We Offer
          </h2>
          <p className="mx-auto max-w-2xl text-muted-foreground">
            Everything you need to run Meta ads at scale — all from one place.
          </p>
        </div>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4 animate-fade-in">
          {services.map((s) => (
            <div
              key={s.title}
              className={`group relative overflow-hidden rounded-2xl border bg-card p-6 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl ${
                s.highlight
                  ? "border-primary/30 shadow-md shadow-primary/10"
                  : "border-border shadow-sm hover:border-primary/20"
              }`}
            >
              {s.highlight && (
                <div className="absolute -right-8 -top-8 h-24 w-24 rounded-full bg-primary/10 blur-2xl" />
              )}
              <div className={`mb-4 flex h-12 w-12 items-center justify-center rounded-xl shadow-md transition-transform group-hover:scale-110 ${
                s.highlight
                  ? "bg-gradient-to-br from-primary to-blue-600 shadow-primary/25"
                  : "bg-gradient-to-br from-primary/80 to-blue-500 shadow-primary/15"
              }`}>
                <s.icon className="h-6 w-6 text-white" />
              </div>
              <h3 className="mb-2 font-bold text-foreground">{s.title}</h3>
              <p className="text-sm leading-relaxed text-muted-foreground">{s.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default OurServices;
