import { Card, CardContent } from "@/components/ui/card";
import { useScrollReveal } from "@/hooks/use-scroll-reveal";
import { Briefcase } from "lucide-react";

const samples = [
  { title: "Agency BM Setup – 10 Ad Accounts", client: "Digital Marketing Agency, USA", result: "Scaled to $50K/month ad spend with zero bans using our verified BMs." },
  { title: "WhatsApp API Integration – E-commerce", client: "Online Retail Store, UK", result: "Automated 10,000+ customer messages daily with our WABA account." },
  { title: "Reinstated Profile Recovery", client: "Social Media Manager, Germany", result: "Recovered banned profile within 24 hours, fully operational and verified." },
  { title: "TikTok Ads – Performance Team", client: "Performance Marketing Team, UAE", result: "Launched TikTok campaigns across 5 markets with our ready-to-use ad accounts." },
  { title: "Bulk BM Order – Reseller", client: "Account Reseller, India", result: "Supplied 50+ verified BMs with 100% delivery rate and zero issues." },
  { title: "Facebook Ads Account – Unlimited", client: "Dropshipping Business, Canada", result: "Launched campaigns immediately with unlimited spending ads account." },
];

const WorkSamples = () => {
  const { ref, visible } = useScrollReveal();

  return (
    <section className="py-16 md:py-24" ref={ref}>
      <div className="container">
        <div className={`mb-12 text-center transition-all duration-700 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}>
          <p className="mb-3 text-sm font-bold uppercase tracking-widest text-primary">Portfolio</p>
          <h2 className="mb-4 text-3xl font-extrabold text-foreground md:text-5xl">VBB STORE'S Work Sample</h2>
          <p className="mx-auto max-w-2xl text-muted-foreground">
            Real results from real clients. Here's a glimpse of the work we've done for advertisers worldwide.
          </p>
        </div>
        <div className={`grid gap-6 sm:grid-cols-2 lg:grid-cols-3 transition-all duration-700 delay-150 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}>
          {samples.map((s) => (
            <Card key={s.title} className="group border border-border rounded-2xl overflow-hidden transition-all duration-300 hover:-translate-y-1 hover:shadow-lg hover:border-primary/20">
              <CardContent className="p-0">
                <div className="bg-gradient-to-br from-primary/5 to-primary/15 p-5 border-b border-border">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-primary to-blue-600 shadow-sm">
                      <Briefcase className="h-4 w-4 text-white" />
                    </div>
                    <p className="text-xs font-bold uppercase tracking-wider text-primary">{s.client}</p>
                  </div>
                  <h3 className="text-base font-bold text-foreground">{s.title}</h3>
                </div>
                <div className="p-5">
                  <p className="text-sm leading-relaxed text-muted-foreground">{s.result}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default WorkSamples;
