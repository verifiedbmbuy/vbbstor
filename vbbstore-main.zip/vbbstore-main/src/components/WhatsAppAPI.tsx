import { MessageSquare, Bot, BarChart3, Lock, Smartphone, Globe, Zap, Users, ShieldCheck, BadgeCheck, Headphones } from "lucide-react";

const reasons = [
  { icon: MessageSquare, title: "Bulk Messaging", desc: "Send thousands of messages, order updates, and promos — all from one dashboard." },
  { icon: Bot, title: "Chatbot Ready", desc: "Hook up AI chatbots to handle customer questions while you sleep." },
  { icon: BarChart3, title: "Track Everything", desc: "See who opened your messages, who replied, and how your campaigns perform." },
  { icon: Lock, title: "Fully Encrypted", desc: "WhatsApp's end-to-end encryption keeps every business conversation private." },
  { icon: Smartphone, title: "Use Multiple Devices", desc: "Your whole team can manage conversations from different devices at the same time." },
  { icon: Globe, title: "Reach 2B+ Users", desc: "WhatsApp is used in 180+ countries. Your customers are already there." },
  { icon: Zap, title: "Real-Time Alerts", desc: "Send instant order confirmations, shipping updates, and payment receipts." },
  { icon: Users, title: "Team Inbox", desc: "Assign chats to team members so nothing falls through the cracks." },
  { icon: ShieldCheck, title: "Green Badge Verified", desc: "Get the official green checkmark that tells customers you're the real deal." },
  { icon: BadgeCheck, title: "Message Templates", desc: "Use pre-approved templates for consistent, compliant outreach at scale." },
  { icon: Headphones, title: "Always-On Support", desc: "Combine automated flows with live agents for round-the-clock customer care." },
  { icon: MessageSquare, title: "Rich Media", desc: "Send images, videos, documents, and interactive buttons — not just plain text." },
];

const WhatsAppAPI = () => {
  return (
    <section className="py-16 md:py-24">
      <div className="container">
        <div className="mb-12 text-center animate-fade-in">
          <p className="mb-3 text-sm font-bold uppercase tracking-widest text-primary">WhatsApp API</p>
          <h2 className="mb-4 text-3xl font-extrabold text-foreground md:text-5xl">
            Why Businesses Need WhatsApp API
          </h2>
          <p className="mx-auto max-w-2xl text-muted-foreground">
            Your customers are on WhatsApp. Meet them where they already are.
          </p>
        </div>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3 animate-fade-in">
          {reasons.map((r) => (
            <div key={r.title} className="group rounded-2xl border border-border bg-card p-6 transition-all duration-300 hover:-translate-y-1 hover:shadow-lg hover:border-primary/20">
              <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-green-500 to-green-600 shadow-md shadow-green-500/20">
                <r.icon className="h-6 w-6 text-white" />
              </div>
              <h3 className="mb-2 font-bold text-foreground">{r.title}</h3>
              <p className="text-sm leading-relaxed text-muted-foreground">{r.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default WhatsAppAPI;
