import { MapPin, MessageCircle, Send, Mail, Globe } from "lucide-react";
import { useScrollReveal } from "@/hooks/use-scroll-reveal";

const Location = () => {
  const { ref, visible } = useScrollReveal();

  return (
    <section className="py-16 md:py-24" ref={ref}>
      <div className="container">
        <div className={`mb-12 text-center transition-all duration-700 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}>
          <p className="mb-3 text-sm font-bold uppercase tracking-widest text-primary">Find Us</p>
          <h2 className="mb-4 text-3xl font-extrabold text-foreground md:text-5xl">How to Find Our Location</h2>
          <p className="mx-auto max-w-2xl text-muted-foreground">
            VBB STORE operates as a global digital business. Reach us through any of the channels below — we're available 24/7.
          </p>
        </div>
        <div className={`mx-auto max-w-3xl grid gap-4 sm:grid-cols-2 transition-all duration-700 delay-150 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}>
          {[
            { icon: Globe, title: "Online Store", desc: "vbbstore.com – Shop 24/7 from anywhere in the world" },
            { icon: MessageCircle, title: "WhatsApp", desc: "Chat with us anytime for instant support" },
            { icon: Send, title: "Telegram", desc: "@vbbstore – Message us on Telegram" },
            { icon: Mail, title: "Email", desc: "support@vbbstore.com" },
          ].map(({ icon: Icon, title, desc }) => (
            <div key={title} className="group flex items-start gap-4 rounded-2xl border border-border bg-card p-6 shadow-sm transition-all duration-300 hover:-translate-y-0.5 hover:shadow-lg hover:border-primary/20">
              <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-blue-600 shadow-md shadow-primary/20 transition-transform group-hover:scale-105">
                <Icon className="h-5 w-5 text-white" />
              </div>
              <div>
                <h3 className="font-bold text-foreground">{title}</h3>
                <p className="text-sm text-muted-foreground">{desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Location;
