import { Link, useLocation } from "react-router-dom";
import { ShoppingCart, Menu } from "lucide-react";
import { useState, useEffect } from "react";
import { useCart } from "@/context/CartContext";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger, SheetTitle } from "@/components/ui/sheet";
import logo from "@/assets/logo.png";

const navLinks = [
  { label: "Home", to: "/" },
  { label: "Shop", to: "/shop" },
  { label: "Blog", to: "/blog" },
  { label: "Contact Us", to: "/contact" },
  { label: "About Us", to: "/about" },
];

const Header = () => {
  const { totalItems } = useCart();
  const location = useLocation();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const isActive = (to: string) => location.pathname === to;

  return (
    <header
      className={`sticky top-0 z-50 transition-all duration-300 ${
        scrolled
          ? "border-b border-border bg-background/80 backdrop-blur-xl shadow-sm"
          : "bg-background"
      }`}
    >
      <div className="container flex h-[72px] items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center group">
          <img
            src={logo}
            alt="Verified BM Buy"
            className="h-10 object-contain transition-transform group-hover:scale-105"
            fetchPriority="high"
            loading="eager"
            width={278}
            height={40}
          />
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden items-center gap-0.5 lg:flex">
          {navLinks.map((link) => (
            <Link
              key={link.to}
              to={link.to}
              className={`relative rounded-xl px-4 py-2 text-sm font-semibold transition-all ${
                isActive(link.to)
                  ? "bg-primary text-primary-foreground shadow-md shadow-primary/20"
                  : "text-muted-foreground hover:bg-primary/5 hover:text-primary"
              }`}
            >
              {link.label}
            </Link>
          ))}
        </nav>

        {/* Right actions */}
        <div className="flex items-center gap-2">
          <Link to="/cart" className="relative" aria-label={`Shopping cart${totalItems > 0 ? `, ${totalItems} items` : ''}`}>
            <Button variant="ghost" size="icon" className="rounded-xl hover:bg-primary/5" aria-label={`Shopping cart${totalItems > 0 ? `, ${totalItems} items` : ''}`}>
              <ShoppingCart className="h-5 w-5" />
              {totalItems > 0 && (
                <span className="absolute -right-0.5 -top-0.5 flex h-5 w-5 items-center justify-center rounded-full bg-primary text-[11px] font-bold text-primary-foreground shadow-lg shadow-primary/30">
                  {totalItems}
                </span>
              )}
            </Button>
          </Link>

          <Button size="sm" className="hidden md:block rounded-xl shadow-md shadow-primary/20 font-bold px-5" onClick={() => window.open('https://wa.me/8801302669333', '_blank')} aria-label="Get started - Contact us on WhatsApp">
            Get Started
          </Button>

          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger asChild className="lg:hidden">
              <Button variant="ghost" size="icon" className="rounded-xl">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-72 p-0">
              <SheetTitle className="sr-only">Navigation</SheetTitle>
              <div className="flex h-[72px] items-center border-b border-border px-5">
                <img src={logo} alt="Verified BM Buy" className="h-9 object-contain" />
              </div>
              <nav className="flex flex-col gap-1 p-3">
                {navLinks.map((link) => (
                  <Link
                    key={link.to}
                    to={link.to}
                    onClick={() => setOpen(false)}
                    className={`rounded-xl px-4 py-3 text-base font-semibold transition-all ${
                      isActive(link.to)
                        ? "bg-primary text-primary-foreground shadow-md shadow-primary/20"
                        : "text-foreground hover:bg-primary/5 hover:text-primary"
                    }`}
                  >
                    {link.label}
                  </Link>
                ))}
                <Link to="/cart" onClick={() => setOpen(false)}>
                  <Button className="mt-3 w-full rounded-xl shadow-lg shadow-primary/25 font-bold py-5">
                    <ShoppingCart className="mr-2 h-4 w-4" />
                    Cart ({totalItems})
                  </Button>
                </Link>
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
};

export default Header;
