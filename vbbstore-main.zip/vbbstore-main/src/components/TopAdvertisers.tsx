import { Shield, Zap, Award, TrendingUp, Lock } from "lucide-react";

const reasons = [
  { icon: Shield, title: "Maximum Trust Score", desc: "Meta gives verified BMs the highest trust level. That means fewer bans, fewer headaches.", stat: "99.9%" },
  { icon: Zap, title: "Scale from Day One", desc: "No warm-up period. Start running big campaigns immediately with higher spend limits.", stat: "10x" },
  { icon: Award, title: "Premium Meta Tools", desc: "Access advanced APIs, analytics, and features that regular accounts can't touch.", stat: "50+" },
  { icon: TrendingUp, title: "Better Ad Delivery", desc: "Meta's algorithm favors verified accounts. You get better placements, lower costs, higher ROAS.", stat: "3x" },
  { icon: Lock, title: "Protected Assets", desc: "Enhanced security keeps your ad accounts, client data, and creative assets safe.", stat: "100%" },
  { icon: Award, title: "Professional Credibility", desc: "Partners and clients take you seriously when you operate from a verified business identity.", stat: "A+" },
];

const TopAdvertisers = () => {
  return (
    <section className="py-16 md:py-24 relative overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute -left-40 top-1/2 h-[400px] w-[400px] -translate-y-1/2 rounded-full bg-primary/[0.04] blur-[100px]" />
        <div className="absolute -right-40 top-1/3 h-[300px] w-[300px] rounded-full bg-primary/[0.03] blur-[80px]" />
      </div>
      <div className="container relative z-10">
        <div className="mb-12 text-center animate-fade-in">
          <p className="mb-3 text-sm font-bold uppercase tracking-widest text-primary">Top Advertisers</p>
          <h2 className="mb-4 text-3xl font-extrabold text-foreground md:text-5xl">
            Why the Best Media Buyers Use Verified BMs
          </h2>
          <p className="mx-auto max-w-2xl text-muted-foreground">
            A verified BM isn't a nice-to-have. For top advertisers, it's the competitive edge.
          </p>
        </div>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3 animate-fade-in">
          {reasons.map((r) => (
            <div key={r.title} className="group relative overflow-hidden rounded-2xl border border-border bg-card p-7 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:border-primary/20">
              <div className="absolute -right-6 -top-6 text-[5rem] font-black text-primary/[0.04] leading-none select-none">
                {r.stat}
              </div>
              <div className="relative">
                <div className="mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-primary to-blue-600 shadow-lg shadow-primary/20 transition-transform group-hover:scale-110">
                  <r.icon className="h-7 w-7 text-white" />
                </div>
                <h3 className="mb-2 text-lg font-bold text-foreground">{r.title}</h3>
                <p className="text-sm leading-relaxed text-muted-foreground">{r.desc}</p>
                <div className="mt-4 inline-flex items-center gap-1.5 rounded-full bg-primary/10 px-3 py-1 text-xs font-bold text-primary">
                  {r.stat} {r.title.split(" ")[0]}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TopAdvertisers;
