import { Shield, Clock, FileCheck, Globe, Truck, HeartHandshake } from "lucide-react";

const reasons = [
  { icon: Clock, title: "5+ Years in Business", desc: "We've been doing this for years. Our track record speaks for itself." },
  { icon: FileCheck, title: "Real Documentation", desc: "Every account comes with genuine docs — no shortcuts, no fakes." },
  { icon: Globe, title: "Worldwide Support", desc: "Doesn't matter where you are. We support customers across every time zone." },
  { icon: Truck, title: "Same-Day Delivery", desc: "Once payment clears, you get your credentials within minutes. Not hours, not days." },
  { icon: Shield, title: "7-Day Guarantee", desc: "Account stopped working? We'll replace it free within 7 days. No questions." },
  { icon: HeartHandshake, title: "Actual Human Support", desc: "You'll talk to real people on WhatsApp, Telegram, or email. Not bots." },
];

const WhyChooseUs = () => {
  return (
    <section className="py-16 md:py-24">
      <div className="container">
        <div className="mb-12 text-center animate-fade-in">
          <p className="mb-3 text-sm font-bold uppercase tracking-widest text-primary">Why VBB Store?</p>
          <h2 className="mb-4 text-3xl font-extrabold text-foreground md:text-5xl">Why People Keep Coming Back</h2>
          <p className="mx-auto max-w-2xl text-muted-foreground">
            We're not the only ones selling verified BMs — but we're the ones people trust.
          </p>
        </div>
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3 animate-fade-in">
          {reasons.map((r) => (
            <div key={r.title} className="group text-center">
              <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-primary to-blue-600 shadow-lg shadow-primary/25 transition-transform group-hover:scale-105">
                <r.icon className="h-8 w-8 text-white" />
              </div>
              <h3 className="mb-2 text-lg font-bold text-foreground">{r.title}</h3>
              <p className="text-sm leading-relaxed text-muted-foreground">{r.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default WhyChooseUs;
