import { useState } from "react";
import { categories } from "@/data/products";
import { useProducts } from "@/hooks/useProducts";
import ProductCard from "@/components/ProductCard";
import { Button } from "@/components/ui/button";

const ProductGrid = () => {
  const [active, setActive] = useState<string>("All");
  const { products } = useProducts();

  const filtered = active === "All" ? products : products.filter((p) => p.category === active);

  return (
    <section id="products" className="py-10 md:py-10">
      <div className="container">
        <div className="mb-12 text-center animate-fade-in">
          <p className="mb-3 text-sm font-bold uppercase tracking-widest text-primary">Our Products</p>
          <h2 className="mb-4 text-3xl font-extrabold text-foreground md:text-5xl">
            Premium Meta Accounts
          </h2>
          <p className="mx-auto max-w-2xl text-muted-foreground">
            Hand-picked verified accounts, ready to use. Every one comes with real documentation and same-day delivery.
          </p>
        </div>

        <div className="mb-10 flex flex-wrap justify-center gap-2 animate-fade-in">
          {categories.map((cat) => (
            <Button
              key={cat}
              variant={active === cat ? "default" : "outline"}
              size="sm"
              onClick={() => setActive(cat)}
              className={`rounded-full px-5 font-medium transition-all ${
                active === cat ? "shadow-md shadow-primary/25" : "hover:bg-primary/5"
              }`}
            >
              {cat}
            </Button>
          ))}
        </div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 animate-fade-in">
          {filtered.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProductGrid;
