import { BadgeCheck, ShieldCheck, Layers, Globe2, Gauge, Fingerprint } from "lucide-react";

const benefits = [
  { icon: BadgeCheck, title: "Genuine Verification", desc: "Every account is backed by real business documents. No fakes, no workarounds — just legitimate verification." },
  { icon: ShieldCheck, title: "Built to Last", desc: "Verified BMs carry inherent trust with Meta, making them far more resistant to bans and restrictions." },
  { icon: Layers, title: "Multi-Account Setup", desc: "Run multiple ad accounts, pixels, and product catalogs all under one roof." },
  { icon: Globe2, title: "No Geographic Limits", desc: "Advertise across all Meta platforms in any country without restrictions." },
  { icon: Gauge, title: "Higher Spend Limits", desc: "Verified accounts unlock spending levels that unverified accounts can only dream of." },
  { icon: Fingerprint, title: "Enterprise Security", desc: "Two-factor auth, admin controls, and business-grade security come standard." },
];

const DistinctBenefits = () => {
  return (
    <section className="py-16 md:py-24 bg-gradient-to-b from-muted/30 to-muted/80">
      <div className="container">
        <div className="mb-12 text-center animate-fade-in">
          <p className="mb-3 text-sm font-bold uppercase tracking-widest text-primary">Key Advantages</p>
          <h2 className="mb-4 text-3xl font-extrabold text-foreground md:text-5xl">
            What Makes Verified BM Assets Different
          </h2>
          <p className="mx-auto max-w-2xl text-muted-foreground">
            Real advantages that directly impact your advertising performance and bottom line.
          </p>
        </div>
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 animate-fade-in">
          {benefits.map((b) => (
            <div key={b.title} className="group rounded-2xl border border-border bg-card p-7 text-center shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-lg hover:border-primary/20">
              <div className="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-primary to-blue-600 shadow-lg shadow-primary/25 transition-transform group-hover:scale-105">
                <b.icon className="h-8 w-8 text-white" />
              </div>
              <h3 className="mb-2 font-bold text-foreground">{b.title}</h3>
              <p className="text-sm leading-relaxed text-muted-foreground">{b.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default DistinctBenefits;
