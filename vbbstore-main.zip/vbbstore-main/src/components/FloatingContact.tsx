import { MessageCircle, Send } from "lucide-react";
import ProductChatbot from "@/components/ProductChatbot";

const FloatingContact = () => {
  return (
    <div className="fixed bottom-28 right-6 z-50 flex flex-col gap-4">
      <a
        href="https://wa.me/8801302669333"
        target="_blank"
        rel="noopener noreferrer"
        className="flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-br from-green-500 to-green-600 text-white shadow-lg shadow-green-500/30 transition-all hover:scale-110 hover:shadow-xl hover:shadow-green-500/40"
        aria-label="Contact via WhatsApp"
      >
        <MessageCircle className="h-6 w-6" />
      </a>
      <a
        href="https://t.me/Verifiedbmbuy"
        target="_blank"
        rel="noopener noreferrer"
        className="flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-br from-primary to-blue-600 text-primary-foreground shadow-lg shadow-primary/30 transition-all hover:scale-110 hover:shadow-xl hover:shadow-primary/40"
        aria-label="Contact via Telegram"
      >
        <Send className="h-6 w-6" />
      </a>
      <ProductChatbot />
    </div>
  );
};

export default FloatingContact;
