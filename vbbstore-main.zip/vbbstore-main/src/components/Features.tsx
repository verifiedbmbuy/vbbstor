import { Headphones, Zap, RefreshCw } from "lucide-react";

const features = [
  {
    icon: Headphones,
    title: "24/7 Support",
    subtitle: "Talk to a Real Person",
    description: "Got a question? Our team is available around the clock. You'll speak with someone who actually knows Business Managers inside and out.",
    gradient: "from-blue-500 to-blue-600",
  },
  {
    icon: Zap,
    title: "Instant Delivery",
    subtitle: "No Waiting Around",
    description: "Pay, contact us, and get your account credentials right away. No delays, no back-and-forth — just fast, secure delivery.",
    gradient: "from-primary to-blue-500",
  },
  {
    icon: RefreshCw,
    title: "7 Days Replacement",
    subtitle: "We've Got Your Back",
    description: "If something goes wrong with your account in the first 7 days (and it's not your doing), we'll replace it free of charge. Simple as that.",
    gradient: "from-blue-600 to-primary",
  },
];

const Features = () => {
  return (
    <section className="relative -mt-12 z-10 pb-16 md:pb-20">
      <div className="container">
        <div className="grid gap-6 md:grid-cols-3 animate-fade-in">
          {features.map((f, i) => (
            <div
              key={f.title}
              className="group relative overflow-hidden rounded-2xl border border-border bg-card p-8 shadow-lg transition-all duration-300 hover:-translate-y-1 hover:shadow-xl"
              style={{ transitionDelay: `${i * 100}ms` }}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-primary/[0.02] to-primary/[0.06] opacity-0 transition-opacity group-hover:opacity-100" />
              <div className="relative">
                <div className={`mb-5 inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br ${f.gradient} shadow-lg shadow-primary/20`}>
                  <f.icon className="h-7 w-7 text-white" />
                </div>
                <h2 className="mb-1 text-xl font-bold text-foreground">{f.title}</h2>
                <p className="mb-3 text-sm font-semibold text-primary">{f.subtitle}</p>
                <p className="text-sm leading-relaxed text-muted-foreground">{f.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;
