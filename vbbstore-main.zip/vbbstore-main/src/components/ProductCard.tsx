import { Link, useNavigate } from "react-router-dom";
import { Shield, Truck, Headphones, MessageCircle, Check, Send } from "lucide-react";
import { Product } from "@/data/products";
import { useCart } from "@/context/CartContext";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { getOptimizedImageUrl } from "@/lib/imageUtils";

const ProductCard = ({ product }: { product: Product }) => {
  const { addToCart } = useCart();
  const navigate = useNavigate();
  const discount = product.originalPrice
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;
  const savings = product.originalPrice ? product.originalPrice - product.price : 0;

  const handleAdd = (e: React.MouseEvent) => {
    e.preventDefault();
    addToCart(product);
    toast.success(`${product.name} added to cart`);
  };

  const handleWhatsApp = (e: React.MouseEvent) => {
    e.preventDefault();
    window.open(
      `https://wa.me/8801302669333?text=${encodeURIComponent(`Hi, I want to buy: ${product.name} ($${product.price})`)}`,
      "_blank"
    );
  };

  return (
    <Link to={`/product/${product.slug || product.id}`}>
      <div className="group relative flex h-full flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-sm transition-all duration-300 hover:-translate-y-1.5 hover:shadow-xl hover:border-primary/20">
        {/* Discount badge */}
        {discount > 0 && (
          <div className="absolute left-3 top-3 z-10 flex items-center gap-1 rounded-lg bg-red-700 px-2.5 py-1.5 shadow-lg shadow-red-700/30">
            <span className="text-xs font-extrabold text-white">{discount}%</span>
            <span className="text-[10px] font-bold uppercase text-white">SAVE</span>
          </div>
        )}

        {/* Product badge */}
        {product.badge && (
          <div className="absolute right-3 top-3 z-10 rounded-lg bg-primary px-2.5 py-1 shadow-lg shadow-primary/30">
            <span className="text-xs font-bold text-primary-foreground">{product.badge}</span>
          </div>
        )}

        {/* Product image */}
        <div className="relative aspect-square overflow-hidden bg-muted">
          <img
            src={getOptimizedImageUrl(product.image, 500, 500)}
            alt={product.name}
            className="h-full w-full object-contain transition-transform duration-300 group-hover:scale-105"
            loading="lazy"
            width={406}
            height={406}
          />
        </div>

        {/* Category & Title area */}
        <div className="flex-1 px-5 pt-3 pb-3">
          <p className="mb-2 text-[11px] font-bold uppercase tracking-widest text-primary">
            {product.category}
          </p>
          <h3 className="mb-2 text-lg font-extrabold leading-snug text-foreground line-clamp-2 transition-colors group-hover:text-primary">
            {product.name}
          </h3>
          <p className="mb-3 text-sm leading-relaxed text-muted-foreground line-clamp-2">
            {product.description}
          </p>

          {/* Star rating */}
          <div className="mb-1 flex items-center gap-1.5">
            <div className="flex gap-0.5">
              {[1, 2, 3, 4, 5].map((s) => (
                <svg key={s} className="h-4 w-4" viewBox="0 0 20 20" fill="hsl(var(--primary))" stroke="hsl(var(--primary))">
                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                </svg>
              ))}
            </div>
            <span className="text-xs font-medium text-muted-foreground">5.0</span>
          </div>
        </div>

        {/* Price section */}
        <div className="mx-5 rounded-xl border-2 border-red-200 bg-red-50/50 p-3.5 dark:border-red-900/30 dark:bg-red-950/20">
          <div className="flex items-baseline gap-3">
            {product.originalPrice && (
              <span className="text-sm font-medium text-muted-foreground line-through">${product.originalPrice}</span>
            )}
            {savings > 0 && (
              <span className="text-xs font-bold text-green-800 dark:text-green-400">Save ${savings.toFixed(2)}</span>
            )}
          </div>
          <div className="flex items-baseline gap-1">
            <span className="text-3xl font-extrabold text-foreground">${product.price}</span>
            <span className="text-sm font-medium text-muted-foreground">USD</span>
          </div>
        </div>

        {/* Trust icons */}
        <div className="mx-5 mt-3 flex justify-between gap-2">
          {[
            { icon: Shield, label: "100%\nSafe" },
            { icon: Truck, label: "Instant" },
            { icon: Headphones, label: "24/7" },
          ].map(({ icon: Icon, label }) => (
            <div key={label} className="flex flex-1 flex-col items-center gap-1.5 rounded-xl border border-border bg-muted/50 p-2.5 transition-colors group-hover:border-primary/10">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-primary to-blue-600 shadow-sm">
                <Icon className="h-4 w-4 text-white" />
              </div>
              <span className="text-center text-[10px] font-bold leading-tight text-muted-foreground whitespace-pre-line">{label}</span>
            </div>
          ))}
        </div>

        {/* Actions */}
        <div className="p-5 pt-3 space-y-2">
          <Button
            className="w-full rounded-xl bg-green-700 py-5 font-bold text-white shadow-lg shadow-green-700/25 hover:bg-green-800 transition-all"
            onClick={handleWhatsApp}
          >
            <MessageCircle className="mr-2 h-5 w-5" />
            Buy on WhatsApp
          </Button>
          <Button
            className="w-full rounded-xl bg-primary py-5 font-bold text-primary-foreground shadow-lg shadow-primary/25 hover:bg-primary/90 transition-all"
            onClick={(e) => {
              e.preventDefault();
              window.open(`https://t.me/Verifiedbmbuy?text=${encodeURIComponent(`Hi, I want to buy: ${product.name} ($${product.price})`)}`, "_blank");
            }}
          >
            <Send className="mr-2 h-5 w-5" />
            Buy on Telegram
          </Button>
          <Button
            variant="outline"
            className="w-full rounded-xl py-5 font-bold transition-all hover:bg-primary/5"
            onClick={(e) => {
              e.preventDefault();
              addToCart(product);
              navigate("/checkout");
            }}
          >
            Buy Now
          </Button>
          <p className="flex items-center justify-center gap-1.5 text-xs text-muted-foreground">
            <Check className="h-3.5 w-3.5 text-green-500" />
            <span>Verified Account • Delivered Same Day</span>
          </p>
        </div>
      </div>
    </Link>
  );
};

export default ProductCard;
