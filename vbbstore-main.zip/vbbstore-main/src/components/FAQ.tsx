import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const faqs = [
  { q: "What exactly is a Verified Business Manager?", a: "It's a Meta Business Manager account that's been verified with real business documents. This gives it a higher trust score, which means fewer restrictions and access to advanced advertising tools." },
  { q: "How does the verification work?", a: "Each BM goes through Meta's official verification process using authentic business documents. That's what gives it the higher trust level and keeps it from getting flagged." },
  { q: "What's the WhatsApp Business API?", a: "It's the enterprise version of WhatsApp that lets you send automated messages, set up chatbots, and handle bulk messaging. Think of it as WhatsApp for serious businesses." },
  { q: "How fast will I get my account?", a: "Fast. Once your payment clears, you'll have your account credentials within minutes. We don't sit on orders." },
  { q: "What payment methods do you accept?", a: "We accept crypto — USDT (TRC20), Bitcoin, and Ethereum. It's fast, secure, and keeps things simple." },
  { q: "What if my account stops working?", a: "If it goes down within 7 days and it's not something you did, we replace it for free. No arguing, no fine print." },
  { q: "Can I use a verified BM for any niche?", a: "Most niches, yes. Just keep it within Meta's advertising policies. We can advise you if you're unsure about a specific niche." },
  { q: "How many ad accounts can I run?", a: "Depends on the package — we offer 1, 3, or 5 ad account slots. Need something custom? Just ask." },
  { q: "Is buying a verified BM safe?", a: "100%. Our accounts use genuine documentation and go through proper verification. We've been doing this for years with thousands of happy customers." },
  { q: "Do you offer bulk pricing?", a: "Absolutely. If you're ordering in volume, reach out on WhatsApp or Telegram and we'll work out a deal." },
  { q: "Do you sell TikTok and Google Ads accounts?", a: "Yes! We sell ready-to-use TikTok Ads and Google Ads accounts. They come with clean history and are ready for your campaigns." },
  { q: "Can I get a reinstated Facebook profile?", a: "Yes. These are fully recovered profiles with clean records and all functionality restored." },
  { q: "How do I reach support after buying?", a: "WhatsApp, Telegram, or email — we're available 24/7. You'll always get a real person, not a bot." },
  { q: "What trust score do your BMs have?", a: "The highest available. That's the whole point — genuine documentation means genuine trust scores." },
  { q: "Can I start running ads immediately?", a: "Yes. Every BM we sell is ready to go. Create your campaigns as soon as you get your credentials." },
  { q: "Do your WhatsApp API accounts get the green badge?", a: "They're eligible for it, yes. The green checkmark is a big trust signal for your customers." },
  { q: "What happens if my account gets restricted?", a: "If it happens within the 7-day window and it's not your fault, we replace it. Our team will walk you through the whole process." },
  { q: "Can I use the account from any country?", a: "Yes. Our accounts work globally. We've served customers in 50+ countries with zero issues." },
  { q: "Do accounts come with documentation?", a: "Every single one. You'll get the genuine documents that were used during verification." },
  { q: "How long have you been doing this?", a: "Over 5 years. We've served 10,000+ customers and we're still here because we do it right." },
];

const midpoint = Math.ceil(faqs.length / 2);
const leftColumn = faqs.slice(0, midpoint);
const rightColumn = faqs.slice(midpoint);

const FAQ = () => {
  return (
    <section id="faq" className="py-16 md:py-24">
      <div className="container">
        <div className="mb-12 text-center animate-fade-in">
          <p className="mb-3 text-sm font-bold uppercase tracking-widest text-primary">FAQ</p>
          <h2 className="mb-4 text-3xl font-extrabold text-foreground md:text-5xl">Got Questions? We've Got Answers.</h2>
          <p className="mx-auto max-w-2xl text-muted-foreground">
            Here's everything people usually ask before buying.
          </p>
        </div>
        <div className="grid gap-6 lg:grid-cols-2 animate-fade-in">
          <Accordion type="single" collapsible className="space-y-2">
            {leftColumn.map((faq, i) => (
              <AccordionItem key={i} value={`faq-l-${i}`} className="rounded-xl border border-border bg-card px-5 shadow-sm data-[state=open]:shadow-md data-[state=open]:border-primary/20 transition-all">
                <AccordionTrigger className="py-5 text-left font-bold text-foreground hover:text-primary hover:no-underline text-sm">
                  {faq.q}
                </AccordionTrigger>
                <AccordionContent className="pb-5 text-sm leading-relaxed text-muted-foreground">
                  {faq.a}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
          <Accordion type="single" collapsible className="space-y-2">
            {rightColumn.map((faq, i) => (
              <AccordionItem key={i} value={`faq-r-${i}`} className="rounded-xl border border-border bg-card px-5 shadow-sm data-[state=open]:shadow-md data-[state=open]:border-primary/20 transition-all">
                <AccordionTrigger className="py-5 text-left font-bold text-foreground hover:text-primary hover:no-underline text-sm">
                  {faq.q}
                </AccordionTrigger>
                <AccordionContent className="pb-5 text-sm leading-relaxed text-muted-foreground">
                  {faq.a}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  );
};

export default FAQ;
